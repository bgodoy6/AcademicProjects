﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using System.IO;
using System;

public class Item
{
    public int curr;
    public Item(int curr)
    {
        this.curr = curr;
    }
}

public class Gear
{
    public bool own,equipped;
    public Gear(bool own)
    {
        this.own = own;
        equipped = false;
    }
}

public interface IActions
{
    void refresh();
    int poisDam();
};

public class Combatant
{
    public int lvl, maxhp, hp, str, mag, def, res;
    public bool poisoned;
   
}

public class Player : Combatant, IActions
{
    public int money, maxMon, maxlvl, mp,maxmp;
    public Item antidote, poison, hpPot, magPot;
    public Gear sRing, mRing, pShield, mShield;
    public Player(int lvl, int money, int hpTot, int magTot, int antTot, int poiTot, bool sR, bool mR, bool pS, bool mS)
    {
        maxMon = 1000000;
        maxlvl = 100;
        this.lvl = lvl;
        this.money = money;
        antidote = new Item(antTot);
        poison = new Item(poiTot);
        hpPot = new Item(hpTot);
        magPot = new Item(magTot);
        sRing = new Gear(sR);
        mRing = new Gear(mR);
        pShield = new Gear(pS);
        mShield = new Gear(mS);
        refresh();
    }
    public void refresh()
    {
        maxhp = lvl * 10;
        maxmp = lvl * 6;
        poisoned = false;
        hp = maxhp;
        mp = maxmp;
        str = (int)(2 * lvl * ((sRing.own && sRing.equipped) ? 1.5 : 1));
        mag = (int)(3 * lvl * ((mRing.own && mRing.equipped) ? 2 : 1));
        def = (int)(2 * lvl * ((pShield.own && pShield.equipped) ? 1.5 : 1));
        res = (int)(2 * lvl * ((mShield.own && mShield.equipped) ? 1.5 : 1));
    }
    public bool levelUp()
    {
        money += 1000;
        if (money>maxMon)
        {
            money = maxMon;
        }
        if(lvl<100)
        {
            lvl++;
            maxhp = lvl * 10;
            maxmp = lvl * 5;
            refresh();
            return true;
        }
        if (lvl == 100)
        {
            lvl+=100;
            maxhp = lvl * 10;
            maxmp = lvl * 5;
            refresh();
            return true;
        }
        return false;
    }
    public int heal()
    {
        hp += (int)(maxhp * .5);
        if (hp > maxhp)
            hp = maxhp;
        return (int)(maxhp * .5);
    }
    public int recover()
    {
        mp += (int)(maxmp * .5);
        if (mp > maxmp)
            mp = maxmp;
        return (int)(maxmp * .5);
    }
    public int poisDam()
    {
        hp -= (int)(hp * .05);
        return (int)(hp * .05);
    }
    public bool cure()
    {
        if (poisoned)
        {
            poisoned = false;
            return true;
        }
        return false;
    }
}

public class Enemy : Combatant, IActions
{
    int type;   //1=boss
    int strMult, magMult, defMult, resMult,maxhpMult;
    public Enemy(int maxhpMult, int strMult, int magMult, int defMult, int resMult,int type)
    {
        this.type = type;
        this.maxhpMult = maxhpMult;
        this.strMult = strMult;
        this.magMult = magMult;
        this.defMult = defMult;
        this.resMult = resMult;
    }
    public void refresh()
    {
        poisoned = false;
        hp = maxhp;
    }
    public void updateStats(int lvl)
    {
        maxhp = maxhpMult * lvl;
        str = lvl*strMult;
        mag = lvl*magMult;
        def = lvl*defMult;
        res = lvl*resMult;
        refresh();
    }
    public int action(ref Player pl)
    {
        if (type==1)
        {
            if (hp < (int)(maxhp * .1))
            {
                pl.poisoned = true;
                poisoned = false;
                hp += 100;
            }
            pl.hp -= 500;
            return (int)(pl.maxhp * .5);
        }
        else {
            if (str - pl.def > mag - pl.res)
            {
                pl.hp -= (str - pl.def > 0) ? str - pl.def : 0;
                return (str - pl.def > 0) ? str - pl.def : 0;
            }
            else
            {
                pl.hp -= (mag - pl.res > 0) ? mag - pl.res : 0;
                return (mag - pl.res > 0) ? mag - pl.res : 0;
            }
        }
    }
    public int action(ref Player pl, bool phy)
    {
        if (phy)
        {
            hp -= (pl.str - def > 0) ? pl.str - def : 0;
            return (pl.str - def > 0) ? pl.str - def : 0;
        }
        else
        {
            pl.mp -= (int)Math.Ceiling(pl.maxmp*.1);
            hp -= (pl.mag - res > 0) ? pl.mag - res : 0;
            return (pl.mag - res > 0) ? pl.mag - res : 0;
        }
    }
    public int poisDam()
    {
        if (type==1 && poisoned)
        {
            hp -= (int)(maxhp * .1+1);
            return (int)(maxhp * .1+1);
        }
        if (type != 1 && poisoned)
        {
            hp -= (int)(maxhp * .05+1);
            return (int)(maxhp * .05+1);
        }
        return 0;
    }
}



public class Foundation : MonoBehaviour {   //character class
    System.Random rng;
    public bool exMode =false;
    Player character;
    Enemy knight, mage, boss, enem;
    ThreadStart Att, Mag, HP, MP, Poi, Ant;
    Thread thr;

    public float movementSpeed;
    public bool busy;
    public Animator an;
    public GameObject menu;
    public 
    
    void createText()
    {
        string path = Application.dataPath + "/sf.txt";
        if (!File.Exists(path))
        {
            File.WriteAllText(path, "1 1000 5 5 5 5 False False False False");
        }
    }
	// Use this for initialization
	void Start () {
        Att = new ThreadStart(useAtt);
        Mag = new ThreadStart(useMag);
        HP = new ThreadStart(useHealPot);
        MP = new ThreadStart(useMagPot);
        Poi = new ThreadStart(usePoison);
        Ant = new ThreadStart(useAnt);
        knight = new Enemy(15, 3, 3, 2, 1, 0);
        mage = new Enemy(10, 0, 4, 1, 3, 0);
        boss = new Enemy(20, 3, 3, 5, 3, 1);
        rng = new System.Random();
        an = GetComponent<Animator>();
        createText();
        loadFile();
	}

    // Update is called once per frame
    void Update()
    {
        if (!busy)
        {
            if (Input.GetAxisRaw("Horizontal") > 0 || Input.GetAxisRaw("Horizontal") < 0)
            {
                transform.Translate(new Vector3(Input.GetAxisRaw("Horizontal") * movementSpeed * Time.deltaTime, 0, 0));
                if (rng.Next(500) == 0 && !exMode)
                {
                    enterCombat();
                }
            }
            if (Input.GetAxisRaw("Vertical") > 0 || Input.GetAxisRaw("Vertical") < 0)
            {
                transform.Translate(new Vector3(0, Input.GetAxisRaw("Vertical") * movementSpeed * Time.deltaTime, 0));
                if (rng.Next(500) == 0 && !exMode)
                {
                    enterCombat();
                }
            }
            if (Input.GetButton("InventoryManagement"))
            {
                Inventory();
                Thread.Sleep(200);
            }
            an.SetFloat("X", Input.GetAxisRaw("Horizontal"));
            an.SetFloat("Y", Input.GetAxisRaw("Vertical"));
        }
        else
        {
            if (Input.GetButton("InventoryManagement"))
            {
                HideInventory();
                Thread.Sleep(200);
            }
        }
        an.Play("enAttacked");
       
    }
    //COMBAT STUFF
    public void enterCombat()
    {
        Busy();
        if (character.lvl>=100)
        {
            enem = boss;
        }
        else
        {
            if (rng.Next(2)==0)
            {
                enem = mage;
            }
            else
            {
                enem = knight;
            }
        }
        character.refresh();
        enem.updateStats((character.lvl==200)?100:character.lvl);
        menu.GetComponent<MainMenu>().Show3();
        menu.GetComponent<MainMenu>().Hide();
        menu.GetComponent<MainMenu>().Hide2();
        displayProgress();
        displayProgress2();
        menu.GetComponent<MainMenu>().displayEn("");
        menu.GetComponent<MainMenu>().displayPl("");
    }
    public void thrdAtt()
    {
        thr = new Thread(Att);
        thr.Start();
    }
    public void thrdMag()
    {
        thr = new Thread(Mag);
        thr.Start();
    }
    public void thrdHP()
    {
        thr = new Thread(HP);
        thr.Start();
    }
    public void thrdMP()
    {
        thr = new Thread(MP);
        thr.Start();
    }
    public void thrdPoi()
    {
        thr = new Thread(Poi);
        thr.Start();
    }
    public void thrdAnt()
    {
        thr = new Thread(Ant);
        thr.Start();
    }
    public void useAtt()
    {
        menu.GetComponent<MainMenu>().displayEn("-"+enem.action(ref character,true)+" hp");
        if (enemyDeath())
        {
            character.levelUp();
            Busy();
            return;
        }
        an.Play("enAttacked");
        Thread.Sleep(500);
        an.Play("pAttacked");
        Thread.Sleep(500);
        menu.GetComponent<MainMenu>().displayPl("-" + enem.action(ref character)+" hp");
        displayProgress();
        if (character.poisoned)
        {
            character.poisDam();//menu.GetComponent<MainMenu>().displayPl("-" +  + " hp");
        }
        if (enem.poisoned)
        {
            enem.poisDam();//menu.GetComponent<MainMenu>().displayEn("-" +  + " hp");
        }
        if (playerDeath())
            return;
        if (enemyDeath())
        {
            character.levelUp();
            Busy();
            return;
        }
        displayProgress();
        displayProgress2();
    }
    public void useMag()
    {
        if(character.mp>=(int)(character.maxmp*.1))
        {
            menu.GetComponent<MainMenu>().displayEn("-" + enem.action(ref character, false) + " hp");
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            menu.GetComponent<MainMenu>().displayPl("-" + enem.action(ref character) + " hp");
            displayProgress();
            if (character.poisoned)
            {
                character.poisDam();//menu.GetComponent<MainMenu>().displayPl("-" +  + " hp");
            }
            if (enem.poisoned)
            {
                enem.poisDam();//menu.GetComponent<MainMenu>().displayEn("-" +  + " hp");
            }
            if (playerDeath())
                return;
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            displayProgress();
            displayProgress2();
        }
        else
        {
            menu.GetComponent<MainMenu>().displayPl("You lack MP");
        }
    }
    public void useHealPot()
    {
        if (character.hp == character.maxhp)
        {
            menu.GetComponent<MainMenu>().displayPl("You're at full hp");
        }
        else if (character.hpPot.curr>0){
            menu.GetComponent<MainMenu>().displayPl("+" + character.heal()+" hp -"+enem.action(ref character) + " hp");
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            displayProgress();
            if (character.poisoned)
            {
                character.poisDam();//menu.GetComponent<MainMenu>().displayPl("-" +  + " hp");
            }
            if (enem.poisoned)
            {
                enem.poisDam();//menu.GetComponent<MainMenu>().displayEn("-" +  + " hp");
            }
            if (playerDeath())
                return;
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            character.hpPot.curr--;
            displayProgress();
            displayProgress2();
        }
        else
        {
            menu.GetComponent<MainMenu>().displayPl("You lack H. Potions");
        }
    }
    public void useMagPot()
    {
        if (character.mp==character.maxmp)
        {
            menu.GetComponent<MainMenu>().displayPl("You're at full mp");
        }
        else if (character.magPot.curr > 0)
        {
            menu.GetComponent<MainMenu>().displayPl("+" + character.recover() + " mp"+" -" + enem.action(ref character) + " hp");
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            displayProgress();
            if (character.poisoned)
            {
                character.poisDam();//menu.GetComponent<MainMenu>().displayPl("-" +  + " hp");
            }
            if (enem.poisoned)
            {
                enem.poisDam();//menu.GetComponent<MainMenu>().displayEn("-" +  + " hp");
            }
            if (playerDeath())
                return;
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            character.magPot.curr--;
            displayProgress();
            displayProgress2();
        }
        else
        {
            menu.GetComponent<MainMenu>().displayPl("You lack M. Potions");
        }
    }
    public void usePoison()
    {
        if (enem.poisoned)
        {
            menu.GetComponent<MainMenu>().displayPl("Enemy is already Poisoned");
        }
        else if (character.poison.curr > 0 && !enem.poisoned)
        {
            menu.GetComponent<MainMenu>().displayEn("Enemy poisoned");
            enem.poisoned = true;
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            menu.GetComponent<MainMenu>().displayPl("-" + enem.action(ref character) + " hp");
            displayProgress();
            if (character.poisoned)
            {
                character.poisDam();//menu.GetComponent<MainMenu>().displayPl("-" +  + " hp");
            }
            if (enem.poisoned)
            {
                enem.poisDam();//menu.GetComponent<MainMenu>().displayEn("-" +  + " hp");
            }
            if (playerDeath())
                return;
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            character.poison.curr--;
            displayProgress();
            displayProgress2();
        }
        else
        {
            menu.GetComponent<MainMenu>().displayPl("You lack Poison");
        }
    }
    public void useAnt()
    {
        if (!character.poisoned)
        {
            menu.GetComponent<MainMenu>().displayPl("You aren't Poisoned");
        }
        else if (character.antidote.curr > 0 && character.poisoned)
        {
            menu.GetComponent<MainMenu>().displayPl("You have been cured"+" -" + enem.action(ref character) + " hp");
            character.cure();
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            displayProgress();
            if (character.poisoned)
            {
                character.poisDam();//menu.GetComponent<MainMenu>().displayPl("-" +  + " hp");
            }
            if (enem.poisoned)
            {
                enem.poisDam();//menu.GetComponent<MainMenu>().displayEn("-" +  + " hp");
            }
            if (playerDeath())
                return;
            if (enemyDeath())
            {
                character.levelUp();
                Busy();
                return;
            }
            character.antidote.curr--;
            displayProgress();
            displayProgress2();
        }
        else
        {
            menu.GetComponent<MainMenu>().displayPl("You lack Antidotes");
        }
    }
    public void displayProgress()
    {
        menu.GetComponent<MainMenu>().displayStats("HP:" + character.hp + "/" + character.maxhp + "\nMP:" + character.mp + "/" + character.maxmp+" "+((character.poisoned)?"Poisoned":"")
            +"\nItems-"+"H.P.:"+character.hpPot.curr + " M.P.:" + character.magPot.curr + " P.:" + character.poison.curr + " A.:" + character.antidote.curr);
    }
    public void displayProgress2()
    {
        menu.GetComponent<MainMenu>().displayStats2("HP:" + enem.hp + "/" + enem.maxhp+"\n" + ((enem.poisoned) ? "Poisoned" : ""));
    }
    public bool enemyDeath()
    {
        if (enem.hp <= 0)
        {
            menu.GetComponent<MainMenu>().Hide();
            menu.GetComponent<MainMenu>().Hide3();
            menu.GetComponent<MainMenu>().Hide2();
            return true;
        }
        return false;
    }
    public bool playerDeath()
    {
        if (character.hp <= 0)
        {
            menu.GetComponent<MainMenu>().Show();
            menu.GetComponent<MainMenu>().Hide3();
            menu.GetComponent<MainMenu>().Hide2();
            return true;
        }
        return false;
    }
    //FILE STUFF
    public void loadFile()
    {
        string pth = Application.dataPath + "/sf.txt";
        StreamReader sr = new StreamReader(pth);
        try
        {
            string[] data = sr.ReadLine().Split(' ');
            character = new Player(Convert.ToInt32(data[0]), Convert.ToInt32(data[1]), Convert.ToInt32(data[2]), Convert.ToInt32(data[3])
            , Convert.ToInt32(data[4]), Convert.ToInt32(data[5]), Convert.ToBoolean(data[6]),
            Convert.ToBoolean(data[7]), Convert.ToBoolean(data[8]), Convert.ToBoolean(data[9]));
        }
        catch{}
    }
    public void save()
    {
        string pth = Application.dataPath + "/sf.txt";
        StreamWriter sw = new StreamWriter(pth);
        sw.WriteLine(""+character.lvl+" "+character.money + " " + character.hpPot.curr +" " + character.magPot.curr +" " + 
            character.antidote.curr +" " + character.poison.curr
            +" " + character.sRing.own + " " + character.mRing.own + " " + character.pShield.own + " " + character.mShield.own);
        sw.Close();

        menu.GetComponent<MainMenu>().display("The game has been saved.");
    }
    //Menus
    public void HideInventory()
    {
        Busy();

        menu.GetComponent<MainMenu>().Hide3();
        menu.GetComponent<MainMenu>().Hide2();
        menu.GetComponent<MainMenu>().Hide();
    }
    public void Inventory()
    {
        Busy();
        menu.GetComponent<MainMenu>().Show2();
        menu.GetComponent<MainMenu>().Hide();
        menu.GetComponent<MainMenu>().Hide3();
    }
    public void exploreMode()
    {
        if (!exMode)
        {
            exMode = true;
            menu.GetComponent<MainMenu>().display("Enemy encounters are off.");
        }
        else
        {
            exMode = false;
            menu.GetComponent<MainMenu>().display("Enemy encounters are on.");
        }
    }
    public void Busy()
    {
        if (busy)
            busy = false;
        else
            busy = true;
    }
    public void displayStats()
    {
        character.refresh();
        menu.GetComponent<MainMenu>().display("Lv:"+character.lvl+" hp:"+character.maxhp+ " mp:" + character.mp + " str:" +character.str+
            " mag:"+character.mag+" def:"+character.def+" res:"+character.res+"\nMoney:"+character.money+
            " Potions- H:"+character.hpPot.curr+" M:" + character.magPot.curr + " A:" + character.antidote.curr + " P:"+character.poison.curr);
    }
    public void buyHP()
    {
        if (character.money < 100)
        {
            menu.GetComponent<MainMenu>().display("You lack 100 money.");
        }
        else if (character.hpPot.curr < 10 && character.money >= 100)
        {
            character.hpPot.curr++;
            character.money -= 100;
            menu.GetComponent<MainMenu>().display("Health Potion purchased you have a total of "+character.hpPot.curr);
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You can't purchase more than 10 of this item.");
        }
    }
    public void buyMP()
    {
        if (character.money < 100)
        {
            menu.GetComponent<MainMenu>().display("You lack 100 money.");
        }
        else if (character.magPot.curr < 10 && character.money >= 100)
        {
            character.magPot.curr++;
            character.money -= 100;
            menu.GetComponent<MainMenu>().display("Magic Potion purchased you have a total of " + character.magPot.curr);
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You can't purchase more than 10 of this item.");
        }
    }
    public void buyA()
    {
        if (character.money < 100)
        {
            menu.GetComponent<MainMenu>().display("You lack 100 money.");
        }
        else if (character.antidote.curr < 10 && character.money >= 100)
        {
            character.antidote.curr++;
            character.money -= 100;
            menu.GetComponent<MainMenu>().display("Antidote purchased you have a total of " + character.antidote.curr);
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You can't purchase more than 10 of this item.");
        }
    }
    public void buyP()
    {
        if (character.money < 100)
        {
            menu.GetComponent<MainMenu>().display("You lack 100 money.");
        }
        else if (character.poison.curr < 10 && character.money >= 100)
        {
            character.poison.curr++;
            character.money -= 100;
            menu.GetComponent<MainMenu>().display("Poison purchased you have a total of " + character.poison.curr);
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You can't purchase more than 10 of this item.");
        }
    }
    public void buySr()
    {
        if (!character.sRing.own && character.money < 5000)
        {
            menu.GetComponent<MainMenu>().display("You lack 5000 money.");
        }
        else if (!character.sRing.own && character.money >= 5000)
        {
            character.sRing.own = true;
            character.money -= 5000;
            menu.GetComponent<MainMenu>().display("Strength Ring purchased.");
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You already own this item.");
        }
    }
    public void buyMr()
    {
        if (!character.mRing.own && character.money < 5000)
        {
            menu.GetComponent<MainMenu>().display("You lack 5000 money.");
        }
        else if (!character.mRing.own && character.money >= 5000)
        {
            character.mRing.own = true;
            character.money -= 5000;
            menu.GetComponent<MainMenu>().display("Magic Ring purchased.");
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You already own this item.");
        }
    }
    public void buyPs()
    {
        if (!character.pShield.own && character.money < 5000)
        {
            menu.GetComponent<MainMenu>().display("You lack 5000 money.");
        }
        else if (!character.pShield.own && character.money >= 5000)
        {
            character.pShield.own = true;
            character.money -= 5000;
            menu.GetComponent<MainMenu>().display("Physical Shield purchased.");
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You already own this item.");
        }
    }
    public void buyMs()
    {
        if (!character.mShield.own && character.money < 5000)
        {
            menu.GetComponent<MainMenu>().display("You lack 5000 money.");
        }
        else if (!character.mShield.own && character.money >= 5000)
        {
            character.mShield.own = true;
            character.money -= 5000;
            menu.GetComponent<MainMenu>().display("Magic Shield purchased.");
        }
        else
        {
            menu.GetComponent<MainMenu>().display("You already own this item.");
        }
    }
    public void eqSr()
    {
        if(character.sRing.own)
        {
            character.sRing.equipped = true;
            character.mRing.equipped = false;
            menu.GetComponent<MainMenu>().display("The Strength Ring has been equipped.");
        }
        else
            menu.GetComponent<MainMenu>().display("You don't own this item.");
        character.refresh();
    }
    public void eqMr()
    {
        if (character.mRing.own)
        {
            character.mRing.equipped = true;
            character.sRing.equipped = false;
            menu.GetComponent<MainMenu>().display("The Magic Ring has been equipped.");
        }
        else
            menu.GetComponent<MainMenu>().display("You don't own this item.");
        character.refresh();
    }
    public void eqPs()
    {
        if (character.pShield.own)
        {
            character.pShield.equipped = true;
            character.mShield.equipped = false;
            menu.GetComponent<MainMenu>().display("The Physical Shield item has been equipped.");
        }
        else
            menu.GetComponent<MainMenu>().display("You don't own this item.");
        character.refresh();
    }
    public void eqMs()
    {
        if (character.mShield.own)
        {
            character.mShield.equipped = true;
            character.pShield.equipped = false;
            menu.GetComponent<MainMenu>().display("The Magic Shield has been equipped.");
        }
        else
            menu.GetComponent<MainMenu>().display("You don't own this item.");
        character.refresh();
    }
}
