﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour {
    public GameObject follow;
    public Vector3 target;
    public float movement;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (!follow.GetComponent<Foundation>().busy)
        {
            target = new Vector3(follow.transform.position.x, follow.transform.position.y,transform.position.z);
            transform.position = Vector3.Lerp(transform.position, target, movement * Time.deltaTime);
        }
    }

}