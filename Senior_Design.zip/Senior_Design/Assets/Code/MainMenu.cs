﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour {
    public GameObject gameObject;
    public GameObject mainMenu;
    public GameObject secondMenu;
    public GameObject combatMenu;
    public Text txt, txtComStats, txtComStats2, txtPlayer, txtEnemy;
    public void Start()
    {
        Hide2();
        Show();
        Hide3();
    }
    public void Play()
    {
        Hide();
        Hide3();
        Hide2();
        gameObject.GetComponent<Foundation>().Busy();
        
    }
    public void Exit()
    {
        Debug.Log("QUIT");
        Application.Quit();
    }
    public void toMainMenu()
    {
        Show();
        Hide2();
        Hide3();
    }
    public void Hide()
    {
        mainMenu.gameObject.SetActive(false);
    }
    public void Show()
    {
        mainMenu.gameObject.SetActive(true);
    }
    public void Hide2()
    {
        secondMenu.gameObject.SetActive(false);
    }
    public void Show2()
    {
        secondMenu.gameObject.SetActive(true);
    }
    public void Hide3()
    {
        combatMenu.gameObject.SetActive(false);
    }
    public void Show3()
    {
        combatMenu.gameObject.SetActive(true);
    }
    public void display(string s)
    {
        txt.text = s;
    }
    public void displayStats(string s)
    {
        txtComStats.text = s;
    }
    public void displayStats2(string s)
    {
        txtComStats2.text = s;
    }
    public void displayEn(string s)
    {
        txtEnemy.text = s;
    }
    public void displayPl(string s)
    {
        txtPlayer.text = s;
    }
}
