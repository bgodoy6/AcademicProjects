/*
Author: Brian Godoy
Date: July 1, 2015
Project: Quadratic Equation Solver
Compiler: Visual Studio 2013
Operating System: Windows 7
*/

/*
Problem Description
Solve the quadratic equation using the quadratic formula Ax^2 + Bx + C = 0 without using a double value for for A, B, or C or pow function.
If b^2 - 4ac is a negative then proper coding must use absvalue and assign it a data type and use "i" to represent imaginary number and having it added to the other number.
If a is 0 then solution isn't possible.

Input
Variable		Data Type			Remark
a				int					no double
b				int
c				int


Output
e				char				to exit
y				double				(b^2-4ac) in order to account for an imaginary number
x1				double				add if y is negative to x2
x2				double
The solution for the quadratic equation (xadd) when it adds
(xsub) when it subtracts as double

Constants
None are required

Analysis
The quadratic formula is needed, since two numbers are usually the result of the quadratic formula two formulas will be needed.
x=(-b +|- (b^2 -4ac)^(1/2))/(2a) must be divided into two formulas when you are adding or subtracting xadd=(-b + (b^2 -4ac)^(1/2))/(2a) {y=b*b-4*a*c in c++}
xsub=(-b - (b^2 -4ac)^(1/2))/(2a). Now they must be converted to c++ without pow function, xadd = (-b + sqrt(y))/(2.0*a) then xsub = (-b + sqrt(y))/(2.0*a) {if y is positive}
If a=0 then x=infinity.If y=negative then (-b)/(2.0*a)=x1 sqrt(abs(y))/(2.0*a)=x2 , add or subtract both xs = to x then output *i for imaginary number.


Algorithm
1. Set up formatting flags (cmath iostraem namespace scientific setprecision)
2a. Use asterisks for design
2b. Title of program
2c. Asterisks
2d. Greet the user and say the purpose of the program
2e. print equation
2f. print Where A,B, and C are integers and A is not equal to zero.
3a. Set values for A,B,C, and y
3b. set the y equation
4. Ask user to input A
5. A stored
6. Ask for B
7. B stored
8. Ask for C
9a. C stored
9b. set a y equation
9c. y will be calculated
10a. if  a==0 then
10b. use asterisks
10c. print no solution is possible
end if
11a. if  y<0 then
11b. set x1 and x2 values
11c. x1=(-b)/(2.0*a)
11d. x2=(sqrt(abs(y)))/(2.0*a)
11e. print Two imaginary solutions are	X= (x1+x2*i) and (x1-x2*i)
12a. else
12b. set xadd and xsub value
12c. xadd = (-b + sqrt(y))/(2.0*a)
12d. xsub = (-b - sqrt(y))/(2.0*a)
12e. print The two real solutions are X= (xadd) and (xsub), if xadd!=xsub
12f. print The one real soution is X= (xadd)
13. Use asterisks
14. print Thanks for using the quadratic equation solver, goodbye.
15. Final row of asterisks
16. e character exit
*/

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main()
{
	cout << fixed << setprecision(4);
	cout << scientific;
	cout << "************************************************************" << '\n';
	cout << "       Quadratic Equation Solver         " << '\n';
	cout << "************************************************************" << '\n';
	cout << "Hello, this program will provide solutions for the equation" << '\n';
	cout << "        Ax^2 + Bx + C = 0" << '\n';
	cout << "Where A,B and C are integers and A is not equal to zero." << '\n';
	cout << "************************************************************" << '\n';
	cout << "Enter the value of A (integer only):";
	char e;
	int a;
	int b;
	int c;
	double y;
	cin >> a;
	cout << '\n' << "Enter the value of B (integer only):";
	cin >> b;
	cout << '\n' << "Enter the value of C (integer only):";
	cin >> c;
	y = (b*b - 4 * a*c);
	if (a == 0)
	{
		cout << '\n' << "No solution is possible if A is equal to zero." << '\n';
	}
	else if (y < 0)
	{
		double x1;
		double x2;
		x1 = (-b) / (2.0*a);
		x2 = (sqrt(abs(y))) / (2.0*a);
		cout << '\n' << "The two imaginary solutions are" << '\n';
		cout << "X = " << x1 << " + " << x2 << "*i" << '\n';
		cout << "and " << x1 << " - " << x2 << "*i" << '\n';
	}
	else
	{
		double xadd;
		double xsub;
		xadd = (0 - b + sqrt(y)) / (2.0*a);
		xsub = (0 - b - sqrt(y)) / (2.0*a);
		if (xadd != xsub)
		{
			cout << '\n' << "The two real solutions are" << '\n';
			cout << "X = " << xadd << '\n';
			cout << "and " << xsub << '\n';
		}
		else
		{
			cout << '\n' << "The one real solution is X = " << xadd << '\n';
		}
	}
	cout << "************************************************************" << '\n';
	cout << "Thanks for using the quadratic equation solver, goodbye." << '\n';
	cout << "************************************************************" << '\n';
	cin >> e;
}