/*
Brian Godoy
July 11, 2015
Assignment 4 employee gross pay
windows 7
visual studios 2013
*/

/*
Problem Description:
Use employee code, job classification code, years of service, and educational code to
calculate an employees grosspay.

Input:
Variable			Data Type		Remarks
first_name			string			irrelevant
last_name			string			irrelevant
job_type			string
employ				char			letter
id					int				irrelevant
job					int				1,2, or 3
years				int				whole number only
education_code		int				1,2,3, or 4
Computed Variables
job_				double			equation
year				double			equation
edu_				double			equation
e					char			to exit


flag_employ			bool
flag_job			bool
flag_years			bool
flag_edu			bool
base (int)
Outputted Variables
gross(double) is the true output needed
// add extra outputeed variables here

Analysis:
grosspay=base_pay+base_pay*job_class_code+base_pay*num_of_years+base_pay*education_code
This equation has to gradually convert.

Algorithm:
1. Set up formatting flags
2a. Set data types for variables and set boolean values to false
2b. greet user
3a. Ask for first name
3b. receive first name
3c. ask for last name
3d. receive last name
4a. ask for employee code and make a table
4b. receive employee code
4c. if (employ == 'S' || employ == 'O' || employ == 'M') then
flag_employ = true;
end if
4d. if (employ == 'S')then
base = 800;
job_type = "Factory Worker";
end if
else if (employ == 'O')then
base = 1000;
job_type = "Office Worker";
end else if
else then
base = 1500;
job_type = "Management";
end else
5a. ask for ID number
5b. receive ID number
6a. ask for job class code and make a table
6b. receive job class code
6c. if (job == 1 || job == 2 || job == 3)then
flag_job = true;
end if
6d. if (job == 1)then
job_ = 0.05;
end if
else if (job == 2)then
job_ = 0.1;
end else if
else then
job_ = 0.2;
end else
7a. ask for number of years worked
7b. receive number of years worked
7c. if (years <= 50 && years >= 0)then
flag_years = true;
end if
7d. if (years <= 10)then
year = 0.05;
end if
else
then
year = (years - 10) / 100.0 + .05;
end else
8a. ask for education code and make a chart
8b. receive education code
8c. if (edu == 1 || edu == 2 || edu == 3 || edu == 4)then
flag_edu = true;
end if
8d. if (edu == 1)then
edu_ = 0;
end if
else if (edu == 2)then
edu_ = .05;
end else if
else if (edu == 3)then
edu_ = .12;
end else if
else then
edu_ = .2;
end else
9. insert equation
10a. if (!flag_employ)then
cout << "You have put an invalid employee code please enter M,O, or S.\n";
end if
if (!flag_job)then
cout << "You have put an invalid job classification code please enter 1,2, or 3.\n";
end if
if (!flag_years)then
cout << "You have put a number of years please enter a whole number only but don't exceed 50.\n";
end if
if (!flag_edu)then
cout << "You have put an invalid educational code please enter 1,2,3,or 4.\n";
end if
10b. if (flag_employ && flag_job && flag_years && flag_edu)then
cout << '\n' << setw(15) << "Full Name" << setw(10) << "ID#" << setw(15) << "Job Type" << setw(20) << "Gross Salary\n";
cout << setw(10) << first << " " << last << setw(10) << id << setw(15) << job_type << setw(20) << gross;
end if
*/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	cout << fixed << setprecision(2);
	cout << "Welcome to the employee gross pay program.\n";
	string first, last, job_type;
	char employ, e;
	int id, job, years, edu, base;
	double gross, job_, year, edu_;
	bool flag_employ = false, flag_job = false, flag_years = false, flag_edu = false;
	cout << "Enter your first name.";
	cin >> first;
	cout << "Enter your last name.";
	cin >> last;
	cout << "Enter your employee code for factory worker(S), office worker(O), or management(M).";
	cin >> employ;
	if (employ == 'S' || employ == 'O' || employ == 'M'){
		flag_employ = true;
	}
	if (employ == 'S'){
		base = 800;
		job_type = "Factory Worker";
	}
	else if (employ == 'O'){
		base = 1000;
		job_type = "Office Worker";
	}
	else {
		base = 1500;
		job_type = "Management";
	}
	cout << "Enter your ID number.";
	cin >> id;
	cout << "Enter your job classification code [1,2, or 3].";
	cin >> job;
	if (job == 1 || job == 2 || job == 3){
		flag_job = true;
	}
	if (job == 1){
		job_ = 0.05;
	}
	else if (job == 2){
		job_ = 0.1;
	}
	else {
		job_ = 0.2;
	}
	cout << "Enter the number of years you have been employed.";
	cin >> years;
	if (years <= 50 && years >= 0){
		flag_years = true;
	}
	if (years <= 10){
		year = 0.05;
	}
	else
	{
		year = (years - 10) / 100.0 + .05;
	}
	cout << "Enter your education code for high school (1), junior college (2), university (3), or graduate school (4).";
	cin >> edu;
	if (edu == 1 || edu == 2 || edu == 3 || edu == 4){
		flag_edu = true;
	}
	if (edu == 1){
		edu_ = 0;
	}
	else if (edu == 2){
		edu_ = .05;
	}
	else if (edu == 3){
		edu_ = .12;
	}
	else {
		edu_ = .2;
	}
	gross = (base + base*job_ + base*year + base*edu_);
	if (!flag_employ){
		cout << "You have put an invalid employee code please enter M,O, or S.\n";
	}
	if (!flag_job){
		cout << "You have put an invalid job classification code please enter 1,2, or 3.\n";
	}
	if (!flag_years){
		cout << "You have put a number of years please enter a whole number only but don't exceed 50.\n";
	}
	if (!flag_edu){
		cout << "You have put an invalid educational code please enter 1,2,3,or 4.\n";
	}
	if (flag_employ && flag_job && flag_years && flag_edu){
		cout << '\n' << setw(15) << "Full Name" << setw(10) << "ID#" << setw(15) << "Job Type" << setw(20) << "Gross Salary" << endl;
		cout << setw(10) << first << " " << last << setw(10) << id << setw(15) << job_type << setw(20) << gross;
	}
	cin >> e;

	return 0;
}