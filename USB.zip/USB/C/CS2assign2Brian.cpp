/*
Brian Godoy
cs2
*/
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

class employee {
private:
	string First, Last, Name;
	char Status;
	double Income;
public:
	employee()
	{
		First = "";
		Last = "";
		Status = ' ';
		Income = 0.0;
		Name = First + ' ' + Last;
	}

	employee(string first, string last, char stat, float income)
	{
		First = first;
		Last = last;
		Status = stat;
		Income = income;
	}
	double getTax()
	{
		if (Status == 's' || Status == 'S')
		{
			if (Income > 28790)
			{
				return 1449.6 + 0.11*(Income - 28790);
			}
			else if (Income > 20930)
			{
				return 742.4 + 0.08*(Income - 20930);
			}
			else if (Income > 1710)
			{
				return 87 + 0.03*(Income - 1710);
			}
			else
			{
				return 0.00;
			}
		}
		else
		{
			if (Income > 28790)
			{
				return 2899.2 + 0.11*(Income - 57580);
			}
			else if (Income > 20930)
			{
				return 1905.4 + 0.09*(Income - 47120);
			}
			else if (Income > 1710)
			{
				return 330 + 0.04*(Income - 3420);
			}
			else
			{
				return 0.00;
			}
		}
	}

	void setFirst(string first)
	{
		First = first;
	}

	void setLast(string last)
	{
		Last = last;
	}

	void setStat(char stat)
	{
		Status = stat;
	}

	void setIncome(float income)
	{
		Income = income;
	}
	string getIName()
	{
		return Last + ',' + First;
	}
	string getName()
	{
		return First + ' ' + Last;
	}
	string getFirst()
	{
		return First;
	}

	string getLast()
	{
		return Last;
	}

	char getStat()
	{
		return Status;
	}

	double getIncome()
	{
		return Income;
	}
	void readFile(ifstream & in)
	{
		string inputfile;
		bool doneLoop = false;
		while (!doneLoop)
		{
			in.clear();
			cout << "Enter a file path.\n";
			getline(cin, inputfile);
			ifstream in(inputfile);
			if (!in.is_open())
			{
				cout << "File path does not exist.\n";
			}
			else
			{
				if (in.peek() != EOF)
				{
					doneLoop = true;
				}
				else
				{
					cout << "The file has no data in it\n";
					in.close();
				}
			}
		}//end while loop
		in.open(inputfile);
	}
	int extractFromFile(employee employeeArray[], ifstream &in)
	{
		string f, l;
		char st;
		double inc;
		int i = 0;
		while (in.peek() != EOF)
		{
			in >> f >> l >> st >> inc;
			employeeArray[i].setFirst(f);
			employeeArray[i].setLast(l);
			employeeArray[i].setStat(st);
			employeeArray[i].setIncome(inc);
			i++;
		}
		return i;
	}
	void print(int len, employee employeeArray[])
	{
		cout << setw(20) << left << "Name" << setw(10) << left << "Status" << setw(15) << left << "Gross Salary" << setw(10) << left << "Taxes" << "Net Salary" << '\n';
		//<< setw(60) << left << setfill('-') << '\n';
		int i = 0;
		cout << "--------------------------------------------------------------------------------\n";
		while (i < len)
		{
			cout << setw(20) << left << employeeArray[i].getIName() << setw(10) << left;
			if (employeeArray[i].getStat() == 's' || employeeArray[i].getStat() == 'S')
			{
				cout << "Single";
			}
			else if (employeeArray[i].getStat() == 'j' || employeeArray[i].getStat() == 'J')
			{
				cout << "Joint";
			}
			else
			{
				cout << employeeArray[i].getStat();
			}
			if (employeeArray[i].getStat() == 's' || employeeArray[i].getStat() == 'j' || employeeArray[i].getStat() == 'S' || employeeArray[i].getStat() == 'J')
			{
				if (employeeArray[i].getIncome() < 0.0)
				{
					cout << "Negative salary is invalid\n";
				}
				else{
					cout << fixed << showpoint << setprecision(2);
					cout << right << '$' << setw(15) << left << employeeArray[i].getIncome() << right << '$' << setw(10) << left << employeeArray[i].getTax() << right << '$' << employeeArray[i].getIncome() - employeeArray[i].getTax() << '\n';
				}
			}
			else {
				cout << "is invalid input\n";
			}
			i++;
		}
	}
	void print(ofstream &out, int len, employee employeeArray[])
	{
		out << setw(20) << left << "Name" << setw(10) << left << "Status" << setw(15) << left << "Gross Salary" << setw(10) << left << "Taxes" << "Net Salary" << '\n';
		//<< setw(60) << left << setfill('-') << '\n';
		out << "--------------------------------------------------------------------------------\n";
		int i = 0, aveamount = 0;
		double totInc = 0.0, tottax = 0.0, totnet = 0.0;
		while (i < len)
		{
			out << setw(20) << left << employeeArray[i].getName() << setw(10) << left;
			if (employeeArray[i].getStat() == 's' || employeeArray[i].getStat() == 'S')
			{
				out << "Single";
			}
			else if (employeeArray[i].getStat() == 'j' || employeeArray[i].getStat() == 'J')
			{
				out << "Joint";
			}
			else
			{
				out << employeeArray[i].getStat();
			}
			if (employeeArray[i].getStat() == 's' || employeeArray[i].getStat() == 'j' || employeeArray[i].getStat() == 'S' || employeeArray[i].getStat() == 'J')
			{
				if (employeeArray[i].getIncome() < 0.0)
				{
					out << "Negative salary is invalid\n";
				}
				else{
					aveamount++;
					out << fixed << showpoint << setprecision(2);
					out << right << '$' << setw(15) << left << employeeArray[i].getIncome() << right << '$' << setw(10) << left << employeeArray[i].getTax() << right << '$' << employeeArray[i].getIncome() - employeeArray[i].getTax() << '\n';
					totInc += employeeArray[i].getIncome();
					tottax += employeeArray[i].getTax();
					totnet += (employeeArray[i].getIncome() - employeeArray[i].getTax());
				}
			}

			else {
				out << "is invalid input\n";
			}
			i++;
		}
		out << '\n' << setw(30) << left << "Averages" << right << '$' << setw(15) << left << totInc / aveamount << right << '$' << setw(10) << left << tottax / aveamount << right << '$' << totnet / aveamount << "\n\n";
	}
	void printSingle()
	{
		cout << setw(20) << left << "Name" << setw(10) << left << "Status" << setw(15) << left << "Gross Salary" << setw(10) << left << "Taxes" << "Net Salary" << '\n';
		//<< setw(60) << left << setfill('-') << '\n';
		cout << "--------------------------------------------------------------------------------\n";
		cout << setw(20) << left << getIName() << setw(10) << left;
		if (getStat() == 's' || getStat() == 'S')
		{
			cout << "Single";
		}
		else if (getStat() == 'j' || getStat() == 'J')
		{
			cout << "Joint";
		}
		else{
			cout << getStat();
		}
		if (getStat() == 's' || getStat() == 'j' || getStat() == 'S' || getStat() == 'J')
		{
			if (getIncome() < 0.0)
			{
				cout << "Negative salary is invalid\n";
			}
			else{
				cout << fixed << showpoint << setprecision(2);
				cout << right << '$' << setw(15) << left << getIncome() << right << '$' << setw(10) << left << getTax() << right << '$' << getIncome() - getTax() << '\n';
			}
		}
		else {
			cout << "is invalid input\n";
		}
	}
};

/*string f, l;
char st;
float inc;
while (in.peek() != EOF)
{
int i = 0;
in >> f >> l >> st >> inc;
setFirst(f);
}*/
void openFile(employee accessEmployeeFunctions, employee employeeArray[], int len)
{
	string outPutFile;
	cout << "Enter a file path: ";
	cin.sync();
	getline(cin, outPutFile);
	ofstream outFile(outPutFile);


	if (!outFile.is_open())
	{
		cout << "Failed to open input File.\n";
	}//Must do file opening validation
	accessEmployeeFunctions.print(outFile, len, employeeArray);
	outFile.close();//must close file
}

void bubbleSort(employee employeeArray[], int len)
{
	employee temp;
	for (int i = 0; i < len; i++)
	{
		for (int j = 0; j < len - 1 - i; j++)
		{
			//cout << j;
			//cout << employeeArray[j].getLast() << ' ' << employeeArray[j + 1].getLast() << '\n';
			if (employeeArray[j].getLast() > employeeArray[j + 1].getLast())
			{
				//cout << employeeArray[j].getLast() << ' ' << employeeArray[j + 1].getLast() << '\n';
				temp = employeeArray[j];
				employeeArray[j] = employeeArray[j + 1];
				employeeArray[j + 1] = temp;
				//cout << j << ' ' <<  employeeArray[j].getLast() << ' ' << employeeArray[j + 1].getLast() << '\n';
			}
		}
	}



}

int LinearSearch(employee employeeArray[], employee temp, int len)
{
	int count;
	for (count = 0; count < len; count++)
	{
		if (temp.getLast() == employeeArray[count].getLast())
		{
			break;
		}
	}
	return count;
}

void addNewEmployee(int len, employee employeeArray[])
{
	string f, l;
	double inc;
	char st;
	cout << "Enter the first name, last name, status, and Income.(equally spaced).\n";
	cin >> f >> l >> st >> inc;
	employeeArray[len].setFirst(f);
	employeeArray[len].setLast(l);
	employeeArray[len].setStat(st);
	employeeArray[len].setIncome(inc);
}

void deleteEmployee(int len, employee employeeArray[], int count, employee temp)
{
	//cout << employeeArray[count].getLast() << ' ' << employeeArray[len -1].getLast() << '\n';
	temp = employeeArray[count];
	employeeArray[count] = employeeArray[len - 1];
	employeeArray[len - 1] = temp;
	//cout << employeeArray[count].getLast() << ' ' << employeeArray[len - 1].getLast() << '\n';
}
int main2()
{
	int len = 0;
	employee employeeArray[100], accessEmployeeFunctions;
	ifstream in;
	ofstream out;
	accessEmployeeFunctions.readFile(in);
	len = accessEmployeeFunctions.extractFromFile(employeeArray, in);
	int choice = 0;
	while (choice != 8)
	{
		cout << "Enter a menu number.\n"
			<< "1. Read data from a file to update the list.\n"
			<< "2. Print employees' info to a file.\n"
			<< "3. Sort employees by last name.\n"
			<< "4. Print employees' info to monitor.\n"
			<< "5. Search and print an employee's info by lastname.\n"
			<< "6. Add a new employee to the list.\n"
			<< "7. Delete an employee from the list.\n"
			<< "8. Exit.";
		cin >> choice;
		if (choice == 1)
		{
			accessEmployeeFunctions.readFile(in);
			accessEmployeeFunctions.extractFromFile(employeeArray, in);
		}
		else if (choice == 2)
		{
			openFile(accessEmployeeFunctions, employeeArray, len);
			accessEmployeeFunctions.print(out, len, employeeArray);
		}
		else if (choice == 3)
		{
			bubbleSort(employeeArray, len);
			cout << "Employees have been sorted by last name.\n";
		}
		else if (choice == 4)
		{
			accessEmployeeFunctions.print(len, employeeArray);
		}
		else if (choice == 5)
		{
			cout << "Enter an employee's last name.";
			string lastNameSearch;
			cin >> lastNameSearch;
			accessEmployeeFunctions.setLast(lastNameSearch);
			int empNum = LinearSearch(employeeArray, accessEmployeeFunctions, len);
			employeeArray[empNum].printSingle();
		}
		else if (choice == 6)
		{
			addNewEmployee(len, employeeArray);
			len++;
			cout << "A new employee has been added.\n";
		}
		else if (choice == 7)
		{
			cout << "Enter an employee's last name.";
			int deleteArray = 0;
			string lastNameSearch;
			cin >> lastNameSearch;
			accessEmployeeFunctions.setLast(lastNameSearch);
			deleteArray = LinearSearch(employeeArray, accessEmployeeFunctions, len);
			deleteEmployee(len, employeeArray, deleteArray, accessEmployeeFunctions);
			cout << "The employee with the last name " << lastNameSearch << " has been succesfully been deleted.\n";
			len--;
			//cout << employeeArray[deleteArray].getLast() << ' ' << employeeArray[len - 1].getLast() << '\n';
		}
		else if (choice == 8)
		{
			cout << "Thank you for using this program.";
			//Exit
		}
		else
		{
			cout << "Invalid choice.\n";
		}
	}

	system("pause");
	return 0;
}