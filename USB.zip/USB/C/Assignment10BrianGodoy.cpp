/*
Brian Godoy
8/11/15
Assignment 10
Visual Studios 2013
Windows 7
*/

/*
ID Block. Fill out your information here
*/
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct CreditCard
{
	string CCN;
	string LastName;
	string FirstName;
	double balance;
	double CreditLimit;
	/*
	Item 1: Complete the body of default constructor such that the various data members are set to following values
	when the default constructor is called:
	Data Member Name		Value set by default Constructor
	CCN						Credit card number not set
	LastName 				Last name not set
	FirstName 				First name not set
	balance 				0.0
	CreditLimt 				1500.00
	*/
	CreditCard()
	{
		CCN = "Credit card number not set";
		LastName = "Last name not set";
		FirstName = "First name not set";
		balance = 0.0;
		CreditLimit = 1500.00;


	}
	/*
	Item 2: Complete the body of explicit constructor that constructor arguments initialize the corresponding and mapping
	struct data members. The table below gives as to which data member is initialized by which constructor argument
	Data Member Name		Value set by explicit Constructor
	CCN						cardNum
	LastName 				lname
	FirstName 				fname

	There are no constructor arguments to initialize balance and CreditLimit. They are set to same values as the default
	constructor as below:
	balance                 0.0
	CreditLimt 				1500.00
	*/
	CreditCard(string fname, string lname, string cardNum)
	{
		LastName = lname;
		FirstName = fname;
		CCN = cardNum;
		balance = 0.0;
		CreditLimit = 1500.00;



	}
	//get functions
	string getCreditCardNumber()
	{
		return CCN;
	}
	string getFirstName()
	{
		return FirstName;
	}
	string getLastName()
	{
		return LastName;
	}
	string getFullName()
	{
		return FirstName + ' ' + LastName;
	}
	double getBalance()
	{
		return balance;
	}
	double getCreditLimit()
	{
		return CreditLimit;
	}
	/*
	Item 3: Write the body of member function ChargeToCard, which takes money as argument. money is the amount of money
	the credit card holder wishes to charge in a purchase transaction. This function MUST do a conditional check
	to ascertain that adding the charge equal to money would not exceed customer's credit limit. Another way of saying this
	is that argument money must be less than or equal to available credit to authorize the purchase, else the transaction
	must be declined. This is similar in nature to the withdraw function for BankAccount struct you did. Sample output from
	the program may give some clue as how this function may be working.
	*/
	void ChargeToCard(double money)
	{
		double availableCredit = CreditLimit - balance;
		if (money <= availableCredit)
		{
			balance += money;
		}
		else
		{
			cout << "Purchase has been denied.\n";
		}


	}
	void makePaymentToCard(double money)
	{
		balance -= money;
	}
	void print()
	{
		cout << fixed << showpoint << setprecision(2);
		cout << "Credit Card Number: " << CCN << endl
			<< "Name: " << FirstName << ' ' << LastName << endl
			<< "Amount owed: $" << balance << endl
			<< "-------------------------------------------" << endl;
	}
};
/*
You can lookup Singhal ebook chapter 12 to see how a selection sort function has been done for
sorting struct arrays. That may provide clues as how to do the bubble sort function here.

Item 4: Write a bubbleSort function (blank body provided later), which sorts the array ccArr passed to it based on the
flag value it gets. len is the logical length or length of interest. flag values determine the sorting basis as follows:
flag = 1 sort based on last name
flag = 2 sort based on CCN
flag = 3 sort based on balance
*/
void bubbleSort(CreditCard ccArr[], int flag, int len);
/*
Item 5: You can look at Singhal ebook chapter 12 to see details of linear search.
Write a LinearSearch function (blank body provided later) that takes a creditCard array ccArr, a flag, length of interest len, and a CreditCard
object CC as arguments. flag value specifies the search basis as below:
if flag == 1 search based on last name
if flag == 2 search based on credit card number
If flag == 1 then it's caller's responsibility that last name field of object CC is populated.
if flag == 2 then it's caller's responsibility that credit card number field of CC object is populated.
The function returns -1 if the item is not found, otherwise return index of the array  where item is located.
*/
int LinearSearch(CreditCard ccArr[], CreditCard CC, int flag, int len);
void print(CreditCard arr[], int len);


const int MAX = 100;

int main()
{
	//Instructor code that is required. Do not delete!!!!
	/*CreditCard CC1("JIM", "JONES", "56738");
	CC1.ChargeToCard(200.99);
	CreditCard CC2("ADAM", "ASHLEY", "12345");
	CC2.ChargeToCard(2000.00);
	CreditCard CC3("BERTHA", "MAPOS", "34567");
	CC3.ChargeToCard(800.91);
	CreditCard CC4("LISA", "BRAVE", "98765");
	CC4.ChargeToCard(1001.23);
	CreditCard CC5("WILLY", "NILLY", "23413");
	CC5.ChargeToCard(700.00);
	CreditCard CC6("JILL", "QUIRK", "67895");
	CC6.ChargeToCard(1400.91);*/
	CreditCard CardArray[MAX];
	int num = 0;
	/*CardArray[0] = CC1;
	CardArray[1] = CC2;
	CardArray[2] = CC3;
	CardArray[3] = CC4;
	CardArray[4] = CC5;
	CardArray[5] = CC6;*/
	//End of instructor code

	/*
	Item 6:
	Write a menu driven program with following menu items and their functionality. [The sample output gives you
	clue as how this would function].
	1. Print credit card list in its current state to console.
	2. Sort credit card list based on last name.
	3. Sort credit card list based on credit card number.
	4. Sort credit card list based on balance.
	5. Search credit card list based on customer last name.
	6. Search credit card list based on credit card number.
	7. Exit.
	*/

	bool done = false;
	unsigned int len = 6;
	while (!done)
	{
		cout << "Type a menu option.\n"
			<< "1. Print credit card list in its current state to console.\n"
			<< "2. Sort credit card list based on last name.\n"
			<< "3. Sort credit card list based on credit card number.\n"
			<< "4. Sort credit card list based on balance.\n"
			<< "5. Search credit card list based on customer last name.\n"
			<< "6. Search credit card list based on credit card number.\n"
			<< "7. Exit.\n";
		int choice;
		cin >> choice;

		if (choice == 1)
		{
			print(CardArray, len);
		}
		if (choice == 2)
		{
			bubbleSort(CardArray, 1, len);
		}
		if (choice == 3)
		{
			bubbleSort(CardArray, 2, len);
		}
		if (choice == 4)
		{
			bubbleSort(CardArray, 3, len);
		}
		if (choice == 5)
		{
			cout << "Enter a customer last name.\n";
			string lname;
			cin >> lname;
			CreditCard CC{ "", lname, "" };
			int index = LinearSearch(CardArray, CC, 1, len);

			if (index < 0)
			{
				cout << "No customer has last name = " << lname << endl;
			}
			else
			{
				cout << "Customer found. Full record below:" << endl;
				CardArray[index].print();
			}
		}
		if (choice == 6)
		{
			cout << "Enter a customer last name.\n";
			string ccn;
			cin >> ccn;
			CreditCard CC{ "", "", ccn };
			int index = LinearSearch(CardArray, CC, 2, len);

			if (index < 0)
			{
				cout << "No student has last name = " << ccn << endl;
			}
			else
			{
				cout << "Student found. Full record below:" << endl;
				CardArray[index].print();
			}
		}
		if (choice == 7)
		{
			done = true;
		}
	}


	system("pause");
	return 0;
}//end of main function

void print(CreditCard arr[], int len)
{
	for (size_t i = 0; i < len; i++)
	{
		arr[i].print();
	}
}//end of print function
int LinearSearch(CreditCard ccArr[], CreditCard CC, int flag, int len)
{
	int index = -1;
	for (int count = 0; count < len; count++)
	{
		if (flag == 1)
		{
			if (CC.LastName == ccArr[count].LastName)
			{
				index = count;
				break;
			}
		}
		else if (flag == 2)
		{
			if (CC.CCN == ccArr[count].CCN)
			{
				index = count;
				break;
			}
		}
		else
		{
			cout << "Invalid search basis.\n";
			break;
		}
	}



	return index;
}//end of LinearSearch function
void bubbleSort(CreditCard ccArr[], int flag, int len)
{
	CreditCard temp;
	for (int i = 0; i < len; i++)
	{
		for (int j = 0; j < len - 1 - i; j++)
		{
			switch (flag)
			{
			case 1:
			{
				if (ccArr[j].LastName > ccArr[j + 1].LastName)
				{
					temp = ccArr[j];
					ccArr[j] = ccArr[j + 1];
					ccArr[j + 1] = temp;
					//cout << ccArr[j].LastName << ' ' << ccArr[j + 1].LastName << '\n';
				}
			}
			break;
			case 2:
			{
				if (ccArr[j].CCN > ccArr[j + 1].CCN)
				{
					temp = ccArr[j];
					ccArr[j] = ccArr[j + 1];
					ccArr[j + 1] = temp;
				}
			}
			break;
			case 3:
			{
				if (ccArr[j].balance > ccArr[j + 1].balance)
				{
					temp = ccArr[j];
					ccArr[j] = ccArr[j + 1];
					ccArr[j + 1] = temp;
				}
			}
			break;
			default:
				cout << "This case is not coded yet.\n";
				return;
			}

		}
	}



}//End of bubble sort function
/*
Example output
Hello ADAM ASHLEY
Charging $2000 will exceed credit limit. Transaction declined.
----------------------------------------------
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
1
Credit Card Number: 56738
Name: JIM JONES
Amount owed: $200.99
-------------------------------------------
Credit Card Number: 12345
Name: ADAM ASHLEY
Amount owed: $0.00
-------------------------------------------
Credit Card Number: 34567
Name: BERTHA MAPOS
Amount owed: $800.91
-------------------------------------------
Credit Card Number: 98765
Name: LISA BRAVE
Amount owed: $1001.23
-------------------------------------------
Credit Card Number: 23413
Name: WILLY NILLY
Amount owed: $700.00
-------------------------------------------
Credit Card Number: 67895
Name: JILL QUIRK
Amount owed: $1400.91
-------------------------------------------
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
2
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
1
Credit Card Number: 56738
Name: JIM ASHLEY
Amount owed: $200.99
-------------------------------------------
Credit Card Number: 12345
Name: ADAM BRAVE
Amount owed: $0.00
-------------------------------------------
Credit Card Number: 34567
Name: BERTHA JONES
Amount owed: $800.91
-------------------------------------------
Credit Card Number: 98765
Name: LISA MAPOS
Amount owed: $1001.23
-------------------------------------------
Credit Card Number: 23413
Name: WILLY NILLY
Amount owed: $700.00
-------------------------------------------
Credit Card Number: 67895
Name: JILL QUIRK
Amount owed: $1400.91
-------------------------------------------
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
3
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
1
Credit Card Number: 12345
Name: JIM ASHLEY
Amount owed: $200.99
-------------------------------------------
Credit Card Number: 23413
Name: ADAM BRAVE
Amount owed: $0.00
-------------------------------------------
Credit Card Number: 34567
Name: BERTHA JONES
Amount owed: $800.91
-------------------------------------------
Credit Card Number: 56738
Name: LISA MAPOS
Amount owed: $1001.23
-------------------------------------------
Credit Card Number: 67895
Name: WILLY NILLY
Amount owed: $700.00
-------------------------------------------
Credit Card Number: 98765
Name: JILL QUIRK
Amount owed: $1400.91
-------------------------------------------
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
4
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
1
Credit Card Number: 12345
Name: JIM ASHLEY
Amount owed: $0.00
-------------------------------------------
Credit Card Number: 23413
Name: ADAM BRAVE
Amount owed: $200.99
-------------------------------------------
Credit Card Number: 34567
Name: BERTHA JONES
Amount owed: $700.00
-------------------------------------------
Credit Card Number: 56738
Name: LISA MAPOS
Amount owed: $800.91
-------------------------------------------
Credit Card Number: 67895
Name: WILLY NILLY
Amount owed: $1001.23
-------------------------------------------
Credit Card Number: 98765
Name: JILL QUIRK
Amount owed: $1400.91
-------------------------------------------
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
5
Enter last name of card holder in all capitals [For example adams must be entered as ADAMS: QUIRK
The record found. Complete detail is below.
Credit Card Number: 98765
Name: JILL QUIRK
Amount owed: $1400.91
-------------------------------------------
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
5
Enter last name of card holder in all capitals [For example adams must be entered as ADAMS: xyz
Record with name xyz not found.
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
6
Enter Credit card number: 876
Record with card number 876 not found.
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
6
Enter Credit card number: 67895
The record found. Complete detail is below.
Credit Card Number: 67895
Name: WILLY NILLY
Amount owed: $1001.23
-------------------------------------------
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
9
This menu item is not yet implemented.
Enter the menu item number below and then press enter key.
1. Print credit card list in its current state.
2. Sort based on last name.
3. Sort based on credit card number
4. Sort based on balance.
5. Search based on last name.
6. Search based on credit card number.
7. Exit.
7

*/