//Brian Godoy
//assignment 4
/*
UML
Class Person
protected:
string address
long Id
public:
Person(string ad = "", long id)
setAddress(string ad):void
setId(long id):void
getAddress():string
getId():long
printPerson():void
*/
/*
UML
Class NameType
protected:
string first, middle, last;
public:
NameType(string f = "", string m = "", string l = "")
setFirst(string f):void
setLast(string l):void
setMiddle(string m):void
getFirst():string
getLast():string
getMiddle():string
printName():void

*/
/*
UML
Class Manager
protected:
salary, taxes: double
title :string
public:
next: manager //pointer
Manager(double sal = 0.0, double tax = 0.0, string title = "")
getTaxes():double
getSalary():double
getTitle():string
setSalary(double sal):void
setTaxes(double tax):void
setTitle(string tit):void
printDetails():void
printManager():void
*/
/*
UML
Class Hourly_Emp
protected:
salary, taxes, pay_rate: double
hours: int
public:
next: Hourly_Emp //pointer
Hourly_Emp(double sal = 0.0, double tax = 0.0, int hours = 0, double pyrt = 0.0)
getTaxes():double
getSalary():double
getPayRate():double
getHours():int
setSalary(double sal):void
setTaxes(double tax):void
setPayRate(double pyrt):void
setHours(double hr):void
printDetails():void
printHourlyEmp():void
*/
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

class NameType{
protected:
	string first, middle, last;
public:
	NameType(string f = "", string m = "", string l = "")
	{
		first = f;
		middle = m;
		last = l;
	}
	void setFirst(string f)
	{
		first = f;
	}
	void setLast(string l)
	{
		last = l;
	}
	void setMiddle(string m)
	{
		middle = m;
	}
	string getFirst()
	{
		return first;
	}
	string getLast()
	{
		return last;
	}
	string getMiddle()
	{
		return middle;
	}
	void printName()
	{
		cout << first << ' ' << middle << ' ' << last << '\n';
	}
};
class Person :public NameType{
protected:
	string address;
	long Id;
public:
	Person(string ad = "", long id = 0)
	{
		address = ad;
		Id = id;
	}
	void setAddress(string ad)
	{
		address = ad;
	}
	void setId(long id)
	{
		Id = id;
	}
	string getAddress()
	{
		return address;
	}
	long getId()
	{
		return Id;
	}
	void printPerson()
	{
		printName();
		cout << address << '\n';
	}
};
class Hourly_Emp : public Person{
protected:
	double salary, taxes, pay_rate;
	int hours;
public:
	Hourly_Emp *next;
	Hourly_Emp(double sal = 0.0, double tax = 0.0, int hr = 0, double pyrt = 0.0)
	{
		salary = sal;
		taxes = tax;
		hours = hr;
		pay_rate = pyrt;
		next = NULL;
	}
	double getTaxes()
	{
		return taxes;
	}
	double getSalary()
	{
		return salary;
	}
	double getPayRate()
	{
		return pay_rate;
	}
	int getHours()
	{
		return hours;
	}
	void setSalary(double sal)
	{
		salary = sal;
	}
	void setTaxes(double tax)
	{
		taxes = tax;
	}
	void setHours(int hr)
	{
		hours = hr;
	}
	void setPayRate(double pyrt)
	{
		pay_rate = pyrt;
	}
	void printDetails()
	{
		printPerson();
		cout << Id << hours << ' ' << salary << ' ' << taxes << ' ' << pay_rate << "\n\n";
	}
	void printHourlyEmp()
	{
		cout << first << ' ' << middle << ' ' << last << ' ';
	}
};
class Manager :public Person{
protected:
	double salary, taxes;
	string title;

public:
	Manager *next;
	Manager(double sal = 0.0, double tax = 0.0, string tit = "")
	{
		salary = sal;
		taxes = tax;
		title = tit;
		next = NULL;
	}
	double getTaxes()
	{
		return taxes;
	}
	double getSalary()
	{
		return salary;
	}
	string getTitle()
	{
		return title;
	}
	void setSalary(double sal)
	{
		salary = sal;
	}
	void setTaxes(double tax)
	{
		taxes = tax;
	}
	void setTitle(string tit)
	{
		title = tit;
	}
	void printDetails()
	{
		printPerson();
		cout << salary << ' ' << taxes << ' ' << title << '\n';
	}
	void printManager()
	{
		cout << '\n' << setw(10) << left << first << setw(10) << left  << middle << setw(10) << left <<  last << setw(20) << left << title;
	}
};


void addEmployee(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	cout << "-Enter M for manager or H for hourly employee: ";
	char category;
	cin >> category;
	cout << "-Will the added employee have a middle name.(type 1 for yes and 0 for no): ";
	bool does;
	cin >> does;
	if (category == 'M')
	{
		string f, m, l, ad, tit;
		long id;
		double tax, sal;
		mt = new Manager;
		cout << "-Enter the employee's first: ";
		cin >> f;
		if (does)
		{
			cout << "-Enter a middle name: ";
			cin >> m;
		}
		cout << "-Enter a last name: ";
		cin.sync();
		getline(cin, l);
		cout << "-Enter a full address: ";
		getline(cin, ad);
		cout << "-Enter an employee's Id, salary, and taxes separately spaced :";
		cin >> id >> sal >> tax;
		cin.sync();
		cout << "-Enter the employee's title: ";
		getline(cin, tit);
		mt->setFirst(f);
		mt->setMiddle(m);
		mt->setLast(l);
		mt->setAddress(ad);
		mt->setId(id);
		mt->setSalary(sal);
		mt->setTaxes(tax);
		mt->setTitle(tit);
		mt->next = NULL;

		tm->next = mt;
		tm = mt;
		mt = hm;

	}
	else
	{
		string f, m, l, ad;
		long id;
		int hr;
		double tax, sal;
		ht = new Hourly_Emp;
		cout << "-Enter the employee's first: ";
		cin >> f;
		if (does)
		{
			cout << "-Enter a middle name: ";
			cin >> m;
		}
		cout << "-Enter a last name: ";
		cin.sync();
		getline(cin, l);
		cout << "-Enter a full address: ";
		getline(cin, ad);
		cout << "-Enter an employee's ID, hours, salary, and taxes separately spaced: ";
		cin >> id >> hr >> sal >> tax;
		ht->setFirst(f);
		ht->setMiddle(m);
		ht->setLast(l);
		ht->setAddress(ad);
		ht->setSalary(sal);
		ht->setTaxes(tax);
		ht->setHours(hr);
		ht->next = NULL;

		th->next = ht;
		th = ht;
		ht = hh;
	}
	cout << "A new employee has been added.\n";
	system("pause");
}

void printfunct(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	mt = hm;
	cout << setw(10) << left << setfill('*') << "first" << setw(10) << left << setfill('*') << "middle" << setw(10) << left << setfill('*') << "last" << setw(20) << left << "title" << ' ' << "salary" << setfill(' ');
	while (mt != NULL)
	{
		mt->printManager();
		cout << ' ' << mt->getSalary() << '\n';
		mt = mt->next;
	}
	mt = hm;
}

void print6(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	ht = hh;
	cout << setw(10) << left << setfill('*') << "first" << setw(10) << left << setfill('*') << "middle" << setw(10) << left << setfill('*') << "last" << ' ' << setfill(' ') << "salary\n";
	while (ht != NULL)
	{
		if (ht->next ==NULL)
		{
			break;
		}
		cout << setw(10) << left << ht->getFirst()
			<< setw(10) << left << ht->getMiddle()
			<< setw(10) << left << ht->getLast()
			<< ' ' << ht->getSalary() << '\n';

		ht = ht->next;
	}
	
	
	ht = hh;
}

void print7(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	mt = hm;
	cout << setw(10) << left << setfill('*') << "first" << setw(10) << left << setfill('*') << "middle" << setw(10) << left << setfill('*') << "last" << setw(20) << left << "title" << setfill(' ');
	while (mt != NULL)
	{
		mt->printManager();
		cout << '\n';
		mt = mt->next;
	}
	mt = hm;
}
void print8(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	ht = hh;
	while (ht != NULL)
	{
		if (ht->next == NULL)
		{
			break;
		}

		cout << ht->getFirst() << ' ' << ht->getMiddle() << ' ' << ht->getLast() << '\n'
			<< ht->getAddress() << '\n' << ht->getId() << ' ' << ht->getHours() << ' ' << ht->getPayRate() << ' ' << ht->getTaxes() << "\n\n";
		ht = ht->next;
	}
	ht = hh;
	system("pause");
}
void print9(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	mt = hm;
	while (mt != NULL)
	{
		mt->printDetails();
		cout << '\n';
		mt = mt->next;
	}
	system("pause");
	mt = hm;
}
void LinearSearchL(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	mt = hm;
	string last;
	bool i;
	while (true){
		cout << "-Enter 1 if you want to change " << mt->getLast() << "\'s last name if not enter 0 to move to the next employee: ";
		cin >> i;


		if (i)
		{
			cout << "-Enter the manager's new last name:";
			cin >> last;
			mt->setLast(last);
			cout << "Last name was changed.\n";
			system("pause");
			break;
		}
		if (mt->next == NULL)
		{
			cout << "There are no more managers.\n";
			system("pause");
			break;
		}
		mt = mt->next;
	}


	mt = hm;
}

void LinearSearchS(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	mt = hm;

	bool i;
	while (true){
		cout << "-Enter 1 if you want to change " << mt->getLast() << "\'s salary if not enter 0 to move to the next employee: ";
		cin >> i;



		if (i)
		{
			double sa;
			cout << "-Enter the manager's new salary.";
			cin >> sa;
			mt->setSalary(sa);
			cout << "Salary was changed.\n";
			system("pause");
			break;
		}
		if (mt->next == NULL)
		{
			cout << "There are no more managers.\n";
			system("pause");
			break;
		}
		mt = mt->next;
	}


	mt = hm;
}

void LinearSearchT(Hourly_Emp *hh, Hourly_Emp *th, Hourly_Emp *ht, Manager *hm, Manager *tm, Manager *mt)
{
	mt = hm;
	string tit;
	bool i;
	while (true){
		cout << "-Enter 1 if you want to change " << mt->getLast() << "\'s title if not enter 0 to move to the next employee: ";
		cin >> i;


		if (i)
		{

			cout << "-Enter the manager's new last name.";
			cin >> tit;
			mt->setTitle(tit);
			cout << "Last name was changed.\n";
			system("pause");
			break;
		}
		if (mt->next == NULL)
		{
			cout << "There are no more managers.\n";
			system("pause");
			break;
		}
		mt = mt->next;
	}


	mt = hm;
}


int main()
{
	cout << "Please enter a file name:";
	Hourly_Emp *hh = NULL, *th = NULL, *ht = NULL;
	Manager *hm = NULL, *tm = NULL, *mt = NULL;
	int choice = 0;
	string user_file;
	getline(cin, user_file);
	ifstream in(user_file);
	while (!in.is_open())
	{
		in.clear();
		in.close();
		cout << "File could not be opened, please try again:";
		getline(cin, user_file);
		in.open(user_file);
	}
	mt = new Manager;
	ht = new Hourly_Emp;
	hm = mt;
	hh = ht;
	bool onceM = false, onceH = false;
	string f, m, l, ad, tit;
	long id;
	double tax, sal;
	char category;
	while (in.peek() != EOF)
	{
		in >> category;

		if (category == 'M')
		{
			mt = new Manager;
			in >> f >> m;
			getline(in, l);
			getline(in, ad);
			in >> id >> sal >> tax;
			getline(in, tit);
			mt->setFirst(f);
			mt->setMiddle(m);
			mt->setLast(l);
			mt->setAddress(ad);
			mt->setId(id);
			mt->setSalary(sal);
			mt->setTaxes(tax);
			mt->setTitle(tit);
			mt->next = NULL;

			if (!onceM)
			{
				hm = mt;
				tm = hm;
			}
			else
			{
				tm->next = mt;
				tm = mt;
			}
			onceM = true;

		}
		else
		{
			string f, m, l, ad;
			long id;
			int hr;
			double tax, sal;
			ht = new Hourly_Emp;
			in >> f >> m;
			getline(in, l);
			getline(in, ad, '\n');
			in >> id >> hr >> sal >> tax;
			ht->setFirst(f);
			ht->setMiddle(m);
			ht->setLast(l);
			ht->setAddress(ad);
			ht->setId(id);
			ht->setSalary(sal);
			ht->setTaxes(tax);
			ht->setHours(hr);
			ht->next = NULL;
			if (!onceH)
			{
				hh = ht;
				th = ht;
			}
			else
			{
				th->next = ht;
				th = ht;
			}
			onceH = true;
		}
	}
	ht = hh;
	mt = hm;

	while (choice != 10)
	{
		cout << "**************Main Menu******************\n"
			<< "Enter the menu item of choice and press enter key.\n"
			<< "1. Add a Manager or hourly paid employee instance to the list(Read data from keyboard)\n"
			<< "2. Print name, title, and salary of all Manager to Console in a table format\n"
			<< "3. Change a Manager's last name\n"
			<< "4. Change a Manager's Salary\n"
			<< "5. Change a Manager's Title\n"
			<< "6. Print only hourly paid employees' names and Salaries to console in a table format\n"
			<< "7. Print only Managers' names and titles to console\n"
			<< "8. Print details of an hourly paid employee\n"
			<< "9. Print the details of a manager\n"
			<< "10. Exit: ";
		cin >> choice;
		if (choice == 1)
		{
			addEmployee(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 2)
		{
			printfunct(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 3)
		{
			LinearSearchL(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 4)
		{
			LinearSearchS(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 5)
		{
			LinearSearchT(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 6)
		{
			print6(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 7)
		{
			print7(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 8)
		{
			print8(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 9)
		{
			print9(hh, th, ht, hm, tm, mt);
		}
		else if (choice == 10){/*end of loop*/ }

		else
		{
			cout << "Menu option does not exist.\n";
		}
	}

	system("pause");
	return 0;
}