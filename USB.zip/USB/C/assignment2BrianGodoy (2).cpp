/*
Author: Brian Godoy
Date: 6-30-2015
Project: Assignment 2 Accumulation
Compiler: Visual Studio 2013
Operating System: Windows 7
*/

/*
Problem Description
Find the accumulation after n years from a deposited amount.

Data Input	
Input		data type		remarks
p			double			the initial deposit
r			double			get in percentage convert then to decimal
q			int				number of times compounding is done per year
n			int				number of years p is left in deposit
e			char			to exit program

Data Output
1. Total accumulation after n years (a)

Global Constants
None are required.

Analysis
The formula necessary is a=p*(1+r/q)^(n*q). r must be converted immediatly after receiving a value.
The formula in c++ is a=p*(pow(1+r/q,n*q))

Algorithm
1a. set formatting including precision 
1b. define p,r,q,n,a
1c. greet the user
2. ask for p
3. get p
4. ask for r in percentage
5. get and convert r to a decimal
6. ask for q
7. get q
8. ask for n
9. get n
9B a=p*(pow(1+r/q,n*q))
10. print "Your total accumulation $" a " for " n " years."
11. print a farewell and how to exit
*/

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main()
{
	cout << fixed << setprecision(2);
	char e;
	double p, a, r;
	int q, n;
	cout << "Hello and welcome to the accumulation calculator enter the following information to see how much money you accumulate over a certain number of years." << '\n';
	cout << "Enter how the amount of money you deposited [$xx.yy]:" << '\n';
	cin >> p;
	cout << "Enter your annual percentage rate [x.y%]:" << '\n';
	cin >> r;
	r = r / 100;
	cout << "Enter the number of times compounding is done per year [xx]:" << '\n';
	cin >> q;
	cout << "Enter the number of years you keep your deposit in for [xx]:" << '\n';
	cin >> n;
	a = p*(pow(1 + r / q, n*q));
	cout << "You would have accumulated $" << a << " after " << n << " years." << '\n';
	cout << "If you wish to exit press any number then enter, goodbye." << '\n';
	cin >> e;
}