#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	cout << fixed << setprecision(2);
	cout << "Welcome to the employee gross pay program.\n";
	string first, last, job_type;
	char employ, e;
	int id, job, years = 0, edu, base;
	double gross, job_, year, edu_;
	bool flag_employ = false, flag_job = false, flag_years = false, flag_edu = false;
	cout << "Enter your first name.";
	cin >> first;
	cout << "Enter your last name.";
	cin >> last;
	cout << "Enter your employee code for factory worker(S), office worker(O), or management(M).";
	cin >> employ;
	if (employ == 'S' || 'O' || 'M'){
		flag_employ = true;
	}
	if (employ == 'S'){
		base = 800;
		job_type = "Factory Worker";
	}
	else if (employ == 'O'){
		base = 1000;
		job_type = "Office Worker";
	}
	else {
		base = 1500;
		job_type = "Management";
	}
	cout << base;
	cout << "Enter your ID number.";
	cin >> id;
	cout << "Enter your job classification code [1,2, or 3].";
	cin >> job;
	if (job == 1 || 2 || 3){
		flag_job = true;
	}
	if (job == 1){
		double job_ = 0.05;
	}
	else if (job == 2){
		job_ = 0.1;
	}
	else {
		job_ = 0.2;
	}
	cout << job_;
	cout << "Enter the number of years you have been employed.";
	cin >> years;
	if (0 <= years <= 50){
		flag_years = true;
	}
	if (0 <= years <= 10){
		year = 0.05;
	}
	else {
		year = (years - 10) / 100.0 + .05;
	}
	cout << year;
	cout << "Enter your education code for high school (1), junior college (2), university (3), or graduate school (4).";
	cin >> edu;
	if (edu == 1 || 2 || 3 || 4){
		flag_edu = true;
	}
	if (edu == 1){
		edu_ = 0;
	}
	else if (edu == 2){
		edu_ = .05;
	}
	else if (edu == 3){
		edu_ = .12;
	}
	else {
		edu_ = .2;
	}
	cout << edu_;
	gross = (base + base*job_ + base*year + base*edu_);
	if (flag_employ = false){
		cout << "You have put an invalid employee code please enter M,O, or S.\n";
	}
	if (flag_job = false){
		cout << "You have put an job classification code please enter 1,2, or 3.\n";
	}
	if (flag_years = false){
		cout << "You have put an number of years please enter a whole number only.\n";
	}
	if (flag_edu = false){
		cout << "You have put an educational code please enter 1,2,3,or 4.\n";
	}
	cout << setw(15) << "Full Name" << setw(10) << "ID" << setw(15) << "Job Type" << setw(20) << "Gross Salary\n";
	cout << setw(15) << first << " " << last << setw(10) << id << setw(15) << job_type << setw(20) << gross;
	cin >> e;

	return 0;
}