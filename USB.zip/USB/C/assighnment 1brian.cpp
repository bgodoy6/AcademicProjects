/*
Author: Brian Godoy
Date:  6/23/2015
Project: BMR calculation project
Compiler: Visual Studio
Operating System: Windows 7
*/

/*Background knowledge:
1. Data types include double and int(integer).
2. To declare a variable you must assign it a value than ask the user for an input, constants must be assigned a value immediately right before the code has been written, and to initialize them you must combine them with other commands or operators.
3. For an output in decimal points you must send an input in decimal points to recieve the decimal point number the double data type is required.
4. First assign a variable as well as a data type so the user may input the data which will be stored as a variable.
5. If you input improper code the machine will output useless information.
6. This includes plus signs, asterisks, etc. which command a computer to preform a function.
7. The ALU processes arithmetical expressions.
8. They are errors usually caused by using punctuation incorrectly.
9. Sequential flow allows a computer to process the code from left to right, up to down. Processes in the sequential order of the code.
10. The output of a string.
11. A new source project must be created to use visual studio 2013.
12. You must find out what will be inputted, outputted and analyze how it will be done creating an approximate algorithm also helps.
*/

/*Problem Description:
Determine the amount of calories burned each day by the person.
The program will inform the user of the purpose of the program and then ask for
1.their height in feet
2.their weight in pounds
3.age in years (use int data type)
4.then asks to type a number based activity factor
Then the program will give advice based off the response telling them if they should burn more calories if their calorie intake exceeds their burned calories. Finally it gives a farewell to the user.

Input:
Variable name		Data Type		Remarks
Weight				double			User must know it should be in pounds
Height				double			User must know it should be in feet
Age					int				User must know it should not be in decimal form
Activity Factor		double			Values should be given to user first
calories burned		double			Will be given with an equation
e					char			to exit the program
Constants are required but they are already hard coded in the program, user enters variables.

Output:
All outputted numbers must have relevant variables.
1.Output calories burned each day
2.Health related reccomendations.

Analysis:
To compute calories burned you need BMR*ActivityFactor
BMR=66+6.2*weight+152.4*height-6.8*age
66,6.2,152.4,and 6.8 can be left as is or typed as a constant.
Total equation: (66+6.2*weight+152.4*height-6.8*age)*ActivityFactor=calories burned
Aproximate Algorithm:
1a. formatting flags must be set
1b. print greeting message
1c. define variables for height, weight, age, and activity factor.
2. tell user to input height in feet
3. get and store height in height variables
4. tell user to input weight in pounds
5. get and store weight in weight variable
6. tell user to input age in years
7. get and store age in age variable
8. tell user to input activity factor based off given values
9. get and store activity factor in activity factor variable
10. print �You burn" cal burned "calories every day. If your calorie intake per day is more than x you may wish to include more exercises in your daily life or you may cut down on your calorie intake."
11. print a farewell
*/

#include <iostream>
using namespace std;
/*
since constants won't be included I'll emulate it in the comments. const int a = 66,
const double b = 6.2, const double c = 152.4, const double d = 6.8
the new formula cal_burned = ((a + b * weight + c * height - d * age) * act_fact)
*/
int main()
{
	cout << "Welcome to the calorie burner counter by using this you will learn how many calories you burn and what you should do afterwards." << '\n'; 
	double weight; //in pounds
	double height; //in feet
	int age; //integer in years
	double act_fact; //gice the user a set of numbers
	double cal_burned;//output
	char e;//exit
	cout << "Please enter your weight in pounds [xx.yy]" << '\n';
	cin >> weight;
	cout << "Please enter your height in feet [xx.yy]" << '\n';
	cin >> height;
	cout << "Please enter your age in years [xx]" << '\n';
	cin >> age;
	cout << "Please enter one of the following numbers:" << '\n';
	cout << "1.2 if you get little to no exercise" << '\n';
	cout << "1.375 if you exercise 1 to 3 times a week" << '\n';
	cout << "1.55 if you exercise 3 to 5 times a week" << '\n';
	cout << "1.725 if you exercise 6 to 7 times a week" << '\n';
	cout << "1.9 if you exercise two times a day including a marathon, etc." << '\n';
	cin >> act_fact;
	cal_burned = ((66 + 6.2 * weight + 152.4 * height - 6.8 * age) * act_fact);
	cout << "You burn" << " " << cal_burned << "calories every day. If your calorie intake exceeds this you might want to consider eating less or more exercis. Press '0' then 'enter' to leave, goodbye."; 
	cin >> e;
}