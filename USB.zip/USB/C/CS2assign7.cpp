//Brian Godoy cs2 assign 7
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
	string x;
	cin << x;
	return 0;
}