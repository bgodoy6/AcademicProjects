/*
Brian Godoy
July 21, 2015
assignment 6 
windows 7
visual studios
*/

/*
Description
Determine an employees gross salary, the tax withheld, and net salary

input
variable		data type		remarks
first			string			first name
last			string			last name
hours			int				hours worked
pay_rate		double			money earned every hour
health_plan		bool			1 or 0 to enroll in health plan or not

computed variables
variable		data type		remarks
salary			double			
tax_withheld	double			.071*salary
net_salary		double			salary - .071*salary //round to cents
full			string			first + ' ' + last 
deduction		int				will either be $200 or $0

output
variable		
Greet the user and explain what the software does//cout
full					
hours			
pay_rate		
salary
tax_withheld
enrollment
deduction//in dollars [$]
net_salary
Goodbye to user and thank them for using software//cout

Analysis
-Gross Salary 
if (salary>40) then		(hours - 40) * 1.5 * rate + 40 * pay_rate		end if
else then		pay_rate * hours		end else
-Tax withheld
tax_withheld = salary*.071
-Net salary
net_salary = salary - salary* .071
if (net_salary>=200) then	cout<<Enter 1 to purchase health plan or 0 to decline; cin>>choice		end if
	if (healthplan) then		deduction=200; enrollment = You have been enrolled in health plan;	end if
	else then	deduction = 0; enrollment = You have not been enrolled in health plan;	end else
else then	deduction = 0; enrollment = you have been denied health plan enrollment;	end else
net_salary -= deduction

Algorithm
-Gross Salary (create function and set variables)
1.  ask for hours worked
1.1 recieve and store hours worked
1.2 ask for pay rate
1.3 receive and store pay rate
2.  if (salary>40) then		
	salary = (hours - 40) * 1.5 * pay_rate + 40 * pay_rate		
	end if
2.1 else then		
	salary = pay_rate * hours		
	end else
-Tax withheld (new function and new variables)
1.  tax_withheld = salary*.071
-Net salary (new function and new variables
net_salary = salary - salary* .071
if (net_salary>=200) then	cout<<Enter 1 to purchase health plan or 0 to decline; cin>>choice		end if
if (health_plan) then		deduction=200; enrollment = You have been enrolled in health plan;	end if
else then	deduction = 0; enrollment = You have not been enrolled in health plan;	end else
else then	deduction = 0; enrollment = you have been denied health plan enrollment;	end else
net_salary -= deduction

*/

#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
using namespace std;

void greeting();
double getUserData(double & pay_rate, string & first, string & last, bool & health_plan);
double getGrossSalery(double hours, double pay_rate);
double getTaxWithHeld(double salary);
double getNetSalary(double salary, double tax_withheld, bool health_plan);
void printResults(const string & first, const string & last, double hours, double pay_rate, double salary, double tax_withheld, double net_salary, bool health_plan);
void goodbye();

int main()
{
	for (size_t i = 0; i < 4; i++)
	{
		greeting();
		double pay_rate, hours, salary, tax_withheld, net_salary;
		string first, last;
		bool health_plan;
		hours = getUserData(pay_rate, first, last, health_plan);
		salary = getGrossSalery(hours, pay_rate);
		tax_withheld = getTaxWithHeld(salary);
		net_salary = getNetSalary(salary, tax_withheld, health_plan);
		printResults(first, last, hours, pay_rate, salary, tax_withheld, net_salary, health_plan);
		goodbye();
		system("pause");
	}
	return 0;
}

void greeting()
{
	cout << "--------------------------------------------------------------------\n";
	cout << "Welcome to the salary calculation program.\n";
	cout << "In this program we will ask for the information that would allow us to process your pay check.\n";
	cout << "We will collect information about hours worked, hourly ppay rate and medical options.\n";
	cout << "Processing will be completed in just few minutes.\n";
}

double getUserData(double & pay_rate, string & first, string & last, bool & health_plan)
{
	cout << "--------------------------------------------------------------------\n";
	cout << "Please enter your first name [One word only]:";
	cin >> first;
	cout << "Please enter your last name [One word only]:";
	cin >> last;
	cout << "Please enter hours worked [positive number only]:";
	double hours;
	cin >> hours;
	cout << "Please enter your hourly pay rate [for example enter 15.23 if your hourly pay rate is $15 and 23 cents]\n";
	cin >> pay_rate;
	cout << "Enter 1 to purchase a health plan or 0 (zero) to decline:";
	cin >> health_plan;
	return hours;
}

double getGrossSalery(double hours, double pay_rate)
{
	double salary;
	if (hours > 40)
	{
		salary = (hours - 40) * 1.5 * pay_rate + 40 * pay_rate;
	}
	else
	{
		salary = pay_rate * hours;
	}
	return salary;
}

double getTaxWithHeld(double salary)
{
	double tax_withheld;
	tax_withheld = salary * .071;
	return tax_withheld;
}

double getNetSalary(double salary, double tax_withheld, bool health_plan)
{
	double net_salary = salary - tax_withheld;
	/*if (net_salary >= 200)
	{
	if (health_plan)
	{
	net_salary -= 200;
	}
	else
	{
	net_salary -= 0;
	}
	}*/
	/*else
	{
	net_salary -= 0;
	}*/
	return net_salary;
}

void printResults(const string &first, const string & last, double hours, double pay_rate, double salary, double tax_withheld, double net_salary, bool health_plan)
{
	if (health_plan && net_salary < 200)
	{
		cout << "Employee salary is not enough to enroll in health plan.\n";
	}
	cout << "--------------------------------------------------------------------\n";
	cout << "Here are the Employee Payroll details.\n";
	string full = first + ' ' + last;
	cout << "Name:" << full << '\n';
	cout << fixed << showpoint << setprecision(2);
	cout << "Hours worked: " << hours << '\n';
	cout << "Hourly Pay Rate: $" << pay_rate << '\n';
	cout << "Gross Salary: $" << salary << '\n';
	cout << "Tax withheld: $" << tax_withheld << '\n';
	if (health_plan)
	{
		if (net_salary >= 200)
		{

			cout << "You have succesfully enrolled in a health plan.\n";
			cout << "The cost of health plan: $200\n";
			cout << "Employee net salary: $" << (net_salary - 200) << '\n';
		}
		else
		{
			cout << "You have been denied out of a health plan.\n";
			cout << "Employee net salary: $" << net_salary << '\n';
		}
	}
	else
	{
		cout << "You have succesfully opted out of a health plan.\n";
		cout << "Employee net salary: $" << net_salary << '\n';
	}
}

void goodbye()
{
	cout << "--------------------------------------------------------------------\n";
	cout << "Thank you for using our program.\n";
	cout << "Please have a pleasant day.\n";
}