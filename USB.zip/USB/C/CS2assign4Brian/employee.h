#ifndef _employee_H_
#define _employee_H_
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class employee {
private:
	string First, Last, Name;
	char Status;
	double Income;
public:
	employee *next = NULL;
	employee()
	{
		First = "";
		Last = "";
		Status = ' ';
		Income = 0.0;
		Name = First + ' ' + Last;
	}

	employee(string first, string last, char stat, double income)
	{
		First = first;
		Last = last;
		Status = stat;
		Income = income;
	}
	double getTax()
	{
		if (Status == 's' || Status == 'S')
		{
			if (Income > 28790)
			{
				return 1449.6 + 0.11*(Income - 28790);
			}
			else if (Income > 20930)
			{
				return 742.4 + 0.08*(Income - 20930);
			}
			else if (Income > 1710)
			{
				return 87 + 0.03*(Income - 1710);
			}
			else
			{
				return 0.00;
			}
		}
		else
		{
			if (Income > 28790)
			{
				return 2899.2 + 0.11*(Income - 57580);
			}
			else if (Income > 20930)
			{
				return 1905.4 + 0.09*(Income - 47120);
			}
			else if (Income > 1710)
			{
				return 330 + 0.04*(Income - 3420);
			}
			else
			{
				return 0.00;
			}
		}
	}

	void setFirst(string first)
	{
		First = first;
	}

	void setLast(string last)
	{
		Last = last;
	}

	void setStat(char stat)
	{
		Status = stat;
	}

	void setIncome(double income)
	{
		Income = income;
	}
	string getIName()
	{
		return Last + ',' + First;
	}
	string getName()
	{
		return First + ' ' + Last;
	}
	string getFirst()
	{
		return First;
	}

	string getLast()
	{
		return Last;
	}

	char getStat()
	{
		return Status;
	}

	double getIncome()
	{
		return Income;
	}

	void printSingle()
	{
		cout << setw(20) << left << getIName() << setw(10) << left;
		if (getStat() == 's' || getStat() == 'S')
		{
			cout << "Single";
		}
		else if (getStat() == 'j' || getStat() == 'J')
		{
			cout << "Joint";
		}
		else{
			cout << getStat();
		}
		if (getStat() == 's' || getStat() == 'j' || getStat() == 'S' || getStat() == 'J')
		{
			if (getIncome() < 0.0)
			{
				cout << "Negative salary is invalid\n";
			}
			else{
				cout << fixed << showpoint << setprecision(2);
				cout << right << '$' << setw(15) << left << getIncome() << right << '$' << setw(10) << left << getTax() << right << '$' << getIncome() - getTax() << '\n';
			}
		}
		else {
			cout << "is invalid input\n";
		}
	}
};

#endif