/*
Brian Godoy
csci-2-0149
*/
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

struct Fractions{
	int num1, num2, den1, den2, whole, x, y, temp, tempx, tempy;
	Fractions()
	{
		num1 = 1;
		num2 = 1;
		den1 = 1;
		den2 = 1;
		whole = 0;
	}

	Fractions(int n1, int n2, int d1, int d2, int wh)
	{
		num1 = n1;
		num2 = n2;
		den1 = d1;
		den2 = d2;
		whole = wh;
	}

	void inverse()
	{
		temp = num1;
		num1 = den1;
		den1 = num1;
		temp = num2;
		num2 = den2;
		den2 = num2;
	}

	void read()
	{
		cout << "Enter a numerator and denominator seperated by a space: ";
		cin >> num1 >> den1;
		if (den1 == 0)
		{
			den1 = 1;
			cout << "WARNING! Zero denom! 1 is used instead.\n";
		}
		cout << "Enter a numerator and denominator seperated by a space: ";
		cin >> num2 >> den2;
		if (den2 == 0)
		{
			den2 = 1;
			cout << "WARNING! Zero denom! 1 is used instead.\n";
		}
		print();
		cout << num1 << '/' << den1 << " = " << num1 << '/' << den1 << '\n';
		cout << "Enter a whole number: ";
		cin >> whole;
		print(whole);
	}

	void print()
	{
		cout << '\n' << num1 << '/' << den1 << " + " << num2 << '/' << den2 << " = ";
		x = num1*den2 + num2*den1;
		y = den1*den2;
		tempx = x;
		tempy = y;
		calculate();
		cout << num1 << '/' << den1 << " - " << num2 << '/' << den2 << " = ";
		x = num1*den2 - num2*den1;
		y = den1*den2;
		tempx = x;
		tempy = y;
		calculate();
		cout << num1 << '/' << den1 << " * " << num2 << '/' << den2 << " = ";// x and y are not necessary but it's convenient
		x = num1*num2;
		y = den1*den2;
		tempx = x;
		tempy = y;
		calculate();
		cout << num1 << '/' << den1 << " / " << num2 << '/' << den2 << " = ";
		x = num1*den2;
		y = den1*num2;
		if (y == 0 && x == 0)
		{
			cout << 1 << '/' << 1 << '\n';
		}
		else if (y == 0)
		{
			x = den1*num2;
			y = num1*den2;
			tempx = x;
			tempy = y;
			calculate();
		}
		else
		{
			tempx = x;
			tempy = y;
			calculate();
		}
	}

	void print(int whole)
	{
		num2 = num1;
		den2 = den1;
		num1 = whole;
		den1 = 1;
		cout << '\n' << num1 << " + " << num2 << '/' << den2 << " = ";
		x = num1*den2 + num2*den1;
		y = den1*den2;
		tempx = x;
		tempy = y;
		calculate();
		cout << num1 << " - " << num2 << '/' << den2 << " = ";
		x = num1*den2 - num2*den1;
		y = den1*den2;
		tempx = x;
		tempy = y;
		calculate();
		cout << num1 << " * " << num2 << '/' << den2 << " = ";// x and y are not necessary but it's convenient
		x = num1*num2;
		y = den1*den2;
		tempx = x;
		tempy = y;
		calculate();
		cout << num1 << " / " << num2 << '/' << den2 << " = ";
		x = num1*den2;
		y = den1*num2;
		if (y == 0 && x == 0)
		{
			cout << 1 << '/' << 1 << '\n';
		}
		else if (y == 0)
		{
			x = den1*num2;
			y = num1*den2;
			tempx = x;
			tempy = y;
			calculate();
		}
		else
		{
			tempx = x;
			tempy = y;
			calculate();
		}
	}

	void calculate()
	{
		if (x == 0)
		{
			cout << 0 << '/' << 1 << '\n';
		}
		else if (x < 0)
		{
			x *= -1;
			if (x > y && x%y != 0)
			{
				tempx *= -1;
				while (tempx > tempy)
				{
					temp = tempx;
					tempx = tempy;
					tempy = temp%tempy;
					if (tempy == 1)
					{
						x *= -1;
						cout << x << '/' << y << '\n';
						break;
					}
					else if (tempy == 0)
					{
						x /= temp;
						y /= temp;
						x *= -1;
						cout << x << '/' << y << '\n';
						break;
					}
					else if (x / y == x%y)
					{
						x *= -1;
						cout << x << '/' << y << '\n';
						break;
					}
					else {
					}
				}
			}
			else if (x == y)
			{
				cout << 1 << '/' << 1 << '\n';
			}
			else
			{
				y /= tempx;
				x /= tempx;
				cout << x << '/' << y << '\n';
			}
		}
		else if (x < y && y%x == 0)
		{
			y /= tempx;
			x /= tempx;
			cout << x << '/' << y << '\n';
		}
		else if (x < y)
		{
			cout << x << '/' << y << '\n';
		}
		else if (x > y)
		{
			while (tempx > tempy)
			{
				temp = tempx;
				tempx = tempy;
				tempy = temp%tempy;
				if (tempy == 1)
				{
					cout << x << '/' << y << '\n';
					break;
				}
				else if (tempy == 0)
				{
					cout << temp << ' ';
					x /= temp;
					y /= temp;
					cout << x << '/' << y << '\n';
					break;
				}
				else if (x%tempy == 0 && y%tempy == 0)
				{
					x /= tempy;
					y /= tempy;
					cout << x << '/' << y << '\n';
					break;
				}
				else {
				}
			}
		}
		else
		{
			cout << 1 << '/' << 1 << '\n';
		}
	}
};

int main()
{
	Fractions fract;

	fract.read();

	//system("pause");
	return 0;
}
