/*
Brian Godoy
8/3/2015
Assignment 9 struct
Visual Studio 2013
Windows 7
*/

#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
using namespace std;

struct BankAccount
{
	int ActNum;
	string LastName, FirstName;
	double balance;

	BankAccount()
	{
		balance = 0.0;
		ActNum = 0;
	}

	BankAccount(int act, string first, string last, double bal)
	{
		ActNum = act;
		LastName = last;
		FirstName = first;
		balance = bal;
	}

	void print()
	{
		cout << fixed << showpoint << setprecision(2);
		cout << "The person's name: " << FirstName << ' ' << LastName << '\n'
			<< "Person's account number: " << ActNum << '\n'
			<< "Person's current balance: $" << balance << endl;
	}

	int getAccountNumber()
	{
		return ActNum;
	}

	double getBalance()
	{
		return balance;
	}

	string getFirstName()
	{
		return FirstName;
	}

	string getLastName()
	{
		return LastName;
	}

	string getFullName()
	{
		return FirstName + ' ' + LastName;
	}

	void setLastName(string newLastName)
	{
		LastName = newLastName;
	}

	void deposit(double money)
	{
		balance += money;
	}

	void withdrawal(double money)
	{
		if (money <= balance)
		{
			balance -= money;
		}
		else
		{
			cout << "You have insufficient funds." << '\n';
		}
	}

	void print(ofstream & out)
	{
		out << fixed << showpoint << setprecision(2);
		out << "The person's name: " << FirstName << ' ' << LastName << '\n'
			<< "Person's account number: " << ActNum << '\n'
			<< "Person's current balance: $" << balance << endl;
	}
};

int main()
{
	cout << fixed << showpoint << setprecision(2);
	bool done = false;
	BankAccount acc;

	while (!done)
	{
		cout << "Type a menu choice and then press enter key.\n"
			<< "1. Create an instance of Bank Account from keyboard data entry.\n"
			<< "2. Print the details of Bank Account instance to console.\n"
			<< "3. Print details of Bank Account instance to an output file. Under this item an output file name will be asked, the ofstream object will be bonded to this file name, and BankAccount object details will be written to the file, and file will be closed.\n"
			<< "4. Make a deposit.\n"
			<< "5. Make a withdrawal.\n"
			<< "6. Print current balance to console.\n"
			<< "7. Print account holder's full name.\n"
			<< "8. Exit" << endl;
		int choice;
		cin >> choice;

		if (choice == 1)
		{
			string first, last;
			int act;
			double bal;
			cout << "Enter person's first name: ";
			cin >> first;
			cout << "Enter person's last name: ";
			cin >> last;
			cout << "Enter person's balance: ";
			cin >> bal;
			cout << "Enter person's account number: ";
			cin >> act;
			acc = BankAccount(act, first, last, bal);
		}
		else if (choice == 2)
		{
			acc.print();
		}
		else if (choice == 3)//incomplete
		{
			string outPutFile;
			cout << "Enter a file path: ";
			cin.sync();
			getline(cin, outPutFile);
			ofstream outFile(outPutFile);


			if (!outFile.is_open())
			{
				cout << "Failed to open input File.\n";
				continue;
			}//Must do file opening validation
			acc.print(outFile);
			outFile.close();//must close file
		}
		else if (choice == 4)
		{
			double deposit;
			cout << "Type the amount you want to deposit: ";
			cin >> deposit;
			acc.deposit(deposit);
		}
		else if (choice == 5)
		{
			double withdraw;
			cout << "Type the amount you want to withraw: ";
			cin >> withdraw;
			acc.withdrawal(withdraw);
		}
		else if (choice == 6)
		{
			double balance = acc.getBalance();
			cout << "Your balance is: $" << balance << '\n';
		}
		else if (choice == 7)
		{
			string full_name = acc.getFullName();
			cout << "The account holders full name is: " << full_name << '\n';
		}
		else if (choice == 8)
		{
			done = true;
		}
	}
	system("pause");
	return 0;
}