#include <iostream>
#include <string>
using namespace std;
//Brian Godoy  CS2
/*
UML
class Stack
private:
top: int 
items[100]: char
public:
isEmpty():bool
isFull():bool
push(char newItem): void
Top():char
pop():char
Stack()
*/
/*
UML
class Stack
private:
front, rear, numI: int
items[100]: char
public:
isEmpty():bool
isFull():bool
enqueue(char newItem): void
dequeue():char
Queue()
*/
class Stack
{
private:
	int top;
	char items[100];
public:
	bool isEmpty() 
	{
		return (top == -1);
	}
	bool isFull()
	{
		return (top == 99);
	}
	void push(char newItem)
	{
		if (isFull())
		{
			cout << "The stack is full. The item is not added.\n";
			return;
		}
		else
		{
			top++;
			items[top] = newItem;
		}
	}
	
	char Top()
	{
		if (isEmpty())
		{
			cout << "The stack is empty. Returned value not reliable.\n";
		}
		else
		{
			return items[top];
		}
	}
	char pop()
	{
		if (isEmpty())
		{
			cout << "The stack is empty.\n";
		}
		else
		{
			char temp = Top();
			top--;
			return temp;
		}
	}
	Stack()
	{
		top = -1;
	}
};

class Queue{
private:
	char items[100];
	int front, rear, numI;
public:
	Queue()
	{
		rear = -1;
		front = 0;
		numI = 0;
	}
	bool isFull()
	{
		return (numI == 100);
	}
	bool isEmpty()
	{
		return (numI == 0);
	}
	void enqueue(char newItem)
	{
		if (isFull())
		{
			cout << "The queue is full so the item was not added.\n";
			return;
		}
		else
		{
			rear = (rear + 1) % 100;
			items[rear] = newItem;
			numI++;
		}
	}
	char dequeue()
	{
		if (isEmpty())
		{
			cout << "The queue is empty so the item was not removed.\n";
		}
		else
		{
			char temp = items[front];
			front = (front + 1) % 100;
			numI--;
			return temp;
		}
	}
};

int convertAndCopy(const string &orig, char copy[], const int &size)
{
	int i = 0, j = 0;
	while (i<size)
	{
		if (toupper(orig[i]) >= 'A' || toupper(orig[i]) >= 'Z')
		{
			copy[j] = toupper(orig[i]);
			j++;
		}
		i++;
	}
	return j;
}

void transfer(Stack &s, Queue &q, const char c[], const int &size)
{
	int i = 0;
	while (i < size)
	{
		
		q.enqueue(c[i]);
		s.push(c[i]);
		i++;
	}
}

bool testComparison(Stack &s, Queue &q, const int &size)
{
	int i = 0;
	while (i < size && s.pop() == q.dequeue())
	{
		i++;
	}
	if (i == size)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int main()
{
	int numS = 0, i = 0;
	bool isPalindrome;
	cout << "Welcome to the palindrome testing program.\n\n"
		<< "How many strings do you wish to test: ";
	cin >> numS;
	cout << "\nEnter the test strings, press enter after each one:\n\n";
	cin.sync();
	while (i < numS)
	{
		isPalindrome = false;
		string phrase;
		char pureForm[100];
		getline(cin, phrase);
		int phL = phrase.length(), puL;
		puL = convertAndCopy(phrase, pureForm, phL);
		Stack s;
		Queue q;
		transfer(s, q, pureForm, puL);//a
		isPalindrome = testComparison(s, q, puL);
		cout << "\n\t\t" << phrase << "\n\t\t";
		if (isPalindrome)
		{
			cout << "**  IS  a  palindrome  **";
		}
		else
		{
			cout << "**  Is  NOT  a  palindrome  **";
		}
		cout << "\n\n";
		i++;
	}
	cout << "Thanks for the exercise!!\n";
	
	
	
	system("pause");
	return 0;
}