/*
Brian Godoy
8/3/2015
Assignment 8 Array and struct
Visual Studio 2013
Windows 7
*/

/*
Input:
Variable		Data Type		Remarks
input			ifstream		confirmation
in				ifstream		questions/answerkey
len				int				must be recieved by "return" from fillanswer then by fillresponse
struct:
qz[]			Quiz
question		string			stores from file
answer			char			answers
response		char

Computed:
score			int
message			string			"answers/questions"

Output:
questions[]
score
max
response[]
answers[]


Algorithm:
-STRUCT Quiz
1. set question, answer and response data
-void openFile
1.bool done = false
2.string in_file
3.while(!done)then
	3.1 clear input
	3.2 ask for file
	3.3 print file name
	3.4 open in_file
	3.5 if(input.fail()) then
		3.51 print file doesn't exist
		3.52 end if
	3.6 else then
		3.61 input peek
		3.62 if (inputeof())
			3.621 print there is no data
			3.622 close input
			3.623 end if
		3.63 else then
			3.631 done = true
			3.632 end else
		3.64 end else
	3.7 end while
4.print in_file was opened
-int fillQuestionsArray
1. int i=0
2. while(in.peek() != EOF && i< max)then
	2.1 getline (in, questions[i], '$')
	2.2 i++
	2.3 end while
3. return 0
-int fillAnswerKeyArray
1. int i=0
2. while(in.peek() != EOF && i< max)then
2.1 getline (in, answers[i], '$')
2.2 i++
2.3 end while
3. return i
-void fillResponseArray
1. ask for answers and print options
2. for(int i=0; i<len ; i++)
	2.1 print questions[i]
	2.2 get toupper(response[i])
	2.3 end loop
-int GradeResponses
1. int score=0
2. for(int i=0; i<len; i++)then
	2.1 if(answers[i] ==response[i]) then
		2.11 score++
		2.12 end if
	2.2 end loop
3. print score out of max
	3.1 if (score>= )then
		3.11 print you passed
		3.12 end if
	3.2 else
		3.21 print you failed and review is needed
	3.3 print score and incorrect response
4. return score
-void printAnswersAndResponses
1. print we will give summary of questions
2. for (int i=0; i<len; i++) then
	2.1 print question[i]
	2.2 print answers[i]
	2.3 print response[i]
	2.4 if(answers[i] == response[i]) then
		2.41 print you got it right
		2.42 end if
	2.5 else
		2.51 print wrong
		2.52 end else
	2.6 system pause
	2.7 end loop
-int main
1. initialize and set data types for necessary variables
2. openfile
3. fillquestions
4. close
5. open file
6. fillanswerkey and return i to len
7. fill reponse
8. graderesponses and return score
9. printanswersandresponses
*/

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;

const int max = 20;
struct Quiz
{
	string question;
	char answer;
	char response;
};
void openInputFile(ifstream & input, const string & message);
int fillQuestions(Quiz qz[], ifstream & in);
int fillAnswerKeys(Quiz qz[], ifstream & inA);
void fillResponses(Quiz qz[], int len);
int gradeResponses(const Quiz qz[], int len);
void printAnswersAndResponses(const Quiz qz[], int len);

int main()
{
	ifstream in;
	Quiz qz[max];
	cout << "Welcome to the driving test.\n";
	openInputFile(in, "questions");
	fillQuestions(qz, in);
	in.close();
	openInputFile(in, "answers");
	int len = fillAnswerKeys(qz, in);
	fillResponses(qz, len);
	int score = gradeResponses(qz, len);
	printAnswersAndResponses(qz, len);
	return 0;
}

void openInputFile(ifstream & input, const string & message)
{
	bool done = false;
	string in_file;
	while (!done)
	{
		input.clear();
		cout << "Please input the name of the data file with " << message << " to be read: ";
		getline(cin, in_file);
		cout << "The file name entered is : " << in_file << '\n';
		ifstream input(in_file);
		if (!input.is_open())
		{
			cout << "The file " << in_file << " does not exist.\n";
		}
		else
		{
			if (input.peek() != EOF)
			{
				done = true;
			}
			else
			{
				cout << "The file has no data in it\n";
				input.close();
			}
		}
	}
	cout << "File " << in_file << " opened and has data in it.\n";
	input.open(in_file);
}

int fillQuestions(Quiz qz[], ifstream & in)
{
	int i = 0;
	while (in.peek() != EOF && i < max)
	{
		getline(in, qz[i++].question, '$');
	}
	return 0;
}

int fillAnswerKeys(Quiz qz[], ifstream & inA)
{
	int i = 0;
	while (inA.peek() != EOF && i < max)
	{
		inA >> qz[i++].answer;
	}
	return i;
}

void fillResponses(Quiz qz[], int len)
{
	cout << setw(5) << "***Driver's License Practice Exam***\n" << "Please answer the questions as asked. Questions are multiple choice.\n" << "Enter correct letter response out of A,B,C, or D.\n";
	for (int i = 0; i < len; i++)
	{
		cout << qz[i].question << '\n' << '\n';
		cout << "Please choose your answer : ";
		cin >> qz[i].response;
		qz[i].response = toupper(qz[i].response);
		if (qz[i].response != 'A' && qz[i].response != 'B' && qz[i].response != 'C' && qz[i].response != 'D')
		{
			cout << "The answer you chose was invalid please type A,B,C, or D only.";
			i--;
		}
		cout << '\n' << '\n';
	}
}

int gradeResponses(const Quiz qz[], int len)
{
	int score = 0;
	for (int i = 0; i < len; i++)
	{
		if (qz[i].answer == qz[i].response)
		{
			score++;
		}
	}
	cout << "You scored " << score << " points out of total 20 points.\n";
	if (score >= 14)
	{
		cout << "You passed.\n";
	}
	else
	{
		cout << "You failed. Please review your answers.\n";
	}
	cout << "Total answered correctly: " << score << '\n';
	cout << "Total answered incorrectly: " << (max - score) << '\n' << '\n';
	return score;
}

void printAnswersAndResponses(const Quiz qz[], int len)
{
	cout << "Now we will give summary of all questions, answers and your responses.\n";
	for (int i = 0; i < len; i++)
	{
		cout << qz[i].question;
		cout << '\n' << '\n' << "Correct answer = " << qz[i].answer << '\n';
		cout << "Your answer = " << qz[i].response << '\n';
		if (qz[i].answer == qz[i].response)
		{
			cout << "You got this question right." << '\n';
		}
		else
		{
			cout << "You got this question wrong." << '\n';
		}
		system("pause");
		cout << '\n' << '\n';
	}
}