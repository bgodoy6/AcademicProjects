/*
Brian Godoy
cs2
*/
/*
UML
class employee
private:
string First, Last, Name
double Income
char Status
public:
employee *next 
employee()
employee(string first, string last, char stat, double income)
setFirst(string first):void 
setLast(string last):void
setStat(char stat):void 
setIncome(double income):void 
getIName():string 
getName():string 
getFirst():string 
getLast():string 
getStat():char 
getIncome():double 
printSingle():void
*/

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>

using namespace std;

class employee {
private:
	string First, Last, Name;
	char Status;
	double Income;
public:
	employee *next = NULL;
	employee()
	{
		First = "";
		Last = "";
		Status = ' ';
		Income = 0.0;
		Name = First + ' ' + Last;
	}

	employee(string first, string last, char stat, double income)
	{
		First = first;
		Last = last;
		Status = stat;
		Income = income;
	}
	double getTax()
	{
		if (Status == 's' || Status == 'S')
		{
			if (Income > 28790)
			{
				return 1449.6 + 0.11*(Income - 28790);
			}
			else if (Income > 20930)
			{
				return 742.4 + 0.08*(Income - 20930);
			}
			else if (Income > 1710)
			{
				return 87 + 0.03*(Income - 1710);
			}
			else
			{
				return 0.00;
			}
		}
		else
		{
			if (Income > 28790)
			{
				return 2899.2 + 0.11*(Income - 57580);
			}
			else if (Income > 20930)
			{
				return 1905.4 + 0.09*(Income - 47120);
			}
			else if (Income > 1710)
			{
				return 330 + 0.04*(Income - 3420);
			}
			else
			{
				return 0.00;
			}
		}
	}

	void setFirst(string first)
	{
		First = first;
	}

	void setLast(string last)
	{
		Last = last;
	}

	void setStat(char stat)
	{
		Status = stat;
	}

	void setIncome(double income)
	{
		Income = income;
	}
	string getIName()
	{
		return Last + ',' + First;
	}
	string getName()
	{
		return First + ' ' + Last;
	}
	string getFirst()
	{
		return First;
	}

	string getLast()
	{
		return Last;
	}

	char getStat()
	{
		return Status;
	}

	double getIncome()
	{
		return Income;
	}
	
	void printSingle()
	{
		cout << setw(20) << left << getIName() << setw(10) << left;
		if (getStat() == 's' || getStat() == 'S')
		{
			cout << "Single";
		}
		else if (getStat() == 'j' || getStat() == 'J')
		{
			cout << "Joint";
		}
		else{
			cout << getStat();
		}
		if (getStat() == 's' || getStat() == 'j' || getStat() == 'S' || getStat() == 'J')
		{
			if (getIncome() < 0.0)
			{
				cout << "Negative salary is invalid\n";
			}
			else{
				cout << fixed << showpoint << setprecision(2);
				cout << right << '$' << setw(15) << left << getIncome() << right << '$' << setw(10) << left << getTax() << right << '$' << getIncome() - getTax() << '\n';
			}
		}
		else {
			cout << "is invalid input\n";
		}
	}
};

void printFile(ofstream &out, employee *ce, employee he)
{
	out << setw(20) << left << "Name" << setw(10) << left << "Status" << setw(15) << left << "Gross Salary" << setw(10) << left << "Taxes" << "Net Salary" << '\n';
		
	out << "--------------------------------------------------------------------------------\n";
	int aveamount = 0;
	double totInc = 0.0, tottax = 0.0, totnet = 0.0;
	while (ce != NULL)
	{
		out << setw(20) << left << ce->getName() << setw(10) << left;
		if (ce->getStat() == 's' || ce->getStat() == 'S')
		{
			out << "Single";
		}
		else if (ce->getStat() == 'j' || ce->getStat() == 'J')
		{
			out << "Joint";
		}
		else
		{
			out << ce->getStat();
		}
		if (ce->getStat() == 's' || ce->getStat() == 'j' || ce->getStat() == 'S' || ce->getStat() == 'J')
		{
			if (ce->getIncome() < 0.0)
			{
				out << "Negative salary is invalid\n";
			}
			else
			{
				aveamount++;
				out << fixed << showpoint << setprecision(2);
				out << right << '$' << setw(15) << left << ce->getIncome() << right << '$' << setw(10) << left << ce->getTax() << right << '$' << ce->getIncome() - ce->getTax() << '\n';
				totInc += ce->getIncome();
				tottax += ce->getTax();
				totnet += (ce->getIncome() - ce->getTax());
			}
		}
		else 
		{
			out << "is invalid input\n";
		}
		ce = ce->next;
		}
	out << '\n' << setw(30) << left << "Averages" << right << '$' << setw(15) << left << totInc / aveamount << right << '$' << setw(10) << left << tottax / aveamount << right << '$' << totnet / aveamount << "\n\n";
	ce = he.next;
}
void outputFile(employee *ce, employee he)
{
	cout << "Enter a file path: ";
	cin.sync();
	string outFile;
	getline(cin, outFile);
	ofstream out(outFile);
	while (!out.is_open())
	{
		out.clear();
		out.close();
		cout << "Failed to open output file please try again:\n";
		getline(cin, outFile);
		out.open(outFile);
	}//Must do file opening validation
	printFile(out, ce, he);
}

void readfile(employee *he, employee *te, employee *ce)
{
	cout << "Enter a file path: ";
	string user_file;
	getline(cin, user_file);
	ifstream in(user_file);
	while (!in.is_open())
	{
		in.clear();
		in.close();
		cout << "File could not be opened, please try again:";
		getline(cin, user_file);
		in.open(user_file);
	}
	bool once = false;
	string f, l;
	char st;
	double inc;
	while (in.peek() != EOF)
	{
		ce = new employee;
		in >> f >> l >> st >> inc;
		ce->setFirst(f);
		ce->setLast(l);
		ce->setStat(st);
		ce->setIncome(inc);
		ce->next = NULL;
		if (!once)
		{
			he = ce;
			once = true;
		}
		else
		{
			te->next = ce;
		}
		te = ce;
	}
	ce = he;
}
/*
employee deleteEmployee(employee *he, employee *te, employee *ce, employee *pe)
{
	if (ce == he)
	{
		he = he->next;
	}
	else
	{
		while (pe->next != ce)
		{
			pe = pe->next;
		}
		if (te == ce)
		{
			te = pe;
			te->next = NULL;
		}
		else 
		{
			pe->next = ce->next;
		}
	}
	ce->next = NULL;
	cout << ce->getLast() << " was succesfully deleted.\n";
	delete ce;
	pe = ce = he;	
}*/

void linkedSearch(employee he, employee *te, employee *ce, employee *pe, string search, bool lPrint)
{
	ce = he.next;
	while (ce != NULL && search != ce->getLast())
	{
		ce = ce->next;
	}
	if (ce == NULL)
	{
		cout << "Employee, " << search << " doesn't exist.\n";
		ce = he.next;
		return;
	}
	if (lPrint)
	{
		cout << setw(20) << left << "Name" << setw(10) << left << "Status" << setw(15) << left << "Gross Salary" << setw(10) << left << "Taxes" << "Net Salary" << '\n';//<< setw(60) << left << setfill('-') << '\n';
		cout << "================================================================================\n";
		ce->printSingle();
		ce = he.next;
	}
	else
	{
		if (ce == he.next)
		{
			he.next = ce->next;
		}
		else
		{
			while (pe->next != ce)
			{
				pe = pe->next;
			}
			if (te == ce)
			{
				te = pe;
				te->next = NULL;
			}
			else
			{
				pe->next = ce->next;
			}
		}
		ce->next = NULL;
		cout << ce->getLast() << " was succesfully deleted.\n";
		delete ce;
	}
}

void addNewEmployee(employee he, employee *te, employee *ce)
{
	string f, l;
	double inc;
	char st;
	ce = new employee;
	cout << "Enter the first name, last name, status, and Income.(equally spaced): ";
	cin >> f >> l >> st >> inc;
	ce->setFirst(f);
	ce->setLast(l);
	ce->setStat(st);
	ce->setIncome(inc);
	te->next = ce;
	te = ce;
	ce = he.next;
	cout << "New employee was succesfully added.\n";
}


int main()
{
	employee he, *te = NULL, *ce = NULL, *pe = NULL;
	cout << "Enter a file path: ";
	string user_file;
	getline(cin, user_file);
	ifstream in(user_file);
	while (!in.is_open())
	{
		in.clear();
		in.close();
		cout << "File could not be opened, please try again:";
		getline(cin, user_file);
		in.open(user_file);
	}
	bool once = false;
	string f, l;
	char st;
	double inc;
	while (in.peek() != EOF)
	{
		ce = new employee;
		in >> f >> l >> st >> inc;
		ce->setFirst(f);
		ce->setLast(l);
		ce->setStat(st);
		ce->setIncome(inc);
		ce->next = NULL;
		if (!once)
		{
			he.next = ce;
			once = true;
		}
		else
		{
			te->next = ce;
		}
		te = ce;
	}
	ce = he.next;
	pe = &he;
	char choice = NULL;
	while (choice != 'f')
	{
		cout << "Enter a menu letter.\n"
			<< "a. Print employees' info to a file.\n"
			<< "b. Print employees' info to monitor.\n"
			<< "c. Search and print an employee's info by lastname.\n"
			<< "d. Add a new employee to the list.\n"
			<< "e. Delete an employee from the list.(User will be asked for last name)\n"
			<< "f. Exit:";
		cin >> choice;
		if (choice == 'a')
		{
			ce = he.next;
			outputFile(ce, he);
			cout << "File output succesful.\n";
		}
		else if (choice == 'b')
		{
			ce = he.next;
			cout << setw(20) << left << "Name" << setw(10) << left << "Status" << setw(15) << left << "Gross Salary" << setw(10) << left << "Taxes" << "Net Salary" << '\n';//<< setw(60) << left << setfill('-') << '\n';
			cout << "================================================================================\n";
			while (ce != NULL)
			{
				ce->printSingle();
				ce = ce->next;
			}
			ce = he.next;
			cout << '\n';
		}
		else if (choice == 'c')
		{
			cout << "Enter an employee's last name: ";
			string search;
			cin >> search;
			linkedSearch(he, te, ce, pe, search, true);
		}
		else if (choice == 'd')
		{
			addNewEmployee(he, te, ce);
		}
		else if (choice == 'e')
		{
			cout << "Enter an employee's last name: ";
			string search;
			cin >> search;
			linkedSearch(he, te, ce, pe, search, false);
		}
		else if (choice == 'f')
		{
			cout << "Thank you for using this program.\n";	//Exit
		}
		else
		{
			cout << "Invalid choice please select again.\n";
		}
	}

	system("pause");
	return 0;
}