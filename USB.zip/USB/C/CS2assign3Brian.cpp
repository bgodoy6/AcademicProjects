#include <iostream>
#include <sstream>
#include <string>

using namespace std;

class Fraction
{
	friend const Fraction operator+(const Fraction & num1, const Fraction & num2)
	{
		Fraction T;
		T.numerator = num1.numerator*num2.denominator + num2.numerator*num1.denominator;
		T.denominator = num1.denominator*num2.denominator;
		T.normalize();
		return T;
	}
	friend const Fraction operator-(const Fraction & num1, const Fraction & num2)
	{
		Fraction T;
		T.numerator = num1.numerator*num2.denominator - num2.numerator*num1.denominator;
		T.denominator = num1.denominator*num2.denominator;
		T.normalize();
		return T;
	}
	friend const Fraction operator*(const Fraction & num1, const Fraction & num2)
	{
		Fraction T;
		T.numerator = num1.numerator*num2.numerator;
		T.denominator = num1.denominator*num2.denominator;
		T.normalize();
		return T;
	}
	friend const Fraction operator/(const Fraction & num1, const Fraction & num2)
	{
		Fraction T;
		if (num1.denominator*num2.numerator != 0)
		{
			T.numerator = num1.numerator*num2.denominator;
			T.denominator = num1.denominator*num2.numerator;
		}
		else
		{
			T = Fraction(0, 1);
		}
		T.normalize();
		return T;
	}
	friend bool operator==(const Fraction & num1, const Fraction & num2)
	{
		return (num1.toDouble() == num2.toDouble());
	}
	friend bool operator!=(const Fraction & num1, const Fraction & num2)
	{
		return (num1.toDouble() != num2.toDouble());
	}
	friend ostream & operator<<(ostream & output, const Fraction & num)
	{
		output << num.numerator << " / " << num.denominator;
		return output;
	}
	friend istream & operator>>(istream & input, Fraction & num)
	{
		input >> num.numerator >> num.denominator;
		num.normalize();
		return input;
	}
private:
	long numerator, denominator;
public:
	Fraction(long Top = 0, long Bottom = 1)
	{
		if (Bottom == 0)
		{
			cout << "Warning denominator can't equal 0, initialized to 1 instead!\n";
			Bottom = 1;
		}
		numerator = Top;
		denominator = Bottom;
		normalize();
	}

	long gcd(long a, long b)// a=num  b=den
	{
		if (a == 0)
		{
			denominator /= b;
			return b;
		}
		if (a < 0)							{ a *= -1; }
		if (b > a)
		{
			int i = 1, j = 1;
			while (i <= a)
			{
				if (a%i == 0 && b%i == 0)
				{
					j = i;
				}
				i++;
			}
			numerator /= j;
			denominator /= j;
			return j;//int returned not long
		}
		else if (a > b)
		{
			int i = 1, j = 1;
			while (i <= b)
			{
				if (a%i == 0 && b%i == 0)
				{
					j = i;
				}
				i++;
			}
			numerator /= j;
			denominator /= j;
			return j;//int returned not long
		}
		else
		{
			numerator /= a;
			denominator /= a;
			return a;
		}//a==b
	}

	long getBottom()const { return denominator; }

	long getTop()const { return numerator; }

	void normalize()
	{
		if (numerator < 0 && denominator < 0)
		{
			numerator *= -1;
			denominator *= -1;
		}
		else if (numerator < 0 || denominator < 0)
		{
			if (denominator < 0)
			{
				denominator *= -1;
				numerator *= -1;
			}
		}
		else  {/*positive numbers*/ }
		gcd(numerator, denominator);
	}

	Fraction operator--()//pre
	{
		numerator -= denominator;
		//normalize();
		return Fraction(numerator, denominator);
	}

	Fraction operator--(int maker)
	{
		Fraction t(numerator, denominator);
		numerator -= denominator;
		//normalize();
		return  t;
	}

	Fraction operator++()//pre
	{
		numerator += denominator;
		return Fraction(numerator, denominator);
	}

	Fraction operator++(int maker)
	{
		Fraction t(numerator, denominator);
		numerator += denominator;
		return  t;
	}

	double toDouble()const		{ return numerator / static_cast<double>(denominator); }

	const string toString()const
	{
		string sNum, sDen;
		stringstream ss, ss0;
		ss << numerator;
		ss >> sNum;
		//ss << NULL
		ss0 << denominator;
		ss0 >> sDen;
		//ss0 << NULL;
		return sNum + " / " + sDen;
	}
};

int main()
{
	Fraction F1, F2;
	cout << "Enter a numerator and denominator seperately spaced for F1:";
	cin >> F1;
	cout << "Enter a numerator and denominator seperately spaced for F2:";
	cin >> F2;
	cout << "F1 = " << F1 << " and F2 = " << F2 << endl;
	cout << "The numerator of F1 is " << F1.getTop() << " and the denominator of F1 is " << F1.getBottom() << endl;
	cout << "The decimal form of F1 is " << F1.toDouble() << endl;
	cout << "The string form of F1 is " << F1.toString() << endl;
	cout << "F1 + F2 = " << F1 + F2 << endl;
	cout << "F1 + 2.0 = " << F1 + 2.0 << endl;
	cout << "F1 - F2 = " << F1 - F2 << endl;
	cout << "F1 * F2 = " << F1 * F2 << endl;
	cout << "F1 / F2 = " << F1 / F2 << endl;
	if (F1 == F2)
	{
		cout << "F1 == F2" << endl;
	}
	if (F1 != F2)
	{
		cout << "F1 != F2" << endl;
	}
	cout << "--F1 = " << --F1 << endl;
	cout << "F1-- = " << F1--;
	cout << " which later becomes " << F1 << endl;
	cout << "++F2 = " << ++F2 << endl;
	cout << "F2++ = " << F2++;
	cout << " which later becomes " << F2 << endl;

	//system("pause");
	return 0;
}
