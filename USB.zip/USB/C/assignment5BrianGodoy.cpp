/*
Brian Godoy	
July 21, 2015
assignment 5 Carbon footprint
windows 7
visual studios
*/

/*
problem description
Find average carbon footprint of cities and tax the city based off the average from the file. Do this by collecting data from each city.
This program must use sentinel values as a negative value.

Carbron foot print average threshold			Fine in $ per year
<=1												0.00
>1 but <=3										1000000.00
>3 but <=5										2000000.00
>5 but <=7										3000000.00
>7 but											4500000.00
Other computed and displayed stuff includes 
1. the number of cities
2. and total fine collected

User inputs
Variable			data types			remarks
inputilename		string				stores path to input file
outfilename			string				stores path to output file

program outputted variables
variables		data type		remarks
city			string			name of city
fine			double			fine of each city
cf				int				just one number
sum_cf			int				add all carbonfootprints for 1 city
ave_cf			double			several months average //must be rounded
tot_cities		int				number of cities
tot_fine		double			the total fines from every city
num_months		int				every number input
rounded_cf		double

Computational aid variables
Variables			Data type			Description
in					ifstream			bonds to input file
out					ofstream			bonds to output file

Analysis
num_months = number of months that record carbon footprint
sum_cf = all cfs added
math form					c++ form
ave_cf = sum_cf/num_months	static_cast<double>(sum_cf)/num_months
rounded_cf					rounded_cf = round(ave_cf)

Algorithm (short)
1. open input file and validate opening
2. open output file and validate opening
3. while (not end of file)
	3.1 increase tot_cities by 1
	3.2 read city
	3.3 output to console and file
	3.4 read first value (sentinel or not) store in cf
	3.5 while (cf>=0)
			sum_cf += cf
			num_months++
			read next score or sentinel
			end while
	3.6 if (num_months>0) then
			ave_cf = static_cast<double>(sum_cf)/num_months
			rounded_cf = round(ave_cf) 
			use if/else based off threshold to store in the variable fine
			tot_fine += fine
			print to console and file; city, rounded_cf, and fine
			end if
	3.7 else
			print to console and file "No value for carbon FP. Fine not calculated.
			end else
		end while
4. print to console and file "Total number of cities in the file = " (tot_cities
4.1 print to console and file "Total fine collected: $" (tot_fine)
4.2 close input and output file
4.3 print goodbye
*/
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <iomanip>
using namespace std;

int main()
{
	int cf;
	string inPutFile;
	cout << "Welcome to the State Software Engineering Lab.\n";
	cout << "We will calculate average carbon footprint and corresponding fine.\n";
	cout << "Please be ready to provide the data file name for carbon FP for US cities.\n";
	cout << "Enter a full path to an input file.";
	getline(cin, inPutFile);
	ifstream in(inPutFile);
	if (!in.is_open())
	{
		cout << "Error opening input file. File either does not exist or has no read permission.\n";
		cout << "Thank you for using the State Software Engineering Lab.";
		exit(0);
	}
	string outPutFile;
	cout << "Enter a full path to an output file.";
	getline(cin, outPutFile);
	ofstream out(outPutFile);
	if (!out.is_open())
	{
		cout << "Error opening output file. File either does not exist or has no read permission.\n";
		cout << "Thank you for using the State Software Engineering Lab.";
		exit(0);
	}
	out << "Welcome to the State Software Engineering Lab.\n";
	out << "We will calculate average carbon footprint and corresponding fine.\n";
	cout << "***************************************************************\n";
	cout << "City		Rounded Average Carbon FP		Fine($)		\n";
	cout << "***************************************************************\n";
	out << "***************************************************************\n";
	out << "City		Rounded Average Carbon FP		Fine($)		\n";
	out << "***************************************************************\n";
	cout << fixed << showpoint << setprecision(2);
	out << fixed << showpoint << setprecision(2);
	int tot_cities = 0;
	double tot_fine = 0.0;
	while (in.peek() != EOF)
	{
		int  num_months = 0, sum_cf = 0;
		tot_cities++;
		string city;
		in >> city;
		in >> cf;
		while (cf >= 0)
		{
			num_months++;
			sum_cf += cf;
			in >> cf;
		}
		if (num_months > 0)
		{
			double ave_cf = static_cast<double>(sum_cf) / num_months;
			int rounded_cf = static_cast<int>(round(ave_cf));
			int fine;
			if (rounded_cf <= 1)
			{
				fine = 0;
				tot_fine += fine;
			}
			else if (rounded_cf <= 3)
			{
				fine = 1000000;
				tot_fine += fine;
			}
			else if (rounded_cf <= 5)
			{
				fine = 2000000;
				tot_fine += fine;
			}
			else if (rounded_cf <= 7)
			{
				fine = 3000000;
				tot_fine += fine;
			}
			else
			{
				fine = 4500000;
				tot_fine += fine;
			}
			cout << setw(15) << city << setw(21) << rounded_cf << setw(21) << static_cast<double>(fine) << '\n';
			out << setw(15) << city << setw(21) << rounded_cf << setw(21) << static_cast<double>(fine) << '\n';
		}
		else
		{
			cout << city << setw(21) << "No value available for carbon FP. Fine not calculated.\n";
			out << city << setw(21) << "No value available for carbon FP. Fine not calculated.\n";
		}
	}
	cout << "***************************************************************\n";
	out << "***************************************************************\n";
	cout << "Total number of cities in the file = " << tot_cities << '\n';
	cout << "Total fine collected: $" << static_cast<double>(tot_fine) << '\n';
	cout << "Thank you for using the State Software Engineering Lab.";
	out << "Total number of cities in the file = " << tot_cities << '\n';
	out << "Total fine collected: $" << tot_fine << '\n';
	out << "Thank you for using the State Software Engineering Lab.";
	system("pause");
	return 0;
}