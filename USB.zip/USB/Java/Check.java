/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author brian_godoy
 */
public class Check extends Transaction{
    private int checkNumber;
    public Check(int tCount, int tId ,double tAmt, int checkNumber)
    {
        super(tCount, tId, tAmt);
        this.checkNumber = checkNumber;
    }
    public int getCheckNumber()
    {
        return checkNumber;
    }
    public void setCheckNumber(int checkNumber)
    {
        this.checkNumber = checkNumber;
    }
}
