/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.ArrayList;
/**
 *
 * @author brian_godoy
 */
public class CheckingAccount extends Account{
    private double totalServiceCharge = 0.0;
    private ArrayList <Transaction> transList = new ArrayList();
    private int transCount = 0;//array quantity
    public ArrayList<Deposit> depList = new ArrayList();
    public ArrayList<Check> chkList = new ArrayList();
    public boolean underFive = false, belowZero = false, option6Flag = false;
    public CheckingAccount(String name, double initBalance)
    {
        super(name, initBalance);
    }
    public void addTrans(Transaction newTrans)
    {
        transList.add(newTrans);
        transCount++;
    }
    public int getTransCount()
    {
        return transCount;
    }
    public Transaction getTrans(int i)
    {
        return transList.get(i);
    }
    public void setBalance(double transAmt, int tCode)
    {
        if(tCode == 1)
            balance = balance - transAmt;//subtract
        else
            balance = transAmt + balance;//add
    }
    public double getServiceCharge()
    {
        return totalServiceCharge;
    }
    public void setServiceCharge(double currentServiceCharge)
    {
        totalServiceCharge = currentServiceCharge + totalServiceCharge;
    }
    public void emptyArrayList()
    {
        depList = new ArrayList();
        chkList = new ArrayList();
        transList = new ArrayList();
        transCount = 0;
    }
    public boolean listIsEmpty()
    {
        return transList.isEmpty();
    }
}
