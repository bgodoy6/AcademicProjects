/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author brian_godoy
 */
public class Deposit extends Transaction{
    private double cash;
    private double check;
    public Deposit(int tCount, int tId ,double tAmt, double check, double cash)
    {
        super(tCount, tId, tAmt);
        this.check = check;
        this.cash = cash;
    }
    public double getCash(){
        return cash;
    }
    public double getCheck(){
        return check;
    }
}
