/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
import java.applet.Applet;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.AudioClip;
import java.net.MalformedURLException;
import java.net.URL;
import static javaapplication3.Main.Index;
/**
 *
 * @author brian_godoy
 */
public class Window extends JPanel {
    JMenuBar File = new JMenuBar();
    JMenuBar Account = new JMenuBar();
    JMenuBar Transactions = new JMenuBar();
    JMenuBar Gamble = new JMenuBar();
    JMenu mF = new JMenu("File");
    JMenu mA = new JMenu("Account");
    JMenu mT = new JMenu("Transactions");
    JMenu mG = new JMenu("Gamble");
    JMenuItem rdFile = new JMenuItem(new AbstractAction("Read from file"){
        public void actionPerformed(ActionEvent ae){
            Main.optionFive();
            mA.add(lstAcc);
        }
    });
    JMenuItem opFile = new JMenuItem(new AbstractAction("Write to file"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                Main.optionSix();
            else
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
        }
    });
    JMenuItem addAcc = new JMenuItem(new AbstractAction("Add new account"){
        public void actionPerformed(ActionEvent ae){
                Main.optionSeven();
                mA.add(lstAcc);
            }
    });
    JMenuItem lstAccT = new JMenuItem(new AbstractAction("List accounts transaction"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                tArea.setText(Main.optiontwo());
            else
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
        }
    });
    JMenuItem lstChk = new JMenuItem(new AbstractAction("List all checks"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                tArea.setText(Main.optionthree());
            else
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
        
        }
    });
    JMenuItem lstDep = new JMenuItem(new AbstractAction("List all deposits"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                tArea.setText(Main.optionfour());
            else
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
        
        }
    });
    JMenuItem findAcc = new JMenuItem(new AbstractAction("Find an account"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                tArea.setText(Main.optionEight());
            else
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
        }
    });
    JMenuItem lstAcc = new JMenuItem(new AbstractAction("List all Accounts"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                tArea.setText(Main.optionNine());
            else
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
        }
    });
    JMenuItem addT = new JMenuItem(new AbstractAction("Add Transactions"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                Main.optionOne();
            else
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
        }
    });
    JMenuItem sltsGame = new JMenuItem(new AbstractAction("Slots"){
        public void actionPerformed(ActionEvent ae){
            if(Main.Index>=0)
                {
                    try{
                        game();
                    }
                    catch(InterruptedException e)
                    {
                        JOptionPane.showMessageDialog(null,e);
                    }
                }
            else{
                tArea.setText("There are no accounts stored, add an account or read one from a file.");
              
            }
        }
    });
    JTextArea tArea = new JTextArea();
    public void game() throws InterruptedException
    {
        JFrame frame = new JFrame("Slots");
        GPanel game = new GPanel();
        frame.addWindowListener(new WindowAdapter() {
           public void windowClosing(WindowEvent e){
             game.stopBGM();
           
        }
        });
        frame.setPreferredSize(new Dimension(500, 500));
        frame.getContentPane().add(game);
        frame.pack();
        frame.setVisible(true); 
    }
    public Window()
    {
        mF.add(rdFile);
        mF.add(opFile);
        mA.add(addAcc);
        mA.add(lstAccT);
        mA.add(lstChk);
        mA.add(lstDep);
        mA.add(findAcc);
        mG.add(sltsGame);    
        mT.add(addT);
        File.add(mF);
        Account.add(mA);
        Transactions.add(mT);
        Gamble.add(mG);
        add(File);
        add(Account);
        add(Transactions);
        add(Gamble);
        add(tArea);
        setLayout(new FlowLayout(FlowLayout.LEFT,2,2));
        setPreferredSize(new Dimension(400, 400));
        tArea.setPreferredSize(new Dimension(400,400));
    }
    
}
