/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
import java.awt.image.BufferedImage;

import java.io.*;
import java.awt.event.*;
import java.util.Timer.*;

import javax.swing.*;
import java.awt.*;
import java.applet.*;
import java.net.*;
import java.util.ArrayList;
import static javaapplication3.Main.acc;
import javax.imageio.ImageIO;
/**
 *
 * @author brian_godoy
 */
public class GPanel extends JPanel {
    private Timer time,time2;
    private JLabel prompt;
    private ArrayList<ImageIcon> images = new ArrayList<ImageIcon>();
    private JLabel bar1, bG, barGains;
    private JButton play;
    private ImageIcon im1,im2,im3;
    private AudioClip clip;
    private Boolean clipPlayed;
    public GPanel(){//listener
        clipPlayed = false;
        slotListener listen = new slotListener();
        play = new JButton("Play");
        play.addActionListener(listen);
        //images
        images.add(new ImageIcon(getClass().getResource("slot1.PNG")));
        images.add(new ImageIcon(getClass().getResource("slot2.PNG")));
        images.add(new ImageIcon(getClass().getResource("slot3.PNG")));
        images.add(new ImageIcon(getClass().getResource("slot4.PNG")));
        images.add(new ImageIcon(getClass().getResource("slot5.PNG")));
        images.add(new ImageIcon(getClass().getResource("slot6.PNG")));
        images.add(new ImageIcon(getClass().getResource("slot7.PNG")));
        //labels
        prompt = new JLabel("Digital Slots");
        prompt = new JLabel("Digital Slots");
        prompt.setFont(new Font("Helvetica", Font.BOLD, 40));
        prompt.setForeground(Color.blue);
        bar1 = new JLabel("\'7s\' x 6 watermelons x 5 lemons x 4 oranges x 3 cherries x 2 grapes x 1  bars x 0");
        
        barGains = new JLabel("Your losses and earnings will be displayed here, close to exit.");
        barGains.setFont(new Font("Helvetica", Font.BOLD, 15));
        bG = new JLabel("");
        bG.setFont(new Font("Helvetica", Font.BOLD, 15));
        try{
            clip = Applet.newAudioClip(new URL("file:C:\\Users\\juventino\\Hw\\pokeAudio.wav"));
            clip.loop();
            Thread.sleep(0);
        }
        catch(MalformedURLException me)
        {
            System.out.println(me);
        }
        catch(InterruptedException me)
        {
            System.out.println(me);
        }
        //this panel
        im1=images.get(6);
        im2=images.get(6);
        im3=images.get(6);
        add(prompt, BorderLayout.NORTH);
        //add(ground);
        add(bar1);
        add(barGains);
        add(play);
        add(bG);
        setBackground(Color.green);
        setPreferredSize(new Dimension(260, 300));
        time = new Timer(250, new slotListener());
        time2 = new Timer(2000, new AbstractAction(){
        public void actionPerformed(ActionEvent ae){
            time.stop();
            time2.stop();
            finalSpin();
            clipPlayed = false;
            play.setEnabled(true);
        }
    });
    }
    public void paintComponent(Graphics pg)
    {
        super.paintComponent(pg);
        im1.paintIcon(this, pg,10, 200);
        im2.paintIcon(this, pg,155, 200);
        im3.paintIcon(this, pg,300, 200);
    }
    public void stopBGM()
    {
        try{
            clip.stop();
            Thread.sleep(5);
        }
        catch(InterruptedException me)
        {
            System.out.println(me);
        }
    }
    private class slotListener implements ActionListener {
        
        public void actionPerformed(ActionEvent ae)
        {
            play.setEnabled(false);
            barGains.setText("-$5");
            bG.setText("-$5");
            if(!clipPlayed)
            {
                clipPlayed = true;
                try{
                    PlaySound.myPlay("file:C:\\Users\\juventino\\Hw\\spinSound.wav");
                }
                catch(InterruptedException ie){
                    System.out.println();
                }
            }
            time.start();
            time2.start();
            im1 = images.get(Main.rng());
            im2 = images.get(Main.rng());
            im3 = images.get(Main.rng());
            repaint();
        }
    }
    public void finalSpin()
    {
        int ran1 = Main.rng(),ran2=Main.rng(),ran3 =Main.rng();
        im1 = images.get(ran1);
        im2 = images.get(ran2);
        im3 = images.get(ran3);
        repaint();
        if(ran1==ran2&&ran1==ran3&&ran1>0)
        {
            barGains.setText("$"+(5*ran1));
            bG.setText("$"+(5*ran1));
            acc.get(Main.Index).addTrans(new Transaction(0, 5, 5*ran1-5));
        }
        else{
            barGains.setText("$0");
            bG.setText("$0");
            acc.get(Main.Index).addTrans(new Transaction(0, 4, -5));
        }
    }
    
}