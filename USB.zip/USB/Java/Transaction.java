/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author brian_godoy
 */
public class Transaction {
    private int transNumber;//transcount//element number
    private int transId;// 1 check,2 deposit,3 service charge
    private double transAmt;//charge,deposit,check amounts
    
    public Transaction(int number, int id, double amount)
    {
        transNumber = number;
        transId = id;
        transAmt = amount;
    }
    public int getTransNumber()
    {
        return transNumber;
    }
    public int getTransId()
    {
        return transId;
    }
    public double getTransAmount()
    {
        return transAmt;
    }
}
