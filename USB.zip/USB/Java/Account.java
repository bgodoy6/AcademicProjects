/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author brian_godoy
 */
public class Account {
    protected String name;//account owner
    protected double balance;//don't define in checking account class
    public Account(String acctName, double initBalance)
    {
        balance = initBalance;
        name = acctName;
    }
    
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public double getBalance()
    {
        return balance;
    }
    public void setBalance(double balance)
    {
        this.balance = balance;
    }
}
