/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author juventino
 */
public class DoublePan extends JPanel{
        private JLabel cashL, checksL;
    private JTextField cashT, checksT;
    private JButton ok, cancel;
   
    
    DoublePan()
    {
       
       setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
       setPreferredSize(new Dimension(250, 85));

        JTextField cashT = new JTextField(22);
        JTextField checksT = new JTextField(22);

        JLabel cashL = new JLabel("Cash:");
        JLabel checksL = new JLabel("Checks:");
        
        ok = new JButton("OK");
        cancel = new JButton("Cancel");
        OptionListener listener = new OptionListener();
        cashT.addActionListener(listener);
        checksT.addActionListener(listener);
        ok.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                String input, input2;
                if (cashT.getText().length() != 0)
                {
                    input = cashT.getText();
                }
                else
                {
                    input = "0";
                }
                if(checksT.getText().length() != 0) 
                {
                    input2 = checksT.getText();
                }
                else
                {
                    input2 = "0";
                }
                Main.depCsh = Double.parseDouble(input); 
                Main.depChk = Double.parseDouble(input2);
                Main.f.dispose();
            }
        });

        cancel.addActionListener(listener);
        add(cashL);
        add(cashT);
        add(checksL);
        add(checksT);
        add(ok);
        add(cancel);
        
       }
    private class OptionListener implements ActionListener{
        public void actionPerformed(ActionEvent event)
        {
            
           
                System.exit(0);
           
            
            }
        }
        
    }



   
        
   

