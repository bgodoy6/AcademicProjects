/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author brian_godoy
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OptionsPanel extends  JPanel{
    private JLabel prompt;
    private JRadioButton one, two, three, four, five, six;
    
    public OptionsPanel()
    {
            
        setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
        prompt = new JLabel("Please choose one of the items:");
        prompt.setFont(new Font("Helvetica", Font.BOLD, 12));
        one = new JRadioButton("a) Enter a transaction");
        one.setBackground(Color.green);
        two = new JRadioButton("b) List all transactions");
        two.setBackground(Color.green);
        three = new JRadioButton("c) List all checks");
        three.setBackground(Color.green);
        four = new JRadioButton("d) List all deposits");
        four.setBackground(Color.green);
        five = new JRadioButton("e) Read from file");
        five.setBackground(Color.green);
        six = new JRadioButton("f) Write to the file");
        six.setBackground(Color.green);
        ButtonGroup group = new ButtonGroup();
        group.add(one);
        group.add(two);
        group.add(three);
        group.add(four);
        group.add(five);
        group.add(six);
        OptionListener listener = new OptionListener();
        one.addActionListener(listener);
        two.addActionListener(listener);
        three.addActionListener(listener);
        four.addActionListener(listener);
        five.addActionListener(listener);
        six.addActionListener(listener);
        add(prompt);
        add(one);
        add(two);
        add(three);
        add(four);
        add(five);
        add(six);
        setBackground(Color.green);
        setPreferredSize(new Dimension(243, 195));
        
    }
    
    private class OptionListener implements ActionListener{
        public void actionPerformed(ActionEvent event)
        {
            Object source = event.getSource();
            if(source == one)// transactions
            {    setVisible(false);
                Main.optionOne();
                setVisible(true);
            }
            else if(source == two)//list all transactioions
            {
                setVisible(false);
                Main.optiontwo();
                setVisible(true);
            }
            else if(source == three)//list all checks
            {
                setVisible(false);
                Main.optionthree();
                setVisible(true);
            }
            else if (source == four) //source == 4 list all deposits
            {   
                setVisible(false);
                Main.optionfour();
                setVisible(true);
            }
             else if (source == five)
            {
                setVisible(false);
                Main.optionFive();
                setVisible(true);
            }
            else{
                setVisible(false);
                Main.optionSix();
                setVisible(true);
            }
        }
        
    }
}
