/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author brian_godoy
 * Main calls the options panel which calls the options methods
 */
import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Dimension;
import java.awt.event.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<CheckingAccount> acc = new ArrayList();
    static int Index = -1;
    static double depCsh, depChk;
    static JDialog f = new JDialog();
    static JFrame frame;
     
    /**
     * @param args the command line arguments
     */
    /**FILE FORMAT
     Name
     initial balance//integer 3 = service charge 2 = deposit 1= check
     2                  //first transaction
     checks   cash               
     1   //2nd transaction
     amount checkNumber
     3 or 4 or 5  //3rd transaction
     amount
     
     //no empty lines
     */
    public static void main(String[] args) throws InterruptedException {
        //TODO code application logic here
        frame = new JFrame("Checking Account actions");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Window wndw = new Window();
        frame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                if(Index>=0 && !acc.get(Index).option6Flag)
                {
                optionSix();
                }
                System.exit(0);
            }
        });
        frame.getContentPane().add(wndw);
        frame.pack();
        frame.setVisible(true);
        
    }
    public static void optionOne()
    {
        acc.get(Index).option6Flag=false;
        int tCode, tNumber = 0;
        double amt;
        DecimalFormat fmt = new DecimalFormat("#0.00");
        String message;
        do
        {  
           tCode = getTransCode();
           if(tCode == 1)//.15 is the charge, 1 is the id unless it's a service charge or if tcode = 2, trans count is tnumber
           {
               amt = getTransAmt();
               int chkNum = Integer.parseInt(JOptionPane.showInputDialog("Enter the check number"));
               
               message = acc.get(Index).getName() + "'s account.\n";
               message = message + "Transaction: Check #" + chkNum + " in amount of $" + fmt.format(amt) + "\n";
               
               processCheck(amt);
               message = message + "Current Balance: ";
               acc.get(Index).chkList.add(new Check(tNumber, 1, amt, chkNum));
               acc.get(Index).addTrans(new Transaction(tNumber++, 1, amt));
               if (acc.get(Index).getBalance() < 0.0)
               {message = message + "($" + fmt.format(acc.get(Index).getBalance()*-1) + ")";}
               else//positive
               {
                   message = message + "$" + fmt.format(acc.get(Index).getBalance());
               }
               message = message + "\n";
               acc.get(Index).setServiceCharge(0.15);
               acc.get(Index).addTrans(new Transaction(tNumber++, 3, .15));
               message = message + "Service Charge: Check ---charge $0.15\n";
               if(acc.get(Index).getBalance() < 500.0 && !acc.get(Index).underFive)
               {
                   acc.get(Index).setServiceCharge(5.0);
                   acc.get(Index).addTrans(new Transaction(tNumber++, 3, 5.0));
                   acc.get(Index).underFive = true;
                   message = message + "Service charge: Below $500 ---charge $5.00\n";
               }
               if(acc.get(Index).getBalance()<50.0)
               {
                   message = message + "Warning: Balance below $50\n";
               }
               if(acc.get(Index).getBalance()<0.0 && !acc.get(Index).belowZero)
               {
                   acc.get(Index).belowZero = true;
                   message = message + "Service charge: Below $0 --charge $10.00\n";
                   acc.get(Index).setServiceCharge(10.0);
                   acc.get(Index).addTrans(new Transaction(tNumber++, 3, 10.0));
               }
               message = message + "Total Service Charge:$"+ fmt.format(acc.get(Index).getServiceCharge());
               JOptionPane.showMessageDialog(null, message);
           }
           else if(tCode == 2)
           {
                DoublePan p = new DoublePan();
                f.setPreferredSize(new Dimension(200, 200));
                f.getContentPane().add(p);
                f.pack();
                f.setModal(true);
                f.setVisible(true);
               
               amt = depCsh + depChk;
               message= acc.get(Index).getName() + "'s account.\n";
               message = message + "Transaction: Deposit in amount of $" + fmt.format(amt) + "\n";
               processDeposit(amt);
               acc.get(Index).depList.add(new Deposit(tNumber, 2, amt, depChk, depCsh));
               acc.get(Index).addTrans(new Transaction(tNumber++, 2, amt));
               message = message + "Current Balance: ";
               if (acc.get(Index).getBalance() < 0.0)
               {message = message + "($" + fmt.format(acc.get(Index).getBalance()*-1) + ")";}
               else//positive
               {
                   message = message + "$" + fmt.format(acc.get(Index).getBalance());
               }
               message = message + "\n";
               acc.get(Index).setServiceCharge(0.10);
               acc.get(Index).addTrans(new Transaction(tNumber++, 3, 0.10));
               message = message + "Service Charge: Deposit ---charge $0.10\n";
               if(acc.get(Index).getBalance() < 500.0 && !acc.get(Index).underFive)
               {
                   acc.get(Index).setServiceCharge(5.0);
                   acc.get(Index).underFive = true;
                   acc.get(Index).addTrans(new Transaction(tNumber++, 3, 5));
                   message = message + "Service charge: Below $500 ---charge $5.00\n";
               }
               if(acc.get(Index).getBalance()<50.0)
               {
                   message = message + "Warning: Balance below $50\n";
               }
               if(acc.get(Index).getBalance()<0.0 && !acc.get(Index).belowZero)
               {
                   acc.get(Index).belowZero = true;
                   message = message + "Service charge: Below $0 --charge $10.00\n";
                   acc.get(Index).setServiceCharge(10.0);
                   acc.get(Index).addTrans(new Transaction(tNumber++, 3, 10));
               }
               message = message + "Total Service Charge:$"+ fmt.format(acc.get(Index).getServiceCharge());
               JOptionPane.showMessageDialog(null, message);
           }
           else//tCode = 0
           {
               message = acc.get(Index).getName() + "'s account.\n";
               message = message + "Transaction: End\n"
                +"Current Balance:";
               if (acc.get(Index).getBalance() < 0.0)//negative
               {message = message + "($" + fmt.format(acc.get(Index).getBalance()*-1) + ")";}
               else//positive
               { message = message + "$" + fmt.format(acc.get(Index).getBalance());}
               message = message + "\n";
               message = message + "Total Service Charge: $" + fmt.format(acc.get(Index).getServiceCharge()) + "\n";
                acc.get(Index).setBalance(acc.get(Index).getServiceCharge(), 1);
                message = message + "Final Balance:";
                if (acc.get(Index).getBalance() < 0.0)
               {message = message + "($" + fmt.format(acc.get(Index).getBalance()*-1) + ")";}
               else//positive
               {message = message + "$" + fmt.format(acc.get(Index).getBalance());}
               JOptionPane.showMessageDialog(null, message);
           }
        }while(false);
    }
    public static String optiontwo()
    {
        DecimalFormat fmt = new DecimalFormat("#0.00");
        int x = 0;
        String message = "Account: "+acc.get(Index).getName() +"\nBalance: $"+fmt.format(acc.get(Index).getBalance())+"\nTotal Service Charge: $"+fmt.format(acc.get(Index).getServiceCharge())+"\n\nList of all transactions:"+"\n\nID     Type                            Amount\n";
        while(x<acc.get(Index).getTransCount()){
            if(acc.get(Index).getTrans(x).getTransId() == 1)//check
                message = message + x + "     " +"Check                            $" + fmt.format(acc.get(Index).getTrans(x).getTransAmount())+"\n";
            else if(acc.get(Index).getTrans(x).getTransId() == 2)//deposit
                message = message + x + "      "+"Deposit                          $" + fmt.format(acc.get(Index).getTrans(x).getTransAmount())+"\n";
            else if(acc.get(Index).getTrans(x).getTransId() == 3)//serv. charge
                message = message + x + "     "+"Svc. Chrg.                       $" + fmt.format(acc.get(Index).getTrans(x).getTransAmount())+"\n";
            else if(acc.get(Index).getTrans(x).getTransId() == 4)//losses
                message = message + x + "     "+"Debit                       $" + fmt.format(acc.get(Index).getTrans(x).getTransAmount())+"\n";
            else//earnings
                message = message + x + "     "+"Crebit                       $" + fmt.format(acc.get(Index).getTrans(x).getTransAmount())+"\n";
            x++;
        }
        return message;
    }
    public static String optionthree()//list all checks
    {
        DecimalFormat fmt = new DecimalFormat("#0.00");
        int x = 0, y = 0;
        String message = "Account: "+acc.get(Index).getName() +"\nBalance: $"+fmt.format(acc.get(Index).getBalance())+"\nTotal Service Charge: $"+fmt.format(acc.get(Index).getServiceCharge())+"\n\nChecks Cashed:"+"\n\nID           Check                      Amount\n";
        while(x<acc.get(Index).getTransCount() && !acc.get(Index).chkList.isEmpty()){
            if(acc.get(Index).getTrans(x).getTransId() == 1){//check
                message = message + x + "             "+ "#"+acc.get(Index).chkList.get(y).getCheckNumber() + "                         $" + fmt.format(acc.get(Index).getTrans(x).getTransAmount())+"\n";
                y++;
            }
            x++;
        }
        return message;
    }
    public static String optionfour()//list all deposits
    {
        DecimalFormat fmt = new DecimalFormat("#0.00");
        int x = 0,y = 0;
        String message = "Account: "+acc.get(Index).getName() +"\nBalance: $"+fmt.format(acc.get(Index).getBalance())+"\nTotal Service Charge: $"+fmt.format(acc.get(Index).getServiceCharge())+"\n\nListing of all Deposits:"+"\n\nID     Type                Check                Cash            Amount\n";
        
        while(x<acc.get(Index).getTransCount()){
           
            if(acc.get(Index).getTrans(x).getTransId() == 2)//deposit
            {
                message = message + x + "         Deposit"+ "        $"+ fmt.format(acc.get(Index).depList.get(y).getCheck()) + "          $" + fmt.format(acc.get(Index).depList.get(y).getCash()) +"          $" + fmt.format(acc.get(Index).depList.get(y).getCash()+acc.get(Index).depList.get(y).getCheck())+"\n";
                y++;
            }
            x++;
        }
        return message;
    }
    public static void optionFive()//read from file
    {
        
        try{ 
            JFileChooser fc = new JFileChooser();
            fc.showDialog(null, "Open");
            File file = fc.getSelectedFile();
            Scanner scan = new Scanner(file);
            String accName = scan.nextLine();
            double initBalance = scan.nextDouble();
            acc.add(new CheckingAccount(accName, initBalance));
            Index = acc.size()-1;
            acc.get(Index).option6Flag = false;
            acc.get(Index).underFive = false;
            acc.get(Index).belowZero = false;
            int tNumber = 0;
            acc.get(Index).emptyArrayList();
            while(scan.hasNextLine())
            {
               int tType = scan.nextInt();
               if(tType == 3)//charge
               {
                   double charge = scan.nextDouble();
                   if(charge == 5.0)
                   {
                       acc.get(Index).underFive = true;
                   }
                   else if(charge == 10.0)
                   {
                       acc.get(Index).belowZero = true;
                   }
                   else{}//ignore
                   acc.get(Index).addTrans(new Transaction(tNumber++, 3, charge));
                   acc.get(Index).setServiceCharge(charge);
               }
               else if (tType == 2)//dep
               {
                   depChk = scan.nextDouble();
                   depCsh = scan.nextDouble();
                   acc.get(Index).depList.add(new Deposit(tNumber, 2, depChk + depCsh, depChk, depCsh));
                   acc.get(Index).addTrans(new Transaction(tNumber++, 2, depChk + depCsh));
                }
               else if (tType == 1)//check
               {
                   double amt = scan.nextDouble();
                   int chkNum = scan.nextInt();
                   acc.get(Index).chkList.add(new Check(tNumber, 1, amt, chkNum));
                   acc.get(Index).addTrans(new Transaction(tNumber++, 1, amt));
               }
               else if (tType == 4||tType == 5)//gambling
               {
                   double charge = scan.nextDouble();
                   acc.get(Index).addTrans(new Transaction(tNumber++, 3, charge));
                   acc.get(Index).setServiceCharge(charge);
               }
               else 
               {
                   JOptionPane.showMessageDialog(null, "The file has an incorrect character, the file will stop being read up to a certain point.");
                   break;
               }
               
            }
            
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
        acc.get(Index).option6Flag = true;
    }
    public static void optionSix()//write to file
    {
        acc.get(Index).option6Flag = true;
        DecimalFormat fmt = new DecimalFormat("#0.00");
        try{
            JFileChooser fc = new JFileChooser();
            fc.showDialog(null, "Save");
            File file = fc.getSelectedFile();
            FileWriter write = new FileWriter(file);
            PrintWriter out = new PrintWriter(write);
            out.println(acc.get(Index).getName());
            if(!acc.get(Index).listIsEmpty())
                out.println(acc.get(Index).getBalance());
            else
                out.print(acc.get(Index).getBalance());
            for(int i =0, j =0, k = 0; i<acc.get(Index).getTransCount();i++)
            {
                
                if(acc.get(Index).getTrans(i).getTransId() == 1)//check 
                {
                    
                    out.println(1);
                    if (i+1<acc.get(Index).getTransCount())
                        out.println(fmt.format(acc.get(Index).getTrans(i).getTransAmount())+" "+acc.get(Index).chkList.get(k).getCheckNumber());
                    else
                        out.print(fmt.format(acc.get(Index).getTrans(i).getTransAmount())+" "+acc.get(Index).chkList.get(k).getCheckNumber());
                    k++;
                }
                else if(acc.get(Index).getTrans(i).getTransId() == 2)//deposit    $" + fmt.format(acc.getTrans(x).getTransAmount())+"\n";
                {
                    out.println(2);
                    if (i+1<acc.get(Index).getTransCount())
                        out.println(fmt.format(acc.get(Index).depList.get(j).getCheck())+" "+fmt.format(acc.get(Index).depList.get(j).getCash()));
                    else
                        out.print(fmt.format(acc.get(Index).depList.get(j).getCheck())+" "+fmt.format(acc.get(Index).depList.get(j).getCash()));
                    j++;
                }
                else//serv. charge and gambling
                {
                    out.println(3);
                    if (i+1<acc.get(Index).getTransCount())
                        out.println(fmt.format(acc.get(Index).getTrans(i).getTransAmount()));
                    else
                        out.print(fmt.format(acc.get(Index).getTrans(i).getTransAmount()));
                }
            }
            
            write.close();
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    public static void optionSeven()//add new account
    {
        String nameInput = JOptionPane.showInputDialog("Enter the account name:");
        String input = JOptionPane.showInputDialog("Enter your initial balance:");
        double balance;
        try
        {
            balance = Double.parseDouble(input);
        }
        catch(NumberFormatException e){
            balance = 0;
        }
        acc.add(new CheckingAccount(nameInput, balance));
        Index = acc.size()-1;
        
    }
    public static String optionEight()//find account
    {
        String findNm = JOptionPane.showInputDialog(null, "Enter the account name:");
        int i = 0;
        while(i<acc.size())
        {
            if(findNm.equals(acc.get(i).getName()))
            {
                Index = i;
                return "Found account for "+acc.get(i).getName();
            }
            i++;
        }
        return "Account for "+acc.get(i).getName()+" was not found."; 
        
    }
    public static String optionNine()//list all accounts
    {
        String message = "";
        int i = 0;
        while(i<acc.size())
        {
            message = message +"Account: "+ acc.get(i).getName()+"\n";
            i++;
        }
        return message;
    }
    public static int getTransCode()
    {
        String input = JOptionPane.showInputDialog("0->End\n1->Check\n2->Deposit\nEnter trans code:");
        return Integer.parseInt(input);
    }
    public static double getTransAmt()
    {
        String inp = JOptionPane.showInputDialog("Enter trans amt:");
        return Double.parseDouble(inp); 
    }
    public static void processCheck(double amount)//check subtracts
    {
        acc.get(Index).setBalance(amount, 1);
    }
    public static void processDeposit(double amount)//deposit adds
    {
        acc.get(Index).setBalance(amount, 2);  
    }
    public static int rng(){
        return (int)(Math.random()*7);
    }
    
}
