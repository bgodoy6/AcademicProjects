/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.util.Scanner;

/**
 *
 * @author Brian
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here// ?=lambda
        CFG cfg = createCFG();
        cfg=changeCFG(cfg);
        cfg.printCFG();
        
    }
    public static CFG createCFG(){
        Scanner in = new Scanner(System.in);
        System.out.println("How many variables will the context-free grammar contain? (S->x|y,A->y|z,B->z = 3 Vars)");
        int vars = in.nextInt();
        CFG cfg = new CFG(vars);
        cfg.initializeList();
        cfg.printCFG();
        return cfg;
    }
    
    public static CFG changeCFG(CFG cfg){
        boolean[] term= new boolean[cfg.size()],lamb=new boolean[cfg.size()],useless= new boolean[cfg.size()];
        String[] vars=new String[cfg.size()];
        cfg.getVars(vars);
        int num=0;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter 0 to remove lambda productions,\n"
                + "enter 1 to remove unit productions, \n"
                + "enter 2 to remove useless productions, or\n"
                + "enter anything else to remove all productions. ");
        num = in.nextInt();
        cfg.getNonUseless(term, lamb);
        if(num==0){
            cfg.removeLambda(term,lamb);
        }
            
        else if(num==1){
            cfg.removeUnit();
        }
            
        else if(num==2){
            cfg.removeUseless(term,lamb,vars);
        }
            
        else{
            cfg.removeLambda(term,lamb);
            cfg.removeUnit();
            cfg.removeUseless(term,lamb,vars);
        }
                
        
        
        return cfg;
    }
    
}
