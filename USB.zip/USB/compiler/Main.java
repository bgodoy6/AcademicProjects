/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.util.Arrays;


/**
 *
 * @author Brian
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Matrix nfa = new Matrix(3,"01"),dfa;
        //creates a matrix of size[3]["01".length] //3x2 array
        //lambda transitions are excluded
        
        
        nfa.createTransition(0, 0, "01"); //q0--0-->q0 and q0--0-->q1
        nfa.createTransition(0, 1, "1"); //q0--1-->q1
        nfa.createTransition(1, 1, "012");
        nfa.createTransition(2, 0, "0");
        nfa.printMatrix();
        
        /**?=lambda transition
         * 0    1  //transition alphabet
         0 01   1
         1      2
         2  0        
         state->state
         */
        
        dfa = NFAtoDFA(nfa);
        dfa.printMatrix();
    }
    
    public static Matrix NFAtoDFA(Matrix nfa){
        Matrix dfa = new Matrix(nfa);
        
        for(int i=0;i<dfa.size();i++){
            for(int j=0;j<dfa.getAlpha().length();j++){
                if(dfa.getVertex(i,j)!=null&&!dfa.contains(dfa.getVertex(i, j))){
                    dfa.expand(dfa.getVertex(i, j));
                }
            }
        }
        dfa.createTraps();
        
        return dfa;
    }
    
    
    public static String unique(String current){
        String newString ="";
        for(int i=0;i<current.length();i++)
        {
            if(!newString.contains(""+current.charAt(i))){
                newString+=current.charAt(i);
            }
        }
        char[] chars = newString.toCharArray();
        Arrays.sort(chars);
        newString = new String(chars);
        
        return newString;
    }
    
}
