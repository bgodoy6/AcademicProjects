/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Brian
 */
public class Matrix {
    
    private String[][] matrix;
    private String[] states;
    private String alphabet;
    private int size,oSize; //current and original size
    
    public Matrix(int n,String alphabet){
        size = n;
        oSize = size;
        this.alphabet = alphabet;
        matrix = new String[n][alphabet.length()];
        states=new String[n];
        for(int i=0;i<n;i++){
            states[i]=""+i;
        }
    }
    public Matrix(Matrix n){
        size = n.size();
        oSize=size;
        alphabet = n.getAlpha();
        matrix = new String[n.size()][alphabet.length()];
        states=n.getStates();
        for(int i=0;i<n.size();i++){
            for(int j=0;j<alphabet.length();j++){
                matrix[i][j]=n.getVertex(i, j);
                
            }
        }
    }
    public String[] getStates(){
        return states;
    }
    public String getAlpha(){
        return alphabet;
    }
    
    public String getVertex(int start,int end){
        return matrix[start][end];
    }
    public void expand(String newState){
        size++;
        String[][] oldMatrix = matrix;
        matrix = new String[size][alphabet.length()];
        for(int i=0;i<size-1;i++){
            for(int j=0;j<alphabet.length();j++){
                matrix[i][j]=oldMatrix[i][j];
            }
        }
        String[] oldStates = states;
        states = new String[oldStates.length+1];
        for(int i=0;i<oldStates.length;i++){
            states[i]=oldStates[i];
        }
        states[states.length-1]=newState;
        createTransitions();
    }
    public void createTransitions(){
        String transition;
        for(int j=0;j<alphabet.length();j++){
            transition="";
            for(int i=0;i<oSize;i++){
                if(matrix[i][j]!=null&&states[size-1].contains(states[i])){
                    transition+=matrix[i][j];
                }
            }
            
            matrix[size-1][j]=Main.unique(transition);
            
        }
        
    }
    public boolean contains(String state){
        for(int i=0;i<states.length;i++){
            if(states[i].equals(state))
                return true;
        }
        return false;
    }
    public void createTraps(){
        size++;
        String[][] oldMatrix = matrix;
        matrix = new String[size][alphabet.length()];
        for(int i=0;i<size-1;i++){
            for(int j=0;j<alphabet.length();j++){
                matrix[i][j]=oldMatrix[i][j];
            }
        }
        String[] oldStates = states;
        states = new String[oldStates.length+1];
        for(int i=0;i<oldStates.length;i++){
            states[i]=oldStates[i];
        }
        states[states.length-1]="trap";
        for(int i=0;i<size;i++){
            for(int j=0;j<alphabet.length();j++){
                if(matrix[i][j]==null)
                    matrix[i][j]="trap";
            }
        }
    }
    public void createTransition(int start,int end,String link){
        matrix[start][end] = link;
    }
    
    public int size(){
        return size;
    }
    public int oSize(){
        return oSize;
    }
    public void printTransition(int start,int end){
        System.out.print(matrix[start][end]);
    }
    public void printMatrix(){
        System.out.print("\t");
        for(int i=0;i<alphabet.length();i++){
            System.out.print(alphabet.charAt(i)+"\t");
        }
        System.out.println();
        
        for(int i=0;i<size;i++){
            System.out.print(states[i]+"\t");
            for(int j=0;j<alphabet.length();j++){
                System.out.print(matrix[i][j]+"\t");
            }
            System.out.println();
        }
    }
}
