/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.util.Scanner;
/**
 *
 * @author Brian
 */
public class CFG {
    private class List{
        public String name;    //S->
        public String[] productions;   //aaSa|a|?
        public List next;
        public boolean term=false;
        public List(String name, int n){
            this.name = name;
            productions = new String[n];
            next = null;
        }
        public void setProd(int i,String prod){
            productions[i] = prod;
        }
        public String getProd(int n){
            return productions[n];
        }
        public String getName(){
            return name;
        }
        public List getNext(){
            return next;
        }
        public int getProdSize(){
            return productions.length;
        }
        public boolean contains(String str){
            for(int i=0;i<productions.length;i++){
               if(productions[i].contains(str)){
                  return true; 
               } 
            }
            return false;
        }
        public boolean getTerminables(){
            int terminates=0;
            for(int i=0;i<productions.length;i++){
                for(int j=0;j<productions[i].length();j++){
                    if(productions[i].charAt(j)>='a'){
                        terminates++;
                        if(terminates==productions[i].length())
                        {
                            return true;
                        }
                    }
                }
                terminates=0;
            }
            return false;
        }
        public void removeProd(String nm){
            int removed=0,newProdInd=0;
            for(int i=0;i<productions.length;i++){
                if(productions[i].contains(nm)){
                    removed++;
                    productions[i]="";
                }
            }
            String[] newProd = new String[productions.length-removed];
            
            for(int i=0;i<productions.length;i++){
                if(productions[i].length()!=0){
                    newProd[newProdInd]=productions[i];
                    newProdInd++;
                }
            }
            productions=newProd;
        }
        
        public void replaceProd(String nm){
            
            for(int i=0;i<productions.length;i++){
                if(productions[i].contains(nm)){
                    
                    productions[i]="aa";
                }
            }
            
        }
        public void addProd(String nm){
            String[] newProd = new String[productions.length+1];
            for(int i=0;i<productions.length;i++){
                newProd[i]=productions[i];
            }
            newProd[productions.length]=nm;
            productions=newProd;
            
        }
        public void insertProds(List h){
            for(int i=0;i<h.getProdSize();i++){
                addProd(h.productions[i]);
            }
        }
        public void rid(){
            int numNull=0,newProdI=0;
            String newProd[];
            for(int i=0;i<productions.length;i++){
                if(productions[i].equals("")){
                    numNull++;
                }
            }
            newProd=new String[productions.length-numNull];
            for(int i=0;i<productions.length;i++){
                if(!productions[i].equals("")){
                    newProd[newProdI]=productions[i];
                    newProdI++;
                }
            }
            productions=newProd;
        }
    }
    private List Head;  //head won't hold data
    private int size;
    public CFG(int n){
        Head = new List("", 0);
        size=n;
    }
    public List head(){
        return Head;
    }
    
    public List next(){
        return Head.next;
    }
    public int size(){
        return size;
    }
    public void removeNode(String nm){
        List h =Head;
        for(int i=0;i<size;i++){
            if(h.next!=null&&h.next.name.equals(nm)){
                h.next=h.next.next;
            }
            h=h.next;
        }
        size--;
    }
    public void initializeList(){
        List h = Head;
        for(int i=0;i<size;i++){
            Scanner in = new Scanner(System.in);
            
            System.out.println("What is the name of this variable?(S->x; name='S')");
            String name = in.nextLine();
            
            System.out.println("How many productions does this variable have?(S->x|y|?; numOfProd=3)");
            int num = in.nextInt();
            h.next=new List(name,num);
            System.out.println("Type all the productions for this variable if any exists.\nex.\tabSa\n\tbb");
            
            for(int j=0 ;j<num; j++){
                String prod=in.next();
                h.next.setProd(j, prod);
            }
            h=h.getNext();
        }
    }
    public void printCFG(){
        List h= Head; 
        System.out.print("\n"+h.getName());
        if(size>0){
            while(h.next!=null){
                if(h.next.getProdSize()!=0&&!h.next.getName().equals("D")){
                    System.out.print(h.next.getName() +" -> ");
                    System.out.print(h.next.getProd(0));
                }
                for(int i=1;i<h.next.getProdSize()&&!h.next.getName().equals("D");i++){
                    System.out.print("|"+h.next.getProd(i));
                }
                System.out.println();
                h=h.next;
            }
        }
    }
    public void removeLambda(boolean[] term,boolean[] lam){
        List h=Head.next;
        h.addProd("a");
        for(int i=0;i<size;i++){
            if(h.contains("?")){
                h.replaceProd("?");
            }
            h=h.next;
        }
    }
    
    public void removeUnit(){
       List h=Head.next,otherh=Head.next;
       for(int i=0;i<size;i++){
           for(int j=0;j<h.getProdSize();j++){
               if(h.productions[j].length()==1&&h.productions[j].charAt(0)>='A'){
                   otherh=Head.next;
                   for(int k=0;k<size;k++){
                       if(h.productions[j].equals(otherh.name))
                       {
                           h.insertProds(otherh);
                           h.productions[j]="";
                       }
                       otherh=otherh.next;
                   }
                   
                   
               }
           }
           h=h.next;
       }
       removeNull();
    }
    
    public void removeUseless(boolean[] term,boolean[] lam,String[] vars){
        String [] useless;
        int numUseless=0;
        for(int i=0;i<size;i++){
            if(!term[i]&&!lam[i]){
                numUseless++;
            }
        }
        useless=new String[numUseless];
        int uselessInd=0;
        for(int i=0;i<size;i++){
            if(!term[i]&&!lam[i]){
                useless[uselessInd]=vars[i];
                uselessInd++;
            }
        }
        for(int i=0;i<size;i++){
            if(!term[i]&&!lam[i]){
                removeNode(vars[i]);
            }
        }
        List h=Head.next;
        for(int i=0;i<size;i++){
            for(int j=0;j<useless.length;j++){
                h.removeProd(useless[j]);
            }
            h=h.next;
        }
    }
    public void getVars(String[] vars){
        List h = Head.next;
        for(int i=0;i<size;i++){
            vars[i]=h.name;
            h=h.next;
        }
    }
    public void getNonUseless(boolean[] term,boolean[] lam){
        List h = Head.next;
        for(int i=0;i<size;i++){
            if(h.contains("?")){
                lam[i]=true;
            }
            else{
                lam[i]=false;
            }
            h=h.next;
        }
        h=Head.next;
        for(int i=0;i<size;i++){
            term[i]=h.getTerminables();
            h=h.next;
        }//
        h=Head.next;
        List h2;
        for(int i=0;i<size;i++){
            h2=Head.next.next;
            for(int j=1;j<size;j++){
                if(h.contains(h2.name)&&!term[i]&&!lam[i]){
                    term[j]=false;
                }
                h2=h2.next;
            }
            h=h.next;
        }//
        List[] useless,useful;
        int numUseless=0;
        for(int i=0;i<size;i++){
            if(!term[i]&&!lam[i])
                numUseless++;
        }
        useless=new List[numUseless];
        useful=new List[size-numUseless];
        h=Head.next;
        int uI1=0,uI2=0;
        for(int i=0;i<size;i++){
            if(!term[i]&&!lam[i]){
                useless[uI1]=h;
                uI1++;
            }
            else{
                useful[uI2]=h;
                uI2++;
            }
                
            h=h.next;
        }
        //
        
        for(int i=0;i<useless.length;i++){
            for(int j=0;j<useless[i].getProdSize();j++){
                for(int k=0;k<useful.length;k++){
                    if(useless[i].productions[j].contains(useful[k].name)){
                        useless[i].term=true;
                    }
                }
            }
        }
        
        //
        h=Head.next;
        for(int i=0;i<size;i++){
            if(!term[i]&&h.term){
                term[i]=true;
            }
            h=h.next;
        }
        //
    }
    public void removeNull(){
        List h =Head.next;
        int areNull=0;
        List[] haveNull;
        int[] numNull =new int[size];
        for(int i=0;i<size;i++){
            for(int j=0;j<h.getProdSize();j++){
                if(h.productions[j].equals("")){
                    areNull++;
                    break;
                }
            }
            h=h.next;
        }
        haveNull=new List[areNull];
        h=Head.next;
        int nullI=0;
        for(int i=0;i<size;i++){
            for(int j=0;j<h.getProdSize();j++){
                if(h.productions[j].equals("")){
                    haveNull[nullI]=h;
                    nullI++;
                    break;
                }
            }
            h=h.next;
        }
        for(int i=0;i<haveNull.length;i++){
            haveNull[i].rid();
        }
    }
}