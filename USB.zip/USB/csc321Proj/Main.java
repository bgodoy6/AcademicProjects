import java.io.*;

public class Main {

    public static void main(String args[]) {
        // command args ignored
        Parser parser = new Parser(new Scanner(
                     new DataInputStream(System.in)));

        System.out.println(" This program illustrates recursive descent parsing using a");
        System.out.println(" procedural approach.");
        System.out.println("The grammar:");
        System.out.println("\t statement  => { expression  \";\" } \".\"");
        System.out.println("\t expression => term { ( \"+\" | \"-\" ) term }");
        System.out.println("\t term       => factor { ( \"*\" | \"/\" ) factor }\");\"");
        System.out.println("\t factor     => number | \"(\" expression \")\")\");\" ");
        System.out.println("\n\t expressions are terminated by  ; and statement by  . ");
        System.out.print("\n\n\t Enter a statement: ");
    
        parser.run( );
        System.out.println("done");
    } // main
        
} // class Test
