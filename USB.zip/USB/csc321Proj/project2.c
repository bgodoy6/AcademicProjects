
#include <stdio.h>

/*

    Author: Gerardo Martinez, Brian Godoy, Sean Bernstein,Carlos Ramirez 

*/

void showbits(long *data,int databytes){    //the largest possible pointer and number of byte
	for(int i=databytes*8-1;i>=0;i--){        //i becomes the number of bits minus 1

  		long value = *data >> (long)i;        

  		if ((value & 1) == 1)        //if the rightmost bit equals 1 the number �1� is printed

   			printf("1");

  		else                //otherwise the number �0� is printed

   			printf("0");

  		if(i%8==0)    //on the 8th digit it will print space to separate all the bits

    			printf(" ");

 		}        //every bit should be printed once the loop ends

 	printf("\n");    //after printing all the bits it will skip a line

}


int main() {

 	long * dataP;



 	for(int j=0;j<4;j++){    //the program will ask for inputs of different types four times

  		int i;

  		printf("Enter an int: ");

  		scanf("%d",&i);

  		dataP = (long)&i;

  		showbits(dataP,sizeof(i));

	
  		float f;

  		printf("Enter a float: ");

  		scanf("%f",&f);

  		dataP = (long)&f;

  		showbits(dataP,sizeof(f));


  		char c;

  		printf("Enter a char: ");

  		scanf("%c",&c);

  		dataP = (long)&c;

  		showbits(dataP,sizeof(c));


  		short s;

  		printf("Enter a short: ");

  		scanf("%h",&s);

  		dataP = (long)&s;

  		showbits(dataP,sizeof(s));


  		double d;

  		printf("Enter a double: ");

  		scanf("%lf",&d);

  		dataP = (long)&d;

  		showbits(dataP,sizeof(d));


  		long l;

  		printf("Enter a long: ");

  		scanf("%ld",&l);

  		dataP = (long)&l;

  		showbits(dataP,sizeof(l));


  		long long ll;

  		printf("Enter a long long: ");

  		scanf("%ll",&ll);

  		dataP = (long)&ll;

  		showbits(dataP,sizeof(ll));

 	}

 	return 0;
}
