/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public class Node {
    //data fields
    Object data;    //data
    Node next;      //pointer
    
    //constructor
    public Node(Object data)
    {
        this.data = data;
        this.next = null;
    }
    
}
