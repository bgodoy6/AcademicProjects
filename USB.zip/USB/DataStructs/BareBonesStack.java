/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public interface BareBonesStack <E>{
    E push(E obj);
    E pop();
    E peek();
    boolean empty();
}
