/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public class ArrayStack<E> implements BareBonesStack<E> {

    //storage for stack
    private E[] theData;
    private int topOfStack = -1;
    private static final int INITIAL_CAPACITY=10;
    public ArrayStack(){
        this.theData = (E[])new Object[INITIAL_CAPACITY];
    }
    @Override
    public E push(E obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //this method adds elements if  there's space
        //check if stack is full
        if(topOfStack==this.theData.length-1)
        {
            System.out.println("Stack Overflow");
            return null;
        }
        topOfStack++;
        this.theData[topOfStack]=obj;
        return obj;
    }

    @Override
    public E pop() {
        //checks for emptiness and returns top
        if(empty()){
            System.out.println("Stack Underflow");
            return null;
        }
        return theData[topOfStack--];
    }

    @Override
    public E peek() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(empty()){
            System.out.println("Stack Underflow");
            return null;
        }
        return theData[topOfStack];
    }

    @Override
    public boolean empty() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return(topOfStack == -1);
    }
    public void display(){
        System.out.print("Stack: ");
        for(int i = 0;i<= topOfStack;i++)
        {
            System.out.print(theData[i]+" | ");
        }
        System.out.println();
    }
    
}
