/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj1;
import java.util.Scanner;
/**
 *
 * @author brian godoy
 */
public class Proj1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String[] teamNames = new String[8], winningPerc = new String[8];
        //these strings store the team names and their winning percentages 
        String[][] draftedPlayerData = new String[8][4];
        //this two dimensional array stores the player's names
        //the 8 represents the team based off ranks and the 4 represents the round they were drafted
        inputTeamInfo(winningPerc,teamNames);
        //the team names and their winning percent will be stored and tied to one index
        //the user will be prompted to input a team name followed by a percent
        sortByPerc(winningPerc,teamNames);
        //the team names are sorted in order from lowest to highest winning percent
        //the winning percents will contain the same index as its team
        displayRank(winningPerc,teamNames);
        //the teams and their rank will be displayed
        //the teams should be ranked lowest to highest winning percent
        inputPlayerData(draftedPlayerData);
        //the two dimensional array will be filled, players will be chosen by teams
        //the teams will go in order starting with rank 1, this will be done 4 times
        outputPlayerData(draftedPlayerData,teamNames);
        //the player's name, team, and round they were drafted will display
    }
    public static void inputTeamInfo(String[] nums,String[] teams)
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the team name first then their winning percent:");
        for(int i = 0; i<8;i++)
        {
            System.out.print("The ");
            teams[i] = scan.nextLine();
            System.out.print("had a winning percentage of ");
            nums[i] = scan.nextLine();
        }
        System.out.println("");
        /**
        This function will prompt the user to input a team name and winning percent
        *The {enter team name}
        *had a winning percent of {enter a winning percent}
         */
    }
    public static void sortByPerc(String[] nums,String[] teams)
    {
        String temp;
        for(int i =0;i<nums.length-1;i++)
        {
            for(int j =i+1;j<nums.length;j++)
            {
                if(Double.parseDouble(nums[i])>Double.parseDouble(nums[j]))
                {
                    temp = nums[j];
                    nums[j] = nums[i];
                    nums[i] = temp;
                    temp = teams[j];
                    teams[j] = teams[i];
                    teams[i] = temp;
                }
            }
        }
        /**
        this is just a bubble sort that will swap both the winning percent and names
        * this will keep the percentage and name tied to one index
         */
    }
    public static void displayRank(String[] nums,String[] teams)
    {
        System.out.println("After sorting the data is:");
        for(int i = 0;i<8;i++)
        {
            System.out.println("The "+teams[i]+" is ranked "+(i+1));
        }
        System.out.println("");
        /**
         This should display a team name followed by a rank
         *the team with rank 1 should be displayed first followed by the team with rank 2
         * and so on
         */
    }
    
    public static void inputPlayerData(String[][] players)
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter draftees, they will be selected inorder based off the team's rank:");
        for(int i=0;i<4;i++)
        {
            for(int j =0;j<8;j++)
            {
                System.out.print("The selected draftee for Round "+(i+1)+" is ");
                players[j][i] = scan.nextLine();
        
            }
        }
        System.out.println("");
        /**
         this will prompt the user to input the name of a player to be drafted (the draftee)
         *for round 1 of the drafting the teams will pick a player based off rank
         * first rank 1 then rank 2 and so on
         * this will go on for 4 rounds
        */
    }
    public static void outputPlayerData(String[][] players,String[] teams)
    {
        for(int i=0;i<4;i++)
        {
            for(int j=0;j<8;j++)
            {    
                System.out.println("Round :"+(i+1)+" Team: "+teams[j]+" selected: "+players[j][i]);
            }
            System.out.println("");//this skips a line between rounds
        }
        /***
        This will output the players data such as the round they were drafted the
        * team that drafted them and their name for each individual player
         * */
    }
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj1;
import java.text.DecimalFormat;
/**
 *
 * @author brian godoy
 */
public class Proj1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String[] teamNames = new String[8], winningPerc = new String[8];
        //these strings store the team names and their winning percentages 
        String[][] draftedPlayerData = new String[8][4];
        //this two dimensional array stores the player's names
        //the 8 represents the team based off ranks and the 4 represents the round they were drafted
        String[][] playersInOrder = new String[8][4];
        inputTeamInfo(winningPerc,teamNames);
        //the team names and their winning percent will be stored and tied to one index
        //the percent is Random and
        sortByPerc(winningPerc,teamNames);
        //the team names are sorted in order from lowest to highest winning percent
        //the winning percents will contain the same index as its team
        displayTeamAndPerc(winningPerc, teamNames);
        
        displayRank(winningPerc,teamNames);
        //the teams and their rank will be displayed
        //the teams should be ranked lowest to highest winning percent
        inputPlayerData(draftedPlayerData);
        //the two dimensional array will be filled, players will be chosen by teams
        //the teams will go in order starting with rank 1, this will be done 4 times
        outputRoundAssignment(draftedPlayerData, playersInOrder);
        outputPlayerData(draftedPlayerData,teamNames);
        //the player's name, team, and round they were drafted will display
    }
    public static void inputTeamInfo(String[] nums,String[] teams)
    {
        teams[0] = "";
        teams[1] = "";
        teams[2] = "";
        teams[3] = "";
        teams[4] = "";
        teams[5] = "";
        teams[6] = "";
        teams[7] = "";
        nums[0] = Math.random()*100+"";
        nums[1] = Math.random()*100+"";
        nums[2] = Math.random()*100+"";
        nums[3] = Math.random()*100+"";
        nums[4] = Math.random()*100+"";
        nums[5] = Math.random()*100+"";
        nums[6] = Math.random()*100+"";
        nums[7] = Math.random()*100+"";
        /**
        This function will input a team name and a random win percent in a string form
         */
    }
    public static void sortByPerc(String[] nums,String[] teams)
    {
        String temp;
        for(int i =0;i<nums.length-1;i++)
        {
            for(int j =i+1;j<nums.length;j++)
            {
                if(Double.parseDouble(nums[i])>Double.parseDouble(nums[j]))
                {
                    temp = nums[j];
                    nums[j] = nums[i];
                    nums[i] = temp;
                    temp = teams[j];
                    teams[j] = teams[i];
                    teams[i] = temp;
                }
            }
        }
        /**
        this is just a bubble sort that will swap both the winning percent and names
        * this will keep the percentage and name tied to one index
         */
    }
    public static void displayTeamAndPerc(String[] nums,String[] teams)
    {
        DecimalFormat fmt = new DecimalFormat("#.##");
        for(int i = 0;i<8;i++)
        {
            System.out.println("The "+teams[i]+" won "+fmt.format(nums[i])+" of their games last season!");
        }
        System.out.println("");
        /**
         This should display a team name followed by a rank
         *the team with rank 1 should be displayed first followed by the team with rank 2
         * and so on
         */
    }
    public static void displayRank(String[] nums,String[] teams)
    {
        System.out.println("After sorting the data is:");
        for(int i = 0;i<8;i++)
        {
            System.out.println("The "+teams[i]+" is ranked "+(i+1));
        }
        System.out.println("");
        /**
         This should display a team name followed by a rank
         *the team with rank 1 should be displayed first followed by the team with rank 2
         * and so on
         */
    }
    
    public static void inputPlayerData(String[][] players)
    {
        players[0][0]="Julius Caesar";
        players[0][1]="Mario Firenze";
        players[0][2]="Ezio Auditore";
        players[0][3]="Niles Edgworth";
        players[1][0]="Odin Dark";
        players[1][1]="Frederick Ylisse";
        players[1][2]="Leo Lyon";
        players[1][3]="Niccolo Machiaveli";
        players[2][0]="Albert Einstein";
        players[2][1]="Isaac Newton";
        players[2][2]="Will Shakespeare";
        players[2][3]="Tom Sawyer";
        players[3][0]="Kobe Bryant";
        players[3][1]="Michael Jordan";
        players[3][2]="Sammy Sosa";
        players[3][3]="Tiger Woods";
        players[4][0]="Ares Mars";
        players[4][1]="Zeus Jupiter";
        players[4][2]="Steven Hawking";
        players[4][3]="Neil Tyson";
        players[5][0]="Bill Nye";
        players[5][1]="Muhammad Ali";
        players[5][2]="Vergil Quintus";
        players[5][3]="Hernan Cortez";
        players[6][0]="Michael Jackson";
        players[6][1]="Poseidon Neptune";
        players[6][2]="Thor Valhalla";
        players[6][3]="Loki Fenrir";
        players[7][0]="Bill Gates";
        players[7][1]="Steve Jobs";
        players[7][2]="Thomas Jeferson";
        players[7][3]="John Adams";
        System.out.println("");
        /**
         this will input player data into the 2d array
        */
    }
    public static void roundAssignment(String[][] players,String[][] inOrder)
    {
        int assignedRound,playersInRound1=0,playersInRound2=0,playersInRound3=0,playersInRound4=0;
        for(int i=0;i<8;i++)
        {    
            for(int j=0;j<4;j++)
            {
                while(true)
                {
                    assignedRound = (int)Math.floor(Math.random()*4);
                    if(playersInRound1<8 && assignedRound==0)
                    {
                        inOrder[playersInRound1][assignedRound] = players[i][j];
                        playersInRound1++;
                        break;
                    }
                    else if(playersInRound1<2 && assignedRound==1)
                    {
                        inOrder[playersInRound2][assignedRound] = players[i][j];
                        playersInRound2++;
                        break;
                    }
                    else if(playersInRound3<8 && assignedRound==2)
                    {
                        inOrder[playersInRound3][assignedRound] = players[i][j];
                        playersInRound3++;
                        break;
                    }
                    else if(playersInRound4<8 && assignedRound==3)
                    {
                        inOrder[playersInRound4][assignedRound] = players[i][j];
                        playersInRound4++;
                        break;
                    }
                    else{
                        //this scenario only causes the next iteration
                    }
                }
                System.out.println(players[i][j]+" has been selected to be drafted in Round "+assignedRound);
            }
        }    
        System.out.println("");//this skips a line between rounds
        /***
        This will output the players round that they were drafted randomly in
         * and place them in an array which will use the index as a way to 
         * determine the players round they were chosen for
         */
    }
    public static void outputPlayerData(String[][] players,String[] teams)
    {
        boolean playersLeft[] = new boolean[8];
        int randomPlayer;
        for(int i=0;i<4;i++)
        {
            playersLeft[0]=true;
            playersLeft[1]=true;
            playersLeft[2]=true;
            playersLeft[3]=true;
            playersLeft[4]=true;
            playersLeft[5]=true;
            playersLeft[6]=true;
            playersLeft[7]=true;
            for(int j=0;j<8;j++)
            {    
                while()
                {
                    randomPlayer = (int)Math.floor(Math.random()*8);
                }
                System.out.println("Round :"+(i+1)+" Team: "+teams[j]+" selected: "+players[j][i]);
            }
            System.out.println("");//this skips a line between rounds
        }
        /***
        This will output the players data such as the round they were in, the
        * team that drafted them randomly, and their name for each individual player.
        * This function randomly drafts a player for the team in order
         * */
    }
}
