﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author juventino
 */
public class main {
    static ItemStack items = new ItemStack();
    public static void main(String[] args)  {
        int[] choice=new int[1];    //the array int will be helpful in function in case 2 of the initial menu choice in case there's a login failure
        choice[0]=0;
        Scanner scanInput = new Scanner(System.in);
        while(choice[0]!=1&&choice[0]!=2&&choice[0]!=3) //user will be put in a loop until a proper login was made or the other options were chosen
        {
            initialMenuOptions();
            choice[0] = scanInput.nextInt();
            initialMenuChoice(choice);
        }
        if(choice[0]==3)
            choice[0]=9;
        while(choice[0]!=9) //until user logs out they will stay in the loop
        {
            menuOptions();
            choice[0] = scanInput.nextInt();
            menuChoice(choice[0]);
        }
    }
    public static void menuOptions(){
        System.out.print("1. Register client and create client login (client supplies the clientID and password, and the clientID " +
        "must be unique)\n" +
        "2. Login existing client\n" +
        "3. Add a food item client ate\n" +
        "4. Check the complete history of food a client ate in a day in reverse order (all food items listed here " +
        "from dinner to breakfast)\n" +
        "5. Check all the diﬀerent types of food items a client ate in a day (all food items listed here only once)\n" +
        "6. Total calories eaten in a day\n" +
        "7. Food with the maximum calorie in a day\n" +
        "8. Food that the client ate maximum number of times in a day\n" +
        "9. Logout\n"+
        "Enter a menu option: ");
    }
    public static void menuChoice(int choice){
        switch(choice){
            case 1:
                register();
                items = new ItemStack();    //the old stack is replaced for the newly registered user
                System.out.println();   //skips extra line for the menu
                break;
            case 2:
                if(!logIn())    //if login fails nothing happens
                    System.out.println("You will remain loogged in as the most recently logged in user.");
                else        //if succesful //the old stack is replaced for the newly registered user
                    items = new ItemStack();
                System.out.println();
                break;
            case 3:
                addFood();      //pushes item to the stack
                System.out.println();
                break;
            case 4:
                items.displayReverse(); //displays items in reverse w/ repeats
                System.out.println();
                break;
            case 5:
                items.display();    //displays items in reverse w/o repeats
                System.out.println();
                break;
            case 6:
                items.calorieCount();   //prints all calories eaten
                System.out.println();
                break;
            case 7:
                items.maxCalItem();     //prints item with the most calories
                System.out.println();
                break;
            case 8:
                items.maxAmountItem();  //prints item that was eaten the most
                System.out.println();
                break;
            case 9:
                System.out.print("Logging  out.\n");
                break;
            default:
                System.out.print("This feature doesn't exist.\n\n");
                break;
        }
    }
    public static void initialMenuOptions(){    //the program starts by logging in a user, registering or logging out these are the options
        System.out.print("1. Register client and create client login (client supplies the clientID and password, and the clientID " +
        "must be unique)\n" +
        "2. Login existing client\n" +
        "3. Logout\n"+
        "Enter a menu option: ");
    }
    public static void initialMenuChoice(int[] choice){ //the program starts by logging in a user, registering or logging out these are the choices
        switch(choice[0]){
            case 1:
                register();
                System.out.println();
                break;
            case 2:
                if(!logIn())
                    choice[0]=0;
                System.out.println();
                break;
            case 3:
                System.out.print("Logging  out.\n");
                break;
            default:
                System.out.print("This feature doesn't exist.\n\n");
                break;
        }
    }
    public static void register(){     //a user can't leave this method w/o a proper registration
        //the user enters info for their account
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your first name:");
        String accFirstName = input.nextLine();
        System.out.println("Enter your last name:");
        String accLastName = input.nextLine();
        
        try{
            File file = new File("UserInfo.txt");
            if(!file.exists()){ //if file "UserInfo.txt" doesn't exist a new file will be created
                System.out.println("A new file will be created for userIDs and passwords.");
                file.createNewFile();
            }
            //the rest of the necessary data is created
            Scanner fileScan = new Scanner(file);
            String userID,passWord="";
            int i =0;
            boolean uniqueID=true;
            do{
                
                System.out.println("Enter a unique userID after two attempts one will be generated for you if it isn't unique:");
                userID = input.nextLine(); 
                while(fileScan.hasNextLine()){  //file will be checked if it has data //it only compares ids and not passwords
                    if(userID.equals(fileScan.nextLine())){ //if an id isn't unique it will be flagged 
                        uniqueID=false;
                    }
                    else    //this may seem redundant but it eliminates an error if false initially then it can't become true w/o this
                        uniqueID=true;
                    fileScan.nextLine();
                }
                fileScan = new Scanner(file);   //restarts to the beggining of the file
                i++;
            }while(i<2&&!uniqueID);//user will be asked a unique id after 2 tries one will be generated
            
            if(!uniqueID){  //if id wasn't unique it will be generated based off lastname
                if(accLastName.length()<8)//id must be 8 chars if the lastname is long it will take a 7 characters from the last name and generate the last one
                    userID = accLastName+generator(accLastName.length());    //id = a combination of lastname chars and the randomly generated chars
                else
                    userID = accLastName.charAt(0)+accLastName.charAt(1)+accLastName.charAt(2)+accLastName.charAt(3)+accLastName.charAt(4)+accLastName.charAt(5)+accLastName.charAt(6)+generator(7);
                System.out.println("A unique userID will be created for you it is:\n"+userID);
            }
            
            while(passWord.length()<8)  //password must be 8 chars long
            {
                System.out.println("Enter a password of at least 8 characters in length or else you'll have to retry:");
                passWord = input.nextLine();
            }
            //the user id and password will be written to a file w/o overwriting in the following format
            //userid
            //password
            //userid
            //password
            //etc.
            PrintWriter output = new PrintWriter(new FileWriter("UserInfo.txt",true));
            output.println(userID);
            output.println(passWord);
            output.close();
            
        }
        catch(IOException e)
        {
            System.out.println(e);
        }
    }
    public static boolean logIn(){
        File file = new File("UserInfo.txt");
        if(!file.exists()){
            System.out.println("A user has yet to be registered please register first.");
            return false;   //this is to check if the file doesn't exist
        }
        else{   //file exists
            try{
                //this is the necessary data
                Scanner fileScan = new Scanner(file);
                Scanner input = new Scanner(System.in);
                String userID,passWord;
                //username is inputted and goes through a loop
                System.out.println("Enter a user ID:");
                userID = input.nextLine();
                while(fileScan.hasNextLine()){  //checks for remaining data
                    if(userID.equals(fileScan.nextLine())){ //if userid matches with a file id they must enter the corresponding password
                        System.out.println("Enter the password:");
                        passWord = input.nextLine();
                        if(passWord.equals(fileScan.nextLine())){
                            System.out.println("You have succesfully logged in.");
                            return true;    //if password and user name match login succeeds
                        }
                        else{
                            System.out.println("The password you entered was incorrect please retry or choose another option.");
                            return false;   //if id matches but not password login will fail
                        }
                    }
                    fileScan.nextLine();
                }
                
            }
            catch(IOException e)
            {
                System.out.println(e);
            }
        }
        System.out.println("The user ID you entered doesn't exist please retry or choose another option.");
        return false;   //if userid doesn't exist in the file
    }
    public static String generator(int size)
    {
        if(size>=7) //the length of the lastname will determine how many chars need to be generated
            size=1;
        else
            size = 8-size;
        String generated="";
        int extra, random;
        for(int i = 0;i<size;i++)   //it will generate a certain amount of random chars
        {
            random=(int)Math.floor(Math.random()*62);   //62 is the number of letters and digits [range]
            if(random<10)
                extra=0+48; //the digits start at char code 48
            else if(random<36)
                extra=7+48;//the uppercase start at char code 101
            else
                extra=7+6+48;//the lowercase start at char code 141
            generated += (char)(extra+random);  //the domain should be the char codes for letters and digits
        }
        return generated;   //the necessary amount of chars are returned
    }
    public static void addFood()    //food item description and amount eaten are added here
    {
        //asks for input
        Scanner input = new Scanner(System.in);
        System.out.println("Type the food name:");
        String name = input.nextLine();
        System.out.println("Type the calories in the food:");
        int mealType=-1,cal = input.nextInt();
        while(mealType!=0&&mealType!=1&&mealType!=2&&mealType!=3)
        {
            System.out.println("Type the food type: 0 = breakfast, 1 = lunch, 2 = snacks, and 3 = dinner:");
            mealType = input.nextInt();
        }
        //changeAndCheckAmount returns the amount of a paricular item, the amount is how many duplicates are in the stack with the same name
        //checksForReplicas returns false if name doesn't have replicas and returns true otherwise
        items.push(new Item(name,items.changeAndCheckAmounts(name),cal,mealType,items.checkForReplicas(name)));
    }
}
