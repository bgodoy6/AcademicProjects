/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author juventino
 */
public class ItemStack {
    
    //storage for stack
    private Item[] theData;
    private int topOfStack = -1;
    private static final int INITIAL_CAPACITY=100;
    public ItemStack(){
        this.theData = new Item[INITIAL_CAPACITY];
    }
    public Item push(Item obj) {
        //this method adds elements if  there's space
        //check if stack is full
        if(topOfStack==this.theData.length-1)
        {
            System.out.println("Stack Overflow");
            return null;
        }
        topOfStack++;
        this.theData[topOfStack]=obj;
        return obj;
    }

    
    public Item pop() {
        if(empty()){
            System.out.println("Stack Underflow");
            return null;
        }
        return theData[topOfStack--];
    }

    public Item peek() {
        if(empty()){
            System.out.println("Stack Underflow");
            return null;
        }
        return theData[topOfStack];
    }

    public boolean empty() {
        return(topOfStack == -1);
    }
    public int changeAndCheckAmounts(String name){
        int amount = 1; //this assumes no replicas exist
        for(int i = 0;i<= topOfStack;i++)   //checks for replicas
        {
            if(theData[i].getName().equals(name)){  //if a replica exists the amount increments by one and is also stored in the variable to return it
                theData[i].setAmount(theData[i].getAmount()+1);
                amount = theData[i].getAmount();
            }
        }
        return amount;  //this returns th replicas + the one being added
    }
    public boolean checkForReplicas(String name){
        for(int i = 0;i<= topOfStack;i++)   //checks for a replica of name
        {
            if(theData[i].getName().equals(name))
                return true;    //this means a replica exists and the new item will be labeled as one
        }
        return false;   //this means a replica doesn't exist and the new item will not be labeled as one
    }
    public void display(){//this displays the stack from the bottom up and will NOT print duplicates
        for(int i = 0;i<= topOfStack;i++)
        {
            if(!theData[i].getReplica())
                System.out.print(theData[i].getName()+" | ");
        }
        System.out.println();
    }
    public void displayReverse(){   //this displays the stack from the top down and will print duplicates
        for(int i = topOfStack;i >= 0 ;i--)
        {
            System.out.print(" | "+theData[i].getName());
        }
        System.out.println();
    }
    public void calorieCount(){ //it will add the calories of all food items including duplicates so for example eating 2 apples will count as double the calories
        int totalCalories=0;    //if stack is empty calories eaten = 0
        for(int i = 0;i<= topOfStack;i++)   //adds all calories
        {
            totalCalories += theData[i].getCalories();
        }
        System.out.println(totalCalories);
    }
    public void maxCalItem(){   //it will print an item with the highest calories
        int indexOfMaxCal=0;
        for(int i = 0;i<= topOfStack;i++)   //searches all
        {
            if(theData[indexOfMaxCal].getCalories()<theData[i].getCalories())
                indexOfMaxCal=i;
        
        }
        System.out.println("The food you ate with the most calories is "+theData[indexOfMaxCal].getName()
                +" at "+theData[indexOfMaxCal].getCalories()+".");
    }
    public void maxAmountItem(){    //print's an item that was eaten the most times
        int indexOfMaxAmount=0;
        
        for(int i = 0;i<= topOfStack;i++)   //searches all
        {
            if(theData[indexOfMaxAmount].getAmount()<theData[i].getAmount())
                indexOfMaxAmount=i; //replaces index of the previous max amount
        }
        System.out.println("The food you ate the most of is "+theData[indexOfMaxAmount].getName()
                +" eaten "+theData[indexOfMaxAmount].getAmount()+" times.");
    }
    
}
