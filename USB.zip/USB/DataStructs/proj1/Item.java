/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author juventino
 */
public class Item {
    private String name;        //food name
    private int amount;         //amount eaten
    private int calories;       //# of calories in item
    private int mealType;       //0 = breakfast,1 = lunch,2=snacks,3=dinner
    private boolean replica;    //true if there's a copy in the stack
    
    public Item(){
        this("",0,0,-1,false);
    }
    public Item(String name,int amount,int calories,int mealType, boolean replica){
        this.name=name;
        this.amount=amount;
        this.calories=calories;
        this.mealType=mealType;
        this.replica = replica;
    }
    public String getName(){
        return name;
    }
    public int getAmount(){
        return amount;
    }
    public int getCalories(){
        return calories;
    }
    public int getMealType(){
        return mealType;
    }
    public boolean getReplica(){
        return replica;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setAmount(int amount){
        this.amount = amount;
    }
    public void setCalories(int calories){
        this.calories = calories;
    }
    public void setMealType(int mealType){
        this.mealType=mealType;
    }
    public void setReplica(boolean replica){
        this.replica = replica;
    }
}
