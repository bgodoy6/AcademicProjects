/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Brian
 */
// the data

public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //initialize hash table
        Hash[] students2011 = new Hash[20],students2012 = new Hash[20],students2013 = new Hash[20];  
        HashTable graduates2017 = new HashTable();
        studentGenerator(students2011, 0);
        studentGenerator(students2012, 20);
        studentGenerator(students2013, 40);
        graduating2017(graduates2017,students2011,students2012,students2013);
        graduates2017.displayRates();
    }
    
    public static void studentGenerator(Hash[] hashes, int uniqueIds){
        //initializes the array of student info per class
        
        for(int i=uniqueIds;i<hashes.length+uniqueIds;i++)
        {
            hashes[i-uniqueIds] = new Hash();
            hashes[i-uniqueIds].id = i+1;
            hashes[i-uniqueIds].name = nameGenerator();
        }
    }
    
    public static String nameGenerator(){
        //generated stores 4 chars generated from the ascii code
        String generated = ""
                +(char)((int)Math.floor(Math.random()*26)+97)
                +(char)((int)Math.floor(Math.random()*26)+97)
                +(char)((int)Math.floor(Math.random()*26)+97)
                +(char)((int)Math.floor(Math.random()*26)+97);
        return generated;
    }
    
    public static void graduating2017(HashTable graduates,Hash[] class2011,Hash[] class2012,Hash[] class2013){
        //generates 0-10 then adds 15 to represent the number graduating 15-25
        int graduating = (int)Math.floor(Math.random()*11)+15; 
        //a class will be chosen 2011,2012,2013 then a student from that class
        int randomClass, randomStudent;
        //will keep track of students that have graduated
        boolean[] graduated = new boolean[60];
        //initializes array
        for(int i=0;i<60;i++){
            graduated[i] = false; 
        }
        //adds graduates to the hash table
        for(int i=0;i<graduating;i++){
            randomClass = (int)Math.floor(Math.random()*3);
            randomStudent = (int)Math.floor(Math.random()*20);
            if(graduated[randomClass*20+randomStudent]==true){
                i--;    //retries iteration if student already graduated
            }
            else{
                graduated[randomClass*20+randomStudent] = true;
                switch(randomClass){
                    case 1:
                        graduates.add(class2011[randomStudent].id, class2011[randomStudent].name);
                        break;
                    case 2:
                        graduates.add(class2012[randomStudent].id, class2012[randomStudent].name);
                        break;
                    default:    //case: 3
                        graduates.add(class2013[randomStudent].id, class2013[randomStudent].name);
                        break;
                }
            }
        }
    }
}