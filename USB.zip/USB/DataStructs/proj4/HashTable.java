/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author Brian
 */
class HashTable // Class to represent entire hash table
{
	// bucketArray is used to store array of chains
	public Hash[] hashArray;

	// Current capacity of array
	private int capacity;

	// Current number of elements
	private int size;

	// Constructor (Initializes capacity, size and empty chains.
	public HashTable()
	{
                hashArray = new Hash[60];
                capacity = 60;
		size = 0;
                
                for(int i = 0;i<capacity; i++)
                {
                    hashArray[i] = new Hash();
                }

	}

	public int capacity() { return capacity; }
	public int size() { return size; }
	public boolean isEmpty() { return size == 0; }
	
	//displays all elements
	public void display() { 
		for(int i=0;i<capacity;i++)
		{
			if(hashArray[i].id==0)
				System.out.print("key:"+i+" ");
			else
				System.out.print(hashArray[i].id+"-");
			if(hashArray[i].name==null)
				System.out.println("value:"+i+" ");
			else
				System.out.println(hashArray[i].name);
		} 
	}
	
        //displays all graduation rates
	public void displayRates() { 
                int graduating2011=0, graduating2012=0, graduating2013=0;
		for(int i=0;i<capacity;i++)
		{
			if(hashArray[i].id>40)
                        {graduating2011++;}
                        else if(hashArray[i].id>20)
                        {graduating2012++;}
                        else if(hashArray[i].id>0)
                        {graduating2013++;}
                        else
                        {/**if id is a dummy value*/}
		} 
                System.out.println("The graduation rates for the class of 2017:\n"
                + "The 4-year rate is " + (graduating2013*100.0/20) + "%\n"
                + "The 5-year rate is " + (graduating2012*100.0/20) + "%\n"
                + "The 6-year rate is " + (graduating2011*100.0/20) + "%\n");
	}
        
	// This implements hash function to find index for a key
	public int getArrayIndex(int key)
	{
		//converts key to string and adds a 0 to the front if key.length()==1
		String keyString = ((""+key).length()==2)?(""+key):("0"+key);
		
		//hash function
		int hashCode = keyString.charAt(0)*31 + keyString.charAt(1);
		
		return hashCode % capacity;
	}
	
	
	// Method to remove a given key
	public String remove(int key)
	{
		// Apply hash function to find index for given key
		int arrayIndex = getArrayIndex(key);

		// Get starting element
		String value = null;

                
		for(int i=0;hashArray[(arrayIndex+i)%capacity].id!=0;i++) 
		{
			if (hashArray[(arrayIndex+i)%capacity].id==key){
				arrayIndex = (arrayIndex+i)%capacity;
				value = hashArray[arrayIndex].name;		
				break;
			}
		}

		// If key was not there
		if (value==null)
			return null;

		// Reduce size
		size--;

		// Removes data
		hashArray[arrayIndex].name = null;
		hashArray[arrayIndex].id = -1;
		
		return value;
	}

	// Returns value for a key
	public String getValue(int key)
	{
		// Find head of chain for given key
		int arrayIndex = getArrayIndex(key);

		// Probes and ends just before repeating 
		for(int i=0;hashArray[(arrayIndex+i)%capacity].id!=0;i++) 
		{
			if (hashArray[(arrayIndex+i)%capacity].id==key)
				return hashArray[(arrayIndex+i)%capacity].name;
		}

		// If key not found
		return null;
	}

	// Adds a key value pair to hash
	public void add(int key, String value)
	{
		// Find index for given key
		int arrayIndex = getArrayIndex(key);
		
		// Check if key is already present and replaces it with the new value if already present
		for(int i=0;hashArray[(arrayIndex+i)%capacity].id!=0;i++)
		{
			if (hashArray[(arrayIndex+i)%capacity].id==key)
			{
				//replaces old value with new assuming it's different to begin with
				hashArray[(arrayIndex+i)%capacity].name = value;
				return;
			}
		}
		// Insert key in chain
		size++;
		for(int i=0;i<capacity;i++){
			if (hashArray[(arrayIndex+i)%capacity].id==-1||hashArray[(arrayIndex+i)%capacity].id==0)
                        {	
                            hashArray[(arrayIndex+i)%capacity].name = value;
                            hashArray[(arrayIndex+i)%capacity].id = key;
                            break;
                        }
                }
		// If load factor goes beyond threshold, then
		// double hash table size
		if ((1.0*size)/capacity >= 0.7)
		{
			Hash[] temp = hashArray;
			hashArray = new Hash[capacity*2];
			capacity *= 2;
			size = 0;
			//copie and initialize
                        for(int i = 0;i<capacity; i++)
                        {
                            hashArray[i] = new Hash();
                        }
			for (int i = 0;i<capacity/2; i++)
				add(temp[i].id, temp[i].name);

		}
	}
}

