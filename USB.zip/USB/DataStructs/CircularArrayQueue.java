/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public class CircularArrayQueue implements Queue{


    private Object[] Q;       //reference to actual Q
    private int front;
    private int rear;
    private int size;
    private int CAPACITY=5;      
    private static int defaultCAPACITY=5;  
    
    public Queue(){
        this(defaultCAPACITY);
    }
    
    public Queue(int begsize){
        this.CAPACITY = begsize;
        Q = new Object[CAPACITY];   //create the actual Q
        this.front=0;
        this.rear = this.CAPACITY-1;
        this.size=0;
    }
    
    public void offer(Object obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //this method adds an element,first check for space
        if(isFull()){
            System.out.println("Queue is full, calling reallocate.");
            this.reallocate();
        }
        size++;
        rear=(rear+1)%CAPACITY;
        Q[rear]=obj;
    }
    
    public void reallocate() {
        	//updates capacity to double
		Object[] temp=new Object[this.CAPACITY*2];
		//copy old array to new
		for(int i =front,j=0;j<size;i++){
			temp[j]=Q[i%CAPACITY];
		}
                
                this.CAPACITY*=2;
		this.Q=temp;
                front=0;
                rear=size;
    }
    
    public Object poll() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(isEmpty()){
            System.out.println("The queue is empty");
            return null;
        }
        Object result = Q[front];
        front = (front+1)%CAPACITY;
        size--;
        return result;
    }

    public boolean isEmpty() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return (size==0);
    }

    public boolean isFull() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return (size==CAPACITY);
    }

    public Object peek() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return Q[front];
    }

    public int size() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return size;
    }

    public void display() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        for(int i = 0; i< size;i++){
            System.out.print(Q[(front+i)%CAPACITY]+"|");
        }
        System.out.println();
    }
    
}

