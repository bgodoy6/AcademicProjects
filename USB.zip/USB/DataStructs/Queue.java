/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public interface Queue {
    public void offer(Object obj);  //adds elements
    public Object poll();           //removes elements and returns
    public boolean isEmpty();       
    public boolean isFull();
    public Object peek();           //no deleting
    public int size();              //how many elements
    public void display();          //display Q contents
}
