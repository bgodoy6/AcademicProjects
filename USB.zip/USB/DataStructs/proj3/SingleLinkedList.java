/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author bgodoy6
 */
public class SingleLinkedList {
    
    private Node head;  //head of link list
    private int size;   //number of nodes in the list
    
    public SingleLinkedList()
    {
        this.head = new Node(-1);   //creates head and store -1
        size = 0;                   //list is empty initially
    }
    
    //add methods
    //method that adds item to the beggining
    public void addFirst(Object item)
    {
        Node first = new Node(item);    //create node
        first.next = head.next;         //copy next of head to next of first
        head.next = first;              //update head next value
        size++;                         //increase size
    }
    
    //Method to add item after a given node reference
    public void addAfter(Node target,Object item)
    {
        Node insert = new Node(item);
        insert.next = target.next;
        target.next = insert;
        size++;
    }
    public void addLast(Object item)
    {
        //we'll use the get node method to retrieve the reference
        Node target = getNode(size);    //get last node
        addAfter(target,item);          //then call add after method
    }
    //helper method returns node reference at given index
    public Node getNode(int index)
    {
        if(index<0||index>size)
        {
            return null;
        }
        Node iter = head;
        for(int i = 0; i<index;i++)
        {
            iter=iter.next;
        }
        return iter;
    }
    public Object removeFirst()
    {
        if(size==0)
        {
            return null;
        }
        Node removed = head.next;
        head.next = head.next.next;
        size--;
        return removed.data;
    }
    
    
    //helper method to display contents of list
    
    public void printList()
    {
        Node temp = head;
        System.out.print("Deck: ");
        while(temp.next!=null)
        {
            Object data = temp.next.data;
            //the following switch statements convert the data to a card
            switch((int)data/10){
                case 0:
                    System.out.println("Nothing");
                    break;
                case 1:
                    System.out.print("Ace of ");
                    break;
                case 11:
                    System.out.print("Jack of ");
                    break;
                case 12:
                    System.out.print("Queen of ");
                    break;
                case 13:
                    System.out.print("King of ");
                    break;
                default:
                    System.out.print(((int)data/10)+" of ");
                    break;
            }
            switch((int)data%10){
                case 1:
                    System.out.println("Spades");
                    break;
                case 2:
                    System.out.println("Hearts");
                    break;
                case 3:
                    System.out.println("Diamonds");
                    break;
                case 4:
                    System.out.println("Clubs");
                    break;
                default:
                    break;
            }//print data//temp.next.data
            System.out.print("-->"); 
            temp = temp.next;                       //point to next node
        }
        System.out.println("");
    }
    public void printReverse(Node head)
    {
        Node temp = head;
        System.out.print("Data: ");
        if(temp.next==null)
        {
            return;                       //point to next node
        }
        printReverse(temp.next);
        System.out.println(temp.next.data+"<--");
    }
}
