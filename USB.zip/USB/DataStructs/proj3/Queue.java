/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author juventino
 */
public class Queue {

    private SingleLinkedList Q;       //reference to actual Q
    private int front;
    private int rear;
    private int size;  
    
    
    
    public Queue(){
        Q = new SingleLinkedList();   //create the actual Q
        this.front=0;                   //0 = the head
        this.rear = 0;
        this.size=0;
    }
    
    public void offer(Object obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //this method adds an element,first check for space
        size++;
        rear=(rear+1);
        Q.addLast(obj);
    }
    
    public Object poll() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(isEmpty()){
            System.out.println("The queue is empty");
            return null;
        }
        Object result = Q.removeFirst();
        size--;
        rear--;
        return result;
    }

    public boolean isEmpty() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return (size==0);
    }

    

    public Object peek() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return Q.getNode(1).data;
    }

    public int size() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return size;
    }

    public void display() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Q.printList();
        System.out.println();
    }
    
}
