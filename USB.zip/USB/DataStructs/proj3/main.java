/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author juventino
 */
public class main {
   
    public static void main(String[] args)  {   
        //C>D>H>S
        Queue []playerDecks = new Queue[4];     //these decks represent players 1-4 each index is a player
        playerDecks[0]=new Queue();     //all player decks are initialized ot there will be a null pointer exception
        playerDecks[1]=new Queue();
        playerDecks[2]=new Queue();
        playerDecks[3]=new Queue();
        dealCards(playerDecks);                 //this function deals the cards randomly to each player
        int randomlySelectedPlayer = (int)Math.floor(Math.random()*4);  //a player is selected at random 0-3, represents 4 in total
        System.out.println("The game has started, the cards have been dealt and players will start in the following order player: "+(randomlySelectedPlayer%4+1)+", "+((randomlySelectedPlayer+1)%4+1)+", "+((randomlySelectedPlayer+2)%4+1)+", "+((randomlySelectedPlayer+3)%4+1)+".\n ");
        for(int i = 0;i<15&&playerDecks[0].size()!=52&&playerDecks[1].size()!=52&&playerDecks[2].size()!=52&&playerDecks[3].size()!=52;i++){
            System.out.println("-----------------------------------------------------------------------------------------");
            randomlySelectedPlayer = round(playerDecks,randomlySelectedPlayer,i+1);
            System.out.println("-----------------------------------------------------------------------------------------");
        }      //game ends after 15 rounds or if a player takes all the cards
        declareWinner(playerDecks);
    }
    public static void dealCards(Queue[] decks){
        int[] mainDeck = {11,12,13,14,21,22,23,24,31,32,33,34,
            41,42,43,44,51,52,53,54,61,62,63,64,71,72,73,74,
            81,82,83,84,91,92,93,94,101,102,103,104,            //1=spades,2=hearts,3=diamonds,4=clubs  if in the ones digit
            111,112,113,114,121,122,123,124,131,132,133,134};   //anything in the tens digit or hundreds,10 represents ace, 20=2,30=3....110=Jack,120=queen,130=king
        
        for(int i=0;i<mainDeck.length;i++){
            int randomCard = (int)Math.floor(Math.random()*(mainDeck.length-i));    //i decreases the range of the random number
            decks[i%4].offer(mainDeck[randomCard]);     //each player gets a random card
            for(int j=randomCard;j<mainDeck.length-1;j++){
                int temp = mainDeck[j];
                mainDeck[j]=mainDeck[j+1];
                mainDeck[j+1]=temp;
            }   //this will shift all the cards to the right of the random card by 1 to the left while the random card is shifted all the way to the right
        }   //the loop deals the cards randomly to each player
    }
    public static int round(Queue []decks,int selectedPlayer,int roundNumber){
        System.out.println("Round "+roundNumber+":\n");
        System.out.println("Player "+((selectedPlayer)%4+1));
        decks[(selectedPlayer)%4].display();
        System.out.println("Player "+((selectedPlayer+1)%4+1));
        decks[(selectedPlayer+1)%4].display();
        System.out.println("Player "+((selectedPlayer+2)%4+1));
        decks[(selectedPlayer+2)%4].display();
        System.out.println("Player "+((selectedPlayer+3)%4+1));
        decks[(selectedPlayer+3)%4].display();
        int[]card= new int[5];  //this will store the order of the cards played based off player order
        card[0] = decks[(selectedPlayer)%4].size()!=0?(int)decks[selectedPlayer%4].poll():0;
        card[1] = decks[(selectedPlayer+1)%4].size()!=0?(int)decks[(selectedPlayer+1)%4].poll():0;
        card[2] = decks[(selectedPlayer+2)%4].size()!=0?(int)decks[(selectedPlayer+2)%4].poll():0;
        card[3] = decks[(selectedPlayer+3)%4].size()!=0?(int)decks[(selectedPlayer+3)%4].poll():0;
        card[4] = 0;    //this will store the highest card
        for(int i =0;i<4;i++){
            System.out.print("Player "+((selectedPlayer+i)%4+1)+" played: ");
            switch((int)card[i]/10){
                case 0:
                    System.out.println("Nothing");
                    break;
                case 1:
                    System.out.print("Ace of ");
                    break;
                case 11:
                    System.out.print("Jack of ");
                    break;
                case 12:
                    System.out.print("Queen of ");
                    break;
                case 13:
                    System.out.print("King of ");
                    break;
                default:
                    System.out.print(((int)card[i]/10)+" of ");
                    break;
            }
            switch(card[i]%10){
                case 1:
                    System.out.println("Spades");
                    break;
                case 2:
                    System.out.println("Hearts");
                    break;
                case 3:
                    System.out.println("Diamonds");
                    break;
                case 4:
                    System.out.println("Clubs");
                    break;
                default:
                    break;
            }
            if(card[i]>card[4]){
                card[4] = card[i];
            }
        }
        if(card[4]==card[0]){
            System.out.println("\nPlayer "+((selectedPlayer)%4+1)+" won round "+roundNumber);
            decks[(selectedPlayer)%4].offer(card[0]);
            decks[(selectedPlayer)%4].offer(card[1]);
            decks[(selectedPlayer)%4].offer(card[2]);
            decks[(selectedPlayer)%4].offer(card[3]);
            return(selectedPlayer)%4;
        }
        else if(card[4]==card[1]){
            System.out.println("\nPlayer "+((selectedPlayer+1)%4+1)+" won round "+roundNumber);
            decks[(selectedPlayer+1)%4].offer(card[0]);
            decks[(selectedPlayer+1)%4].offer(card[1]);
            decks[(selectedPlayer+1)%4].offer(card[2]);
            decks[(selectedPlayer+1)%4].offer(card[3]);
            return(selectedPlayer+1)%4;
        }
        else if(card[4]==card[2]){
            System.out.println("\nPlayer "+((selectedPlayer+2)%4+1)+" won round "+roundNumber);
            decks[(selectedPlayer+2)%4].offer(card[0]);
            decks[(selectedPlayer+2)%4].offer(card[1]);
            decks[(selectedPlayer+2)%4].offer(card[2]);
            decks[(selectedPlayer+2)%4].offer(card[3]);
            return(selectedPlayer+2)%4;
        }
        else{
            System.out.println("\nPlayer "+((selectedPlayer+3)%4+1)+" won round "+roundNumber);
            decks[(selectedPlayer+3)%4].offer(card[0]);
            decks[(selectedPlayer+3)%4].offer(card[1]);
            decks[(selectedPlayer+3)%4].offer(card[2]);
            decks[(selectedPlayer+3)%4].offer(card[3]);
            return(selectedPlayer+3)%4;
        }
    }
    public static void declareWinner(Queue[] decks){
        int largestDeck=0;
        for(int i=0;i<4;i++){
            if(decks[i].size()>largestDeck){
                largestDeck=decks[i].size();
            }
        }
        for(int i=0;i<decks.length-1;i++){
            for(int j=i+1;j<decks.length;j++){
                if(decks[i].size()==decks[j].size()&&largestDeck==decks[i].size()){
                    System.out.println("The game is a Tie!");
                    return;
                }
            }
        }
        for(int i=0;i<4;i++){
            if(decks[i].size()==largestDeck){
                System.out.println("The winner is player "+(i+1));
                return;
            }
        }
    }
}