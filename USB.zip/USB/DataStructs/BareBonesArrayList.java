/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public interface BareBonesArrayList <E> {
    public void add(E a);
    public void add(E a,int index);
    public E remove(int index);
    public E get(int index);
    public void set(E a,int index);
    public int getSize();
    public int indexof(E a);
}
