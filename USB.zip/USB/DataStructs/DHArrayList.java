/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public class DHArrayList <E> implements BareBonesArrayList<E>{
    private int size;		//elements in array
	private int capacity;	//size of array
	private E[] myArray;	//reference to store actual data
	private static final int INITIAL_CAPACITY = 10;	//default size
	
	//constructor
	public DHArrayList(){
		this.capacity = INITIAL_CAPACITY;
		this.size = 0;
		myArray = (E[])new Object[this.capacity];	//create array w/ initial size
	}
	
	//overloaded constructer to create arraylist of var size
	
	public DHArrayList(int capacity){
		this.capacity = capacity;
		this.size = 0;
		myArray = (E[])new Object[this.capacity];	
	}
	
    @Override
    public void add(E a){
        //this adds element to the end
		if(size<capacity)	//there is space to add data
		{
			myArray[size] = a;	//size = index of first free location
			size++;
		}
		else{
			System.out.println("There isn't enough space in the list, calling reallocate");
			this.reallocate();	//change array capacity
			this.add(a);		//new space availabe and can insert
		}
	}
	private void reallocate(){
		this.capacity*=2;	//updates capacity to double
		E[] temp=(E[])new Object[this.capacity];
		//copy old array to new
		for(int i =0;i<myArray.length;i++){
			temp[i]=myArray[i];
		}
		//update is needed after copying is done
		this.myArray=temp;
	}

    @Override
    public void add(E a, int index) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		//this adds an element to a specific location
		if(index<0||index>size){
		System.out.println("Invalid index");
		return;
		}
		//we can reuse the other add(), if the index is at the end
		else if (index==size){
			this.add(a);
		}
		else{
			if(this.capacity == this.size)
				this.reallocate();
				
			for(int i =size;i>index;i--){
				this.myArray[i] = this.myArray[i-1];
			
			}
			//insert data
			this.myArray[index]=a;
			size++;
		}
	}
 
    @Override
    public E remove(int index) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if (index<=0||index>=size)
        {    
            System.out.println("Invalid index");
            return null;
        }
        E temp = myArray[index];
        //loop to shift elements
        for(int i = index; i<size-1;i++){
            this.myArray[i] = this.myArray[i+1];
        }
        size--;
        return null;
    }

    @Override
    public E get(int index) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(index<0||index>=size-1)//checks for valid index
            return null;
        return this.myArray[index];
    }

    @Override
    public void set(E a, int index) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(index<0||index>=size-1)//checks for valid index
            return;
        this.myArray[index]=a;
        
    }
	@Override
    public int getSize() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		return size;
    }
    @Override
    public int indexof(E a) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	for(int i = 0; i<size;i++){
            if(this.myArray[i].equals(a))
                return i;
        }
        return -1;
    }
    public void display(){
	System.out.println("The contents of the list: ");
	for(int i=0;i<size;i++){
            System.out.println(myArray[i]+",");
	}
    }
}
