// the data
class Hash
{
	int id;			//key
	String name;		//value

	
	// Constructor
	public HashNode(int id=null, String name=null)
	{
		this.id = id;
		this.name = name;
	}
}

// Class to represent entire hash table
class HashTable
{
	// bucketArray is used to store array of chains
	private Hash[] hashArray;

	// Current capacity of array
	private int capacity;

	// Current number of elements
	private int size;

	// Constructor (Initializes capacity, size and empty chains.
	public HashTable()
	{

		capapcity = 60;
		hashArray = new Hash[60];
		size = 0;
	}

	public int capacity() { return capacity; }
	public int size() { return size; }
	public boolean isEmpty() { return size == 0; }
	
	//displays all elements
	public void display() { 
		for(int i=0;i<capacity;i++)
		{
			if(hashArray[i].id==null)
				System.out.print("key:"+i+" ");
			else
				System.out.print(hashArray[i].key);
			if(hashArray[i].value==null)
				System.out.print("value:"+i+" ");
			else
				System.out.print(hashArray[i].key);
		} 
	}
	

	// This implements hash function to find index for a key
	private int getArrayIndex(int key)
	{
		//converts key to string and adds a 0 to the front if key.length()==1
		String keyString = ((""+key).length()==2)?""+key:"0"+key);
		
		//hash function
		int hashCode = keyString.charAt(0)*31 + keyString.charAt(1);
		
		return hashCode % capacity;
	}
	
	
	// Method to remove a given key
	public String remove(int key)
	{
		// Apply hash function to find index for given key
		int arrayIndex = getArrayIndex(key);

		// Get starting element
		String value = null;


		for(int i=0;hashArray[(arrayIndex+i)%capacity].key!=null;i++) 
		{
			if (hashArray[(arrayIndex+i)%capacity].id==key){
				arrayIndex = (arrayIndex+i)%capacity;
				value = hashArray[(arrayIndex+i)%capacity];		
				break;
			}
		}

		// If key was not there
		if (value==null)
			return null;

		// Reduce size
		size--;

		// Removes data
		hashArray[arrayIndex].name = null;
		hashArray[arrayIndex].id = -1;
		
		return value;
	}

	// Returns value for a key
	public String getValue(int key)
	{
		// Find head of chain for given key
		int arrayIndex = getArrayIndex(key);

		// Probes and ends just before repeating 
		for(int i=0;hashArray[(arrayIndex+i)%capacity].key!=null;i++) 
		{
			if (hashArray[(arrayIndex+i)%capacity].id==key)
				return hashArray[(arrayIndex+i)%capacity].value;
		}

		// If key not found
		return null;
	}

	// Adds a key value pair to hash
	public void add(int key, String value)
	{
		// Find index for given key
		int arrayIndex = getArrayIndex(key);
		

		// Check if key is already present and replaces it with the new value if already present
		for(int i=0;hashArray[(arrayIndex+i)%capacity].key!=null;i++)
		{
			if (hashArray[(arrayIndex+i)%capacity].id==key)
			{
				//replaces old value with new assuming it's different to begin with
				hashArray[(arrayIndex+i)%capacity].name = value;
				return;
			}
		}

		// Insert key in chain
		size++;
		for(int i=0;i<capacity;i++)
			if (hashArray[(arrayindex+i)%capacity].id==-1||hashArray[(arrayindex+i)%capacity].id==null)
				hashArray[(arrayIndex+i)%capacity] = new Hash(key, value);

		// If load factor goes beyond threshold, then
		// double hash table size
		if ((1.0*size)/numBuckets >= 0.7)
		{
			Hash[] temp = hashArray;
			hashArray = new Hash[capacity*2];
			capacity *= 2;
			size = 0;
			//copies 
			for (Hash hash : temp)
				add(hash.id, hash.name);

		}
	}

}
	
	public class HashTableImplementation {
	// Driver method to test Map class
			public static void main(String[] args)
			{
				HashTable ht = new HashTable();
				
			}

}
