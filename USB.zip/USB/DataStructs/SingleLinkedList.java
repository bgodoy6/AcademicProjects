/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author bgodoy6
 */
public class SingleLinkedList {
    
    private Node head;  //head of link list
    private int size;   //number of nodes in the list
    
    public SingleLinkedList()
    {
        this.head = new Node(-1);   //creates head and store -1
        size = 0;                   //list is empty initially
    }
    
    //add methods
    //method that adds item to the beggining
    public void addFirst(Object item)
    {
        Node first = new Node(item);    //create node
        first.next = head.next;         //copy next of head to next of first
        head.next = first;              //update head next value
        size++;                         //increase size
    }
    
    //Method to add item after a given node reference
    public void addAfter(Node target,Object item)
    {
        Node insert = new Node(item);
        insert.next = target.next;
        target.next = insert;
        size++;
    }
    public void addLast(Object item)
    {
        //we'll use the get node method to retrieve the reference
        Node target = getNode(size);    //get last node
        addAfter(target,item);          //then call add after method
    }
    //helper method returns node reference at given index
    public Node getNode(int index)
    {
        if(index<0||index>size)
        {
            return null;
        }
        Node iter = head;
        for(int i = 0; i<index;i++)
        {
            iter=iter.next;
        }
        return iter;
    }
    public Object removeFirst()
    {
        if(size==0)
        {
            return null;
        }
        Node removed = head.next;
        head.next = head.next.next;
        size--;
        return removed.data;
    }
    //helper method to display contents of list
    
    public void printList()
    {
        Node temp = head;
        System.out.print("Data: ");
        while(temp.next!=null)
        {
            System.out.print(temp.next.data+"-->"); //print data
            temp = temp.next;                       //point to next node
        }
        System.out.println("");
    }
    public void printReverse(Node head)
    {
        Node temp = head;
        System.out.print("Data: ");
        if(temp.next==null)
        {
            return;                       //point to next node
        }
        printReverse(temp.next);
        System.out.println(temp.next.data+"<--");
    }
}
