// e51.js - The JavaScript solution for Exercise 5.1
//
// The event handler function to produce an alert message 
//  about the chosen color

function colorChoice (color) {

    switch (color) {
        case "red": 
	    alert("Your favorite color is red");
            break;
        case "blue": 
	    alert("Your favorite color is blue");
            break; 
        case "green":
	    alert("Your favorite color is green");
            break;    
        case "yellow":
	    alert("Your favorite color is yellow");
            break; 
        case "orange":
 	    alert("Your favorite color is orange");
            break; 
        default:
            alert("Error in JavaScript function colorChoice");
            break;
    }
}