<!DOCTYPE html>
<!--	e9_1.php
	A solution to Exercise Project1.php
	-->
<html lang = "en">
<head> 
  <title> Project1.php </title>
  <meta charset = "utf-8" />
  <?php

  function unique($strings) {
     $uniqueStrings = array();
     foreach ($strings as $string) {
        foreach ($uniqueStrings as $uString) {
           if ($string == $uString) break;
        }
        if ($string != $uString)
           $uniqueStrings[] = $string;
     }
     return $uniqueStrings;
  }
  ?>
</head>
<body>
<?php
$str = array(42, 24, 2, 4, 42, 24, 2, 4, 24, 42, 42, 24);
$uStr = unique($str);
foreach ($uStr as $st)
   print ("$st <br />");
?>
</body>
</html>
