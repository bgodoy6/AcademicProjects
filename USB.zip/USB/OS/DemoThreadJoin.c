/*	Brian Godoy
CSC 341

Ran on onlinegdb compiler.
I managed to make the code work but it required some additional lines of code and changes.

pthread_t thread id; 	//is moved to the top, no longer part of main and becomes the main thread
pthread_t t; 		//becomes the non main thread
PrintHello(void* data)	//the parameter becomes pointless because the id of the main thread is directly accessible

*/
#include <stdio.h>       /* standard I/O routines                 */
#include <pthread.h>     /* pthread functions and data structures */


pthread_t  thread_id;     	       /* thread's ID (just an integer) */



void* PrintHello(void* data)
{

	pthread_t tid = thread_id;    /* data received by thread */ //id of main thread


	pthread_join(tid, NULL);            /* wait for thread tid     */	//waits for main thread

	printf("Hello from new thread %u - got %u\n", pthread_self(), tid);

	pthread_exit(NULL);	                /* terminate the thread    */ // this thread ends

}



/* like any C program, program's execution begins in main */

int main(int argc, char* argv[])
{


	int        rc;         	       /* return value                  */

	int        tid;

	pthread_t t;

	tid = pthread_self();			//gets id of calling thread //id of main thread

	thread_id = pthread_self();


	rc = pthread_create(&t, NULL, PrintHello, NULL);  //creates thread w/ default attributes
													  //return id of new thread



	if (rc)                             /* could not create thread */

	{

		printf("\n ERROR: return code from pthread_create is %d \n", rc);

		exit(1);

	}

	sleep(1);

	printf("\n Created new thread (%u) ... \n", t);

	pthread_exit(NULL);		//terminates main thread

}

//void* PrintHello(void* data)
//{
//pthread_t tid = (pthread_t)data;    /* data received by thread */ //id of main thread

//pthread_join(tid, NULL);            /* wait for thread tid     */	//waits for main thread
//printf("Hello from new thread %u - got %u\n", pthread_self(), data);
//pthread_exit(NULL);	                /* terminate the thread    */ // this thread ends
//}

/* like any C program, program's execution begins in main */
//int main(int argc, char* argv[])
//{
//int        rc;         	       /* return value                  */
//pthread_t  thread_id;     	       /* thread's ID (just an integer) */
//int        tid;

//tid = pthread_self();			//gets id of calling thread //id of main thread

//rc = pthread_create(&thread_id, NULL, PrintHello, (void*)tid);  //creates thread w/ default attributes
//return id of new thread


//if(rc)                             /* could not create thread */
//{
//printf("\n ERROR: return code from pthread_create is %d \n", rc);
//exit(1);
//}
//sleep(1);
//printf("\n Created new thread (%u) ... \n", thread_id);	//
//  pthread_exit(NULL);		//terminates main thread
//}
//
