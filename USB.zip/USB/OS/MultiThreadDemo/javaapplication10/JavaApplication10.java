/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication10;
/**
 *
 * @author Brian
 */
public class JavaApplication10 {
    public static int sumAll=0;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n=4;
        for(int i=0;i<n;i++){
            Thread myThreads =new Thread(new MultiThreadingDemo());
            myThreads.start();
        }
        try{
            //Thread.sleep(1);
            System.out.println("The total sum is "+MultiThreadingDemo.total);
        }catch(Exception e){System.out.println("Some error happened.");}
    }
    
}
