/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication10;

/**
 *
 * @author Brian
 */
public class MultiThreadingDemo implements Runnable{
    int A[]={1,2,3,4,5,6,7,8};
    int sum =0;
    static int total;
    @Override
    public void run(){
        try{
            System.out.println("Thread " + Thread.currentThread().getId()+" is running");
            int myThreadId = (int)(Thread.currentThread().getId())%10;
            int random =(int)(Math.random()*15000);
            //Thread.sleep(random);
            sum=A[2*myThreadId]+A[2*myThreadId+1];
            System.out.println("Sum: "+sum+" from "+ Thread.currentThread().getId());
            System.out.println("Thread " + Thread.currentThread().getId()+" is done");
            total+=sum;
        }catch(Exception e){
            System.out.println("Some error happened:(");
        }
    }
}
