/*
 * A UDP Client
 * Implementing the Stop-n-Wait-ARQ algorithm
 * Uses: 
 * 		class Packet  payload, sequence numbers, etc
 * 		class NoisyDatagramSocket - extends DatagramSocket - add drops & delays
 * 
 * Last modified:  Malcolm 20171005
 *
 */
package javaapplication1;
import java.io.*;
import java.net.*;
import java.nio.*;

class StopAndWaitClient{
    private static final int BUFFER_SIZE = 1024;
    private static final int size = 1;
    private static final int PORT = 6789;
    private static final int SEQUENCE_NUMBER = 0;
    private static final int TimeOutValue = 3000;
    private static final String SERVER = "localhost";
    private static int N = 10;                        // number of times to loop 
	
    public static void main(String args[]) throws Exception{
		// Create a socket  //DatagramSocket socket = new DatagramSocket();
		NoisyDatagramSocket socket = new NoisyDatagramSocket();
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		String sentence;
                int sequenceNumber = 0;
		
		while( (sentence = inFromUser.readLine()) != null) {
		  N = sentence.length();
		  for (int i=0; i<N; i+=size) {
			String sData = sentence.substring(i, i+size);
            
			// Create a byte array for sending and receiving data
			byte[] rData = new byte[ BUFFER_SIZE ];
                        Packet sPacket = new Packet(sequenceNumber, sData);                  // payload: data & i (sequence number)

                        // serialize the payload
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();   // setup stream - will be bytes
                        ObjectOutputStream oos = new ObjectOutputStream(baos);      // setup to serialize Packet
                        oos.writeObject(sPacket);                                 // write Packet to Object stream
                        byte[] sBuf = baos.toByteArray();                           // put packet (stream) into byte buffer

			// Get the IP address of the server
			InetAddress serverIP = InetAddress.getByName( SERVER );

			System.out.println( "Sending Packet (seq_n: " + sequenceNumber + ") Payload: '" + sData + "'"); 
			DatagramPacket sDatagram = new DatagramPacket(sBuf, sBuf.length, serverIP, PORT);

			socket.send( sDatagram );
                        
			// Receive the server's packet
			DatagramPacket rDatagram = new DatagramPacket(rData, rData.length, serverIP, PORT);
			socket.receive( rDatagram );
			byte[] rPayload = rDatagram.getData();                     // fill buffer for payload

			// serialize the payload
			ByteArrayInputStream bais = new ByteArrayInputStream(rPayload);// stream will be array of bytes
			ObjectInputStream ois = new ObjectInputStream(bais);        // setup stream 
			Packet rPacket = new Packet(0, new String(new byte[BUFFER_SIZE]));
                        
			try {
				rPacket = (Packet) ois.readObject();                   // read and cast to Packet
			} catch (ClassNotFoundException e) {e.printStackTrace(); }  // if not packet (recover?)
                        catch (IOException e) {e.printStackTrace(); }
                        
                        int seq_no = rPacket.getSeq();
			String rBuf = new String(rPacket.getPayload());         // pull out data
			System.out.println(" Received Packet (seq_n: "  + seq_no + ") Payload: '" + rBuf + "'");
			// If we receive an ack, stop the while loop
		  }
	    }	
    }
}
