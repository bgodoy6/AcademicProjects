// The packet class to build packet for datagram.

import java.net.InetAddress;
import java.net.DatagramPacket;
import java.io.Serializable;
import java.io.IOException;
import java.lang.Exception;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.Timer;
import java.util.TimerTask;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;        
/*
 *  Packet class for java network progaming
 *
 *      payload (byte[]), 
 *      length (int)            - length of payload
 *      sequence number (int)   - for packet enumeration
 *      state (enumeration)     - Ready, Sent, Ack, etc
 *      Last (bool)             - are we last packet 
 *      reTransmits (int)       - how many time have we been resend
 *
 */


public class Packet implements Serializable, Comparable<Packet>  {
   private int seq;                                   // the seq number
   private byte[] payload;                            // the datagram's Payload
   private int len;                                   // the length of data (the payload)
   public volatile State state;                       // the state of packet  Ready,Sent, etc
   public boolean Last;                               // the state of packet  Ready,Sent, etc
   public volatile int reTransmits = 0;               // the times of retransmits
   public static InetAddress address;                 // ipaddess for resend
   public static int port;                            // port number of resent
   private transient Timer timer;                     // timer for resend (can't be serialized)
   private transient TimerTask timertask;             // thread for resend (can't be serialized)
                                                      // Set for all unacknoledged packets
   //private static volatile Set <Integer> unAckSet = new HashSet<Integer>();
   public static SortedSet<Integer> unAckSet = new TreeSet<Integer>();

   private Packet() { }                               // no default constructor

   public Packet(int seq, byte [] Payload) {
       this.seq = seq;
       this.payload = Payload;
       this.state = State.Ready;
       this.len = this.payload.length;
       this.Last=false;
       this.timer = new Timer();
    }

    public Packet(int seq, String strPayload) {
        this(seq, strPayload.getBytes());
    }

    public Packet(Packet p) {
        this.len = p.len;
        this.seq = p.seq;
        this.payload = p.payload;
        this.state = p.state;
        this.reTransmits = p.reTransmits;
        this.Last=false;
        this.timer = new Timer();
    }
    
    public Packet(int seq, byte[] payload, State state) {
        this(seq, payload);
        this.state = state;
    }

    public Packet(int seq, String strPayload, State state) {
        this(seq, strPayload);
        this.state = state;
    }
    

   public void setSeq(int seq) { this.seq = seq; }
   public void setReady() { this.state = State.Ready; }
   public void setAck(boolean ack) { this.state = State.Acked; }
   public void setAck() { this.state = State.Acked; }
   public void setAcked() { setAck();}
   public void setSent() { this.state = State.Sent; }
   public void setAcknowledgment() { this.state = State.Acknowledgment; }
   public void setReceived() { this.state = State.Received; }
   public void setLost() { this.state = State.Lost; }
   public void setCorrupt() { this.state = State.Corrupt; }
   public void setResent() { this.state = State.Resent; }
   public void setLast() { this.Last = true; }
   public void setReset() { this.state = State.Reset; }
   public boolean isReset() { return this.state == State.Reset; }
   public void setState(State s) { this.state = s; }
   public State getState() { return this.state; }
   public void setPayLoad(byte[] payload) { this.payload = payload; }
   public int getRetransmits(){ return reTransmits;}
   public void incRetransmits() {reTransmits++;}
   public byte[] getPayload() { return payload; }
   public String getPayloadStr() { return (new String( payload )); }
   public String getData() { return (new String( payload )); }
   public int getSeq() { return seq; }
   public boolean isAcked() { return (state == State.Acked); }
   public boolean isLast() { return this.Last; }
   public static void setPort(int p) { port =  p;}
   public static void setAddress(InetAddress a) { address = a;}
   public  void setUnAckSet() { unAckSet.add(getSeq()); }
   public static void setUnAckSet(int seq_num) {  unAckSet.add(seq_num); }
   public static void printUnAckSet() {
      System.out.print("\t - Unacknowledged packets are: ");
      for(Object object :unAckSet) { 
         int e = (Integer) object;
         System.out.print(e+" ");
      }
      System.out.print(" \n");
   }
   public static boolean inUnAckSet(int num ) {  return unAckSet.contains(num); }
   public static boolean isEmptyUnAckSet() {  return unAckSet.isEmpty(); }
   public void unsetUnAck() { unAckSet.remove(getSeq()); }
   public static void unsetUnAck(int num) { unAckSet.remove(num); }
   public static void UnAckCancelRemove(ArrayList<Packet> sent, int num) {
      int index = (num==1)?0:num-1;
      //System.out.println("in UnAckCancelRemove - num:"+num+" index:"+ index);
      sent.get(index).setAcked();
      sent.get(index).cancelResend();
      sent.get(index).cancelResend();
      unAckSet.remove(num);
   }
   public static void UnAckCancelRemoveAll(ArrayList<Packet> sent, int num) {
      int index = (num==1)?0:num-1;
      //System.out.println("in UnAckCancelRemoveAll - num:"+num+" index:"+ index);
      sent.get(index).setAcked();
      sent.get(index).cancelResend();
      unAckSet.remove(num);
      for(Object object :unAckSet) {
         int element = (Integer) object;
         //if (element < num){
         element = (element==1)?0:element-1;
            unAckSet.remove(num);
            if(sent.contains(element)){
               sent.get(element).cancelResend();
               sent.get(element).setAcked();
            }
         //}
      }
   }

   public static DatagramPacket makeDatagram(Packet packet, InetAddress ipaddress, int portno){
      DatagramPacket datagram = new DatagramPacket(new byte[1], 1);
      address = ipaddress;
      port = portno;
      //System.out.println(" packet:"+packet);
      try {
         byte[] buf = Serializer.toBytes(packet);       // serialize the payload
         datagram = new DatagramPacket(buf, buf.length, address, port);
      } catch(IOException e) { e.printStackTrace(); }
         return datagram;
   }

   public static Packet makePacket(DatagramPacket datagram) {
      // this.address = datagram.getAddress();
      // this.port = datagram.port();;
      Packet packet = new Packet(-1,"DUMMY");
      try {
         packet = (Packet) Serializer.toObject(datagram.getData());      // read and cast to Packet
      } 
      catch (ClassNotFoundException e) { e.printStackTrace(); } 
      catch (IOException e) { e.printStackTrace(); }

      return packet;  
   }


   public void scheduleResend( NoisyDatagramSocket socket, int time){
      Packet p = this;
      timertask = new TimerTask(){
         @Override
         public void run() {
            while (true) {
               if( ! inUnAckSet( p.getSeq() ) ) { 
                  //System.out.println(" \t\t -  THREAD: in resend - packet has been Acknowledged  ");
                     break;
               }
               incRetransmits();                   
               try { 
                  socket.send( makeDatagram(p, address, port) );
               }catch (IOException e) {e.printStackTrace();}
                  String pl = new String(getPayload());
                  int s = getSeq();
                  int t = getRetransmits();
                  System.out.println(" \t\t -  THREAD:Resending packet: " + s +" payload:"+pl+" times: "+t);
                  try {
                     Thread.sleep(time);
                  } catch(InterruptedException e) { Thread.currentThread().interrupt();}
            }   
         } 
      }; 
      timer.schedule( timertask, time);
   }

   public void cancelResend(){
      String pl = new String(getPayload());
      System.out.println(" \t\t -   THREAD:Canceling resend for packet # "+getSeq()+" payload: "+ pl);
      timertask.cancel();
      timer.cancel();
      //timer.purge();
    }


@Override
   public int compareTo(Packet p) {
      if (this.seq < p.getSeq()) return -1;
      else if (this.seq > p.getSeq()) return 1;   
      else return 0;
    }

@Override
  public String toString() {
   return ("Seq: "+seq+" 's state is "+state.toString()
               +" , payload is '"+getData()
               +"' , it is "+reTransmits+" times to retransmits"
               +"  to IPaddress:"+address+" port:"+port);
               
   }


}  // Packet class


// the state class used to represent current state of a packet

enum State {
    Ready(2),Sent(4), Acknowledgment(6), Acked(8), Received(10), Lost(12), Corrupt(14), Resent(16), Reset(18) ;
    private int value; // the value of enum state

    private State(int value) { this.value = value; }
    private State() { this.value = 4; }

    public String toString() {
        switch (this.value){
            case 2  : return "Ready";
            case 4  : return "Sent";
            case 6  : return "Acknowledgment";
            case 8 : return "Acked";
            case 10 : return "Received";
            case 12 : return "Lost";
            case 14 : return "Corrupt";
            case 16 : return "Resent";
            case 18 : return "Reset";
        }
        return "Unknow State";
    }
} // State class

class Serializer {
   public static byte[] toBytes(Object obj) throws IOException {
      ByteArrayOutputStream b = new ByteArrayOutputStream();
      ObjectOutputStream o = new ObjectOutputStream(b);
      o.writeObject(obj);
      return b.toByteArray();
   }

   public static Object toObject(byte[] bytes) throws IOException, ClassNotFoundException {
      ByteArrayInputStream b = new ByteArrayInputStream(bytes);
      ObjectInputStream o = new ObjectInputStream(b);
      return o.readObject();
   }
} // Serializer class
