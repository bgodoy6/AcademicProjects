/**
 * A UDP Server
 * Implementing the Stop-n-Wait-ARQ algorithm
 * Uses: 
 * 		class Packet  payload, sequence numbers, etc
 * 		class NoisyDatagramSocket - extends DatagramSocket - add drops & delays
 * 
 * Last modified:  Malcolm 20171005
 *
 */
package javaapplication3;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.util.*;

class StopAndWaitServer{
    private static final int BUFFER_SIZE = 1024;
    private static final int PORT = 6789;
    private static final int SEQUENCE_NUMBER = 0;

	public static void main(String[] args) throws IOException {
        Integer expected_seq_no = SEQUENCE_NUMBER;
	    
	// Create a server socket  // DatagramSocket serverSocket = new DatagramSocket( PORT );
	NoisyDatagramSocket socket = new NoisyDatagramSocket( PORT );
		
	Packet rPacket = new Packet(0, new String(new byte[BUFFER_SIZE]));
        
    	// Set up byte arrays for sending/receiving data
        byte[] rBuf = new byte[ BUFFER_SIZE ];
           
        // Infinite loop to check for connections 
        while(true){
		// Get the received packet
	    DatagramPacket rDatagram = new DatagramPacket( rBuf, rBuf.length );
	    socket.receive( rDatagram );
            
            byte[] rData = rDatagram.getData();                      	// get payload from UPD datagram
            ByteArrayInputStream bais = new ByteArrayInputStream(rData);// datagram payload is serialized
            ObjectInputStream ois = new ObjectInputStream(bais);        // setup stream
            try {
                rPacket = (Packet) ois.readObject();                    // cast read object to Packet
            } catch (ClassNotFoundException e) {e.printStackTrace(); }
            // Get packet's IP and port
            InetAddress IPAddress = rDatagram.getAddress();
            int port = rDatagram.getPort();

            // Get the message from the packet
            String payload = new String(rPacket.getPayload());         // get sent data
            int seq_no = rPacket.getSeq();                             // get sequence number /
            System.out.println("FROM CLIENT: '" + payload + "' sequence number: " + seq_no );
            Packet sPacket;
            
            // Make Packet for ACK - send same data back
            sPacket = new Packet(seq_no, payload, State.Acked);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();   // setup stream - will be bytes
            ObjectOutputStream oos = new ObjectOutputStream(baos);     	// setup to serialize Packet
            oos.writeObject(sPacket);                               	// write Packet to Object stream
            byte[] sData = baos.toByteArray();                         	// data for UPD datagram (to send)

            // Make Datagram  - Send data back to the client
            DatagramPacket sDatagram = new DatagramPacket( sData, sData.length, IPAddress, port );
            socket.send( sDatagram );

       	}
    }
}
