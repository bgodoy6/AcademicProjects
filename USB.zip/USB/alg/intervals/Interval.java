/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;

import java.util.Random;

/**
 *
 * @author Brian
 */
public class Interval {
        public int start,end;
    
        public Interval(){  //generates a random inerval
            start=0;
            end=0;
        }
        public void initialize(int upper, int lower){
            Random rng = new Random();
            do{
                end=rng.nextInt((upper-lower+1))+lower;
                start=rng.nextInt((upper-lower+1))+lower;
            }while(start==end);
            if(start>end){
                int temp=start;
                start=end;
                end=temp;
            }
            
        }
        public void printInterval(){
                System.out.print("["+start+","+end+"]");
        }
    }
