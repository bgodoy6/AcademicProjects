/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;
import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
/**
 *
 * @author Brian
 */
public class JavaApplication6 {
    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n,s,t;
        System.out.println("Please enter 3 numbers greater than zero");
        System.out.println("The number of intervals:");
        n=scan.nextInt();
        System.out.println("Then an upper bound.");
        t=scan.nextInt();
        System.out.println("Then a lower bound.");
        s=scan.nextInt();
        Interval[] intervals  = new Interval[n];
        for(int i=0;i<n;i++){
            intervals[i]=new Interval();
            intervals[i].initialize(t, s);
        }
        System.out.println("Interval Scheduling:");
        schedulePrinting(intervals);
        System.out.println("Interval Partitioning:");
        partitionPrinting(intervals);
    }
    public static void schedulePrinting(Interval[] ints){
        for(int i=0;i<ints.length-1;i++){   //sort 
            for(int j=i+1;j<ints.length;j++){
                if(ints[i].end>ints[j].end){
                    Interval temp=ints[j];
                    ints[j]=ints[i];
                    ints[i]=temp;
                }
            }
        }
        int size=1;
        ints[0].printInterval();
        for(int i=1,prevInterval=0;i<ints.length;i++){
            if(ints[prevInterval].end<=ints[i].start){
                ints[i].printInterval();
                prevInterval=i;
                size++;
            }
        }
        System.out.println("\nMax size:"+size);
    }
    public static void partitionPrinting(Interval[] ints){
        for(int i=0;i<ints.length-1;i++){   //sort 
            for(int j=i+1;j<ints.length;j++){
                if(ints[i].start>ints[j].start){
                    Interval temp=ints[j];
                    ints[j]=ints[i];
                    ints[i]=temp;
                }
            }
        }//printIntervals(ints);
        int minRooms=1;
        
        Interval[][] prevInts=new Interval[ints.length][ints.length];
        prevInts[0][0]=ints[0];
        int []sizes=new int[ints.length];
        for(int i=0;i<sizes.length;i++){
            sizes[i]=0;
        }
        sizes[0]=1;
        for(int i=1;i<ints.length;i++){
            if(!compatible(prevInts,ints[i],minRooms,sizes)){
                minRooms++;
                sizes[minRooms-1]++;
                prevInts[minRooms-1][0]=ints[i];//ints[i].printInterval();
            }//if compatible with a classroom it is scheduled //printSizes(sizes);
        }
        printRooms(prevInts,minRooms,sizes);
        System.out.println("Minimum rooms:"+minRooms);
    }
    public static boolean compatible(Interval[][] classRooms,Interval currInt, int roomNums, int size[]){
        for(int i=0;i<roomNums;i++){//System.out.print(i+","+classRooms[i].end+"."+currInt.start);
            if(classRooms[i][size[i]-1].end<=currInt.start){
                classRooms[i][size[i]]=currInt;//System.out.println(size[i]);
                size[i]++;
                return true;
            }//System.out.print("; ");
        }
        return false;
    }
    public static void printRooms(Interval[][] ints, int rooms,int[]sizes){
        for(int i=0;i<rooms;i++){
            for(int j=0;j<sizes[i];j++){
                ints[i][j].printInterval();
            }
            System.out.println();
        }
    }
    public static void printSizes(int[] sizes){
        for(int i=0;i<sizes.length;i++){
            System.out.print(sizes[i]);
        }
        System.out.println();
    }
    public static void printIntervals(Interval[] ints){
        for(int i=0;i<ints.length;i++){
            ints[i].printInterval();
        }
        System.out.println();
    }
}
